//
//  SharePlanViewController.m
//  whenme
//
//  Created by Eric English on 4/24/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "JoinPlanViewController.h"
#import "SharePlanViewController.h"
#import "SignupTableViewController.h"
#import "KeychainWrapper.h"
#import "whenMeConstants.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>
#import "SDWebImage/UIImageView+WebCache.h"

#import "SHK.h"
#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "Plan.h"
#import "GAI.h"

@interface JoinPlanViewController ()


@end



@implementation JoinPlanViewController

@synthesize myPlanData;
@synthesize backGround; 
@synthesize graybar;
@synthesize addButton;
@synthesize trashButton;
@synthesize remindSwitch;
@synthesize friendSwitch;
@synthesize shareMyPlan;
@synthesize planTextView;
@synthesize shareView;
@synthesize managedObjectContext;
@synthesize facebookShareButton;
@synthesize twitterShareButton;
@synthesize whenmeShareButton;
@synthesize isLoggedIn;
@synthesize hud = _hud;
@synthesize responseData;
@synthesize uniqueIDString;
@synthesize locationManager;
@synthesize currentLocation;
@synthesize timerDisplay;
@synthesize timer;
@synthesize myPlanImage;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithData:(NSMutableDictionary*)data nibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    // call the base class ini
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.myPlanData = data;
        NSLog(@" This is my plan data %@",myPlanData);
    }
    
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    //[SHK logoutOfAll];
    
    self.title=@"";
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }

    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
        self.view.backgroundColor=[UIColor colorWithRed:249.0f/255.0f green:247.0f/255.0f blue:243.0f/255.0f alpha:1.0f];
    [graybar setImage:[UIImage imageNamed:@"offwhite-bar.png"]] ;
    //[shareMyPlan setImage:[UIImage imageNamed:@"sharemyplan.png"]];
    
    shareView.layer.cornerRadius = 10;
    if (phoneVersion<5){
        
    }
    else {
        shareView.frame=CGRectMake(17,424,287,40);
    }
    
    planTextView.layer.cornerRadius = 10;
    planTextView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    planTextView.textColor=[[UIColor alloc] initWithRed:152.0 / 255 green:123.0 / 255 blue:94.0 / 255 alpha:1.0];
    //planTextView.layer.borderWidth=1;
    //planTextView.layer.borderColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1].CGColor;
    
    if (phoneVersion<5){
        
    }
    else {
        planTextView.frame=CGRectMake(17,145,287,267);
        
    }
    
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:@"Join Plan" style:UIBarButtonItemStylePlain target:self action:@selector(savePlan)];
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
    
    
    
    //construct the plan view text
    NSString *finalPlanText;
    NSString *planText=[myPlanData objectForKey:@"planText"];
    NSString *planDigitPicked=[myPlanData objectForKey:@"planDigitPicked"];
    NSString *planTimeFramePicked=[myPlanData objectForKey:@"planTimeFramePicked"];
    NSString *planDate=[myPlanData objectForKey:@"planDate"];
    uniqueIDString=[myPlanData objectForKey:@"uniqueID"];
    
    NSLog (@"In the view did load the string is %@",uniqueIDString);
    
    if ([planTimeFramePicked isEqualToString:@"right now"]){
        finalPlanText=[NSString stringWithFormat:@"\"I am going to %@ %@.\"",planText,planTimeFramePicked];
        planTextView.text=finalPlanText;
    }
    else if ([planTimeFramePicked isEqualToString:@"in the past"]){
        finalPlanText=[NSString stringWithFormat:@"\"I am going to %@.\"",planText];
        planTextView.text=finalPlanText;
    }
    else if(planTimeFramePicked==nil){
        finalPlanText=[NSString stringWithFormat:@"\"I am going to %@ %@.\"",planText,planDate];
        
    }
    else{
        finalPlanText=[NSString stringWithFormat:@"\"I am going to %@ %@ %@.\"",planText,planDigitPicked,planTimeFramePicked];
    }
    
    //finalPlanText=[NSString stringWithFormat:@"\"I am going to %@ %@ %@.\"",planText,planDigitPicked,planTimeFramePicked];
    //adjust font to fit uitext view
    planTextView.text=finalPlanText;
    float fudgeFactor = 16.0;
    float fontSize = 35;
    
    planTextView.font = [planTextView.font fontWithSize:fontSize];
    
    CGSize tallerSize = CGSizeMake(planTextView.frame.size.width-fudgeFactor,1000);
    CGSize stringSize = [finalPlanText sizeWithFont:planTextView.font constrainedToSize:tallerSize lineBreakMode:UILineBreakModeWordWrap];
    
    while (stringSize.height >= planTextView.frame.size.height)
    {
        if (fontSize <= 12) // it just won't fit
            NSLog(@"it just wont fit");
        
        fontSize -= 1.0;
        planTextView.font = [planTextView.font fontWithSize:fontSize];
        tallerSize = CGSizeMake(planTextView.frame.size.width-fudgeFactor,1000);
        stringSize = [finalPlanText sizeWithFont:planTextView.font constrainedToSize:tallerSize lineBreakMode:UILineBreakModeWordWrap];
    }
    
    
    UIImageView *triangle;
    if (phoneVersion<5){
        triangle = [[UIImageView alloc] initWithFrame:CGRectMake(145, 370, 31, 16)];
    }
    else {
        triangle = [[UIImageView alloc] initWithFrame:CGRectMake(145, 458, 31, 16)];
        
    }
    triangle.image = [UIImage imageNamed:@"triangle.png"];
    [self.view addSubview:triangle];
    
    
    
    
    addButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    
    if(phoneVersion<5){
    addButton.frame = CGRectMake(0,388, 320,43);
    }
    else{
      addButton.frame = CGRectMake(0,476, 320,43);
    }
    addButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [addButton addTarget:self action:@selector(savePlan) forControlEvents:UIControlEventTouchUpInside];
    [addButton setBackgroundImage:[UIImage imageNamed:@"joinPlan-large.png"] forState:UIControlStateNormal]; //sets the Background image 
    
    [addButton setImage:[UIImage imageNamed:@"joinPlan-large.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:addButton];
 
    UIImageView *theUserImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64, 30, 30)];
    [theUserImage setImageWithURL:[NSURL URLWithString:[myPlanData objectForKey:@"userImage"]]
                   placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
    [[self view] addSubview:theUserImage];

    
    
    NSString *userName;
    userName=[NSString stringWithFormat:@"%@'s plan",[myPlanData objectForKey:@"username"]];
    UILabel *userLabel = [ [UILabel alloc ] initWithFrame:CGRectMake(35, 64, 150.0, 32.0) ];
    userLabel.textAlignment =  UITextAlignmentLeft;
    userLabel.textColor = [UIColor brownColor];
    userLabel.backgroundColor = [UIColor clearColor];
    userLabel.font = [UIFont systemFontOfSize:12.0f];
    [self.view addSubview:userLabel];
    userLabel.text=userName;
    
    UILabel *planDateLabel;
    if(phoneVersion<5){
       planDateLabel = [ [UILabel alloc ] initWithFrame:CGRectMake(0, 275+64, 320.0, 32.0) ];
    }
    else{
       planDateLabel = [ [UILabel alloc ] initWithFrame:CGRectMake(0, 363+64, 320.0, 32.0) ];
    }
     
    planDateLabel.textAlignment =  UITextAlignmentCenter;
    planDateLabel.textColor = [[UIColor alloc] initWithRed:206.0 / 255 green:203.0 / 255 blue:193.0 / 255 alpha:1.0];
    planDateLabel.backgroundColor = [UIColor clearColor];
    planDateLabel.font = [UIFont systemFontOfSize:20.0f];
    [self.view addSubview:planDateLabel];
    
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    
    NSDateFormatter *dateFormatback = [[NSDateFormatter alloc] init];
    [dateFormatback setTimeZone:timeZone];
    [dateFormatback setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    
    NSLog(@"Current Date: %@", [dateFormat stringFromDate:[NSDate date]]);
    NSLog(@"Sent date: %@",[myPlanData valueForKey:@"planDate"]);
    NSDate *aDate =[dateFormat dateFromString:[myPlanData valueForKey:@"planDate"]];
    NSLog(@"Converted date is: %@",aDate);
    NSString *planDateString = [dateFormatback stringFromDate:aDate];
    NSLog(@"The converted date string is: %@",planDateString);
 
    planDateLabel.text=planDateString;
  
    
    UILabel *imgView2 = [[UILabel alloc] initWithFrame:CGRectMake(180, 70, 71, 20)];
    [imgView2 setText:@"friend:"];
    imgView2.textColor=[UIColor lightGrayColor];
    [[self view] addSubview:imgView2];
    
    

    
    friendSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(237, 64, 0, 0)];
    //[friendSwitch addTarget: self action: @selector(flipLocation) forControlEvents: UIControlEventValueChanged];
     [friendSwitch setOn:YES];
     [self.view addSubview: friendSwitch];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    if (!context) {
        NSLog(@"NO MANAGED OBJECT CONTEXT");
    }
    
    
    // Pass the managed object context to the view controller.
    self.managedObjectContext = context;
    
    //set up share buttons
    
    
    
    
    
    /*if ([[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]){
        UIImageView *disabledSharers= [[UIImageView alloc] init];
        disabledSharers.image = [UIImage imageNamed:@"sharingDisabled.png"];
        disabledSharers.frame = CGRectMake(182, 275,115,35);
        [[self view] insertSubview:disabledSharers atIndex:100];
    }
    else {
        facebookShare=[SHKFacebook isServiceAuthorized];
        twitterShare=[SHKTwitter isServiceAuthorized];
        whenmeShare=YES;
        
        if (whenmeShare==NO){
            whenmeShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            whenmeShareButton.frame = CGRectMake(182, 275, 34, 35);
            whenmeShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [whenmeShareButton addTarget:self action:@selector(toggleWhenme) forControlEvents:UIControlEventTouchUpInside];
            [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:whenmeShareButton];
        }
        else{
            whenmeShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            whenmeShareButton.frame = CGRectMake(182, 275, 34, 35);
            whenmeShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [whenmeShareButton addTarget:self action:@selector(toggleWhenme) forControlEvents:UIControlEventTouchUpInside];
            [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:whenmeShareButton];
            
        }
        
        if (twitterShare==NO){
            twitterShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            twitterShareButton.frame = CGRectMake(222, 275, 34, 35);
            twitterShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [twitterShareButton addTarget:self action:@selector(authorizeTwitter) forControlEvents:UIControlEventTouchUpInside];
            [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:twitterShareButton];
        }
        else{
            twitterShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            twitterShareButton.frame = CGRectMake(222, 275, 34, 35);
            twitterShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [twitterShareButton addTarget:self action:@selector(toggleTwitter) forControlEvents:UIControlEventTouchUpInside];
            [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:twitterShareButton];
            
        }
        
        if (facebookShare==NO){
            facebookShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            facebookShareButton.frame = CGRectMake(262, 275, 34, 35);
            facebookShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [facebookShareButton addTarget:self action:@selector(authorizeFacebook) forControlEvents:UIControlEventTouchUpInside];
            [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:facebookShareButton];
        }
        else
        {
            facebookShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
            facebookShareButton.frame = CGRectMake(262, 275, 34, 35);
            facebookShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
            [facebookShareButton addTarget:self action:@selector(toggleFacebook) forControlEvents:UIControlEventTouchUpInside];
            [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
            
            [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the image
            [[self view] addSubview:facebookShareButton];
            
        }
    }*/
    NSLog(@"first clock tick is %@",[myPlanData objectForKey:@"planDate"]);
    [self clockTick:[myPlanData objectForKey:@"planDate"]];
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"join_plan"];
}

-(void)savePlan{
    if(isLoggedIn){
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Joining Plan...";
        responseData = [NSMutableData data];
        NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
        NSString *passwordToSend=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
        NSString *addFriend;
        if (friendSwitch.isOn){
            addFriend=[NSString stringWithFormat:@"1"];
        }
        else {
            addFriend=[NSString stringWithFormat:@"0"];
        }
        
        const char *bytes = [[NSString stringWithFormat:@"secretKey=387213549&userID=%@&password=%@&uniqueID=%@&addFriend=%@", userID,passwordToSend,uniqueIDString,addFriend] UTF8String];
        NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/joinplan.aspx"];
        NSMutableURLRequest *request =
        [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
        [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
        
    //[self performSelector:@selector(addPlan) withObject:nil afterDelay:1.0];
    }
    else {
        SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"SignUp", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
}

- (void) addPlan
{
    [self.hud hide:YES];
    //create a dictionary object with all of the collected data

    NSDate *myPlanDate;
    NSString *digitPicked;
    NSString *timeFramePicked;


    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    NSDate *aDate =[dateFormat dateFromString:[myPlanData valueForKey:@"planDate"]];
    NSLog(@"The date is: %@",aDate);
    NSString *dateString = [dateFormat stringFromDate:aDate];
        
        
        //convert date to timeframe
        
        NSDate *todayDate = [NSDate date];
        NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
        
        NSDate *today=[dateFormat dateFromString:todayDateString];
        NSDate *strDate=[dateFormat dateFromString:dateString];
        NSLog(@"strDate is %@",strDate);
        
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                                   fromDate:today
                                                     toDate:strDate
                                                    options:0];
        
        
        NSLog(@"%d days %d hours %d minutes %d seconds",components.day,components.hour,components.minute,components.second);
        
        
        if (components.day>0) {
            digitPicked=[NSString stringWithFormat:@"%d", components.day];
            timeFramePicked=@"days from now";
        }
        else if (components.hour>0){
            digitPicked=[NSString stringWithFormat:@"%d", components.hour];
            timeFramePicked=@"hours from now";
        }
        
        else if (components.minute>0){
            digitPicked=[NSString stringWithFormat:@"%d", components.minute];
            timeFramePicked=@"minutes from now";
        }
        
        else{
            digitPicked=@"--";
            timeFramePicked=@"right now";
        }
        
    
           //store the plan locally using core data
    
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterDecimalStyle];
    NSNumber * mylat = [f numberFromString:[myPlanData objectForKey:@"latitude"]];
    NSNumber * mylong = [f numberFromString:[myPlanData objectForKey:@"longitude"]];
        
        Plan *plan = (Plan *)[NSEntityDescription insertNewObjectForEntityForName:@"Plan" inManagedObjectContext:managedObjectContext];
        
        [plan setPlanID:nil];
        [plan setUniqueID:nil];
        [plan setPlanText:[myPlanData objectForKey:@"planText"]];
        [plan setPlanDigit:digitPicked];
        [plan setPlanTimeFrame:timeFramePicked];
        [plan setPlanDate:aDate];
        [plan setLatitude:mylat];
        [plan setLongitude:mylong];
        [plan setCreateDate:[NSDate date]];
        [plan setActive:[NSNumber numberWithInteger: 1]];
        [plan setHasPlanPicture:[NSNumber numberWithInteger: 0]];
        [plan setHasCompletePicture:[NSNumber numberWithInteger: 0]];
        [plan setLocationOverride:[NSNumber numberWithInteger: 0]];
        
        NSError *error = nil;
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }
        else {
            NSLog(@"Plan saved");
        }
        
        NSManagedObjectID *localID = [plan objectID];
        NSURL *uri = [localID URIRepresentation];
        NSData *uriData = [NSKeyedArchiver archivedDataWithRootObject:uri];
        
        NSString *hasPlanPicture=@"0";
        NSString *hasCompletePicture=@"0";
        NSString *locationOverride=@"0";
        
        NSMutableDictionary *myPlan = [[NSMutableDictionary alloc] initWithObjectsAndKeys:dateString, @"planDate", [myPlanData objectForKey:@"planText"], @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",uriData,@"localID", hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",locationOverride,@"locationOverride", [myPlanData objectForKey:@"latitude"],@"latitude",[myPlanData objectForKey:@"longitude"],@"longitude", nil];
    
    NSLog(@"I am sending the plan data %@",myPlan);


        [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
        
        /*NSString *customTime = [[NSUserDefaults standardUserDefaults]
         stringForKey:@"customTime"];
         if (!customTime){
         customTime=@" 9:00:00";
         }*/
        NSString *myFireDateString=dateString;
        NSLog(@"%@",myFireDateString);
        NSDate *myFireDate = [dateFormat dateFromString:myFireDateString];
        
        
        UILocalNotification *scheduledAlert;
        scheduledAlert = [[UILocalNotification alloc] init];
        scheduledAlert.applicationIconBadgeNumber=-1;
        scheduledAlert.fireDate = myFireDate;
        scheduledAlert.timeZone = [NSTimeZone localTimeZone];
        scheduledAlert.userInfo = myPlan;
        scheduledAlert.soundName= UILocalNotificationDefaultSoundName;
        scheduledAlert.alertBody = [NSString stringWithFormat:@"Reminder: \"%@\" ", planTextView.text];
        [[UIApplication sharedApplication] scheduleLocalNotification:scheduledAlert];
        
        
        SharePlanViewController *sharePlanView=[[SharePlanViewController alloc] initWithData:myPlan nibName:@"SharePlanViewController" bundle:nil];
        
        sharePlanView.managedObjectContext = self.managedObjectContext;
        
        
        
        [self.navigationController pushViewController:sharePlanView animated:YES];
    }
    



- (void) authorizeFacebook{
    [self toggleFacebook];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    NSString *urlImage = @"http://www.when.me//images/icon.png";
    
    [item setCustomValue:urlImage forKey:@"image"];
    [SHKFacebook shareItem:item];
    
}

- (void) authorizeTwitter{
    [self toggleTwitter];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    
    // Share the item
    [SHKTwitter shareItem:item];
    
}

- (void) toggleFacebook {
    //facebookShare=!facebookShare;
    
    if (facebookShare==NO){
        facebookShare=YES;
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        facebookShare=NO;
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}



- (void) toggleTwitter {
    
    if (twitterShare==NO){
        twitterShare=YES;
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        twitterShare=NO;
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}

- (void) toggleWhenme {
    
    if (whenmeShare==NO){
        whenmeShare=YES;
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        whenmeShare=NO;
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}



-(void) showTrashConfirm{
    [self showDeleteSheet:nil];
}

-(void) showCompleteConfirm{
    [self showCompleteSheet:nil];
}

-(IBAction)showDeleteSheet:(id)sender {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Permanently Delete Plan?" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Delete Plan" otherButtonTitles:nil, nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery setTag:1];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
    
}

-(IBAction)showCompleteSheet:(id)sender {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Complete This Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:nil, nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery setTag:2];
    [popupQuery addButtonWithTitle:@"I Did It!"]; 
    [popupQuery addButtonWithTitle:@"I'm There!"];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
    
}

-(IBAction)showPhotoSheet {
	UIActionSheet *popupQuery;
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
        popupQuery = [[UIActionSheet alloc] initWithTitle:@"Attach Photo To Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Remove Photo" otherButtonTitles:@"Take New Photo",@"From Photo Library", nil];
    }
    
    else {
        
        popupQuery = [[UIActionSheet alloc] initWithTitle:@"Attach Photo To Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take New Photo",@"From Photo Library", nil];
        
    }
    
	popupQuery.actionSheetStyle = UIActionSheetStyleDefault;
    [popupQuery setTag:3];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
	
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	
    
    NSLog(@"I am here");
    int actionSheetTag;
    
    actionSheetTag=[actionSheet tag];
    
    if (actionSheetTag==1){
        NSLog(@"Trash it");
        
        if (buttonIndex == 0) { //delete sheet
      
            //[self trashMe];
            
        }
    }
    
    else if (actionSheetTag==2){ //complete sheet
        if (buttonIndex == 1) {
            //[self completeMe];
            
        }
        
        if (buttonIndex == 2) {
            //[self completeMe];
            
        }
    }
    
    else if (actionSheetTag==3){ //photo sheet
        
        if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
            
            if (buttonIndex == 0) {
                
                [self deletePlanPhoto];
                
            }
            
            if (buttonIndex == 1) {
                
                [self getImageFromCamera];
                
            }
            if (buttonIndex == 2) {
                [self loadImageFromPicker];
                
                
            }
            
            
            if (buttonIndex == 3) {
                NSLog(@"cancel");
                
            }
            
        }
        else {
            if (buttonIndex == 0) {
                
                [self getImageFromCamera];
                
            }
            if (buttonIndex == 1) {
                [self loadImageFromPicker];
                
                
            }
            
            
            if (buttonIndex == 2) {
                NSLog(@"cancel");
                
            }
        }
        
        
    }
    
    
    
}

-(void) deletePlanPhoto {
    NSLog(@"Delete Plan Photo");
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
        
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:folderPath];
    
    
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",dataPath];
    NSLog(@"I am here photo path:%@",photoPath);
    
    [[NSFileManager defaultManager] removeItemAtPath:photoPath error:NULL];
    //update view
    [myPlanData setObject:[NSNumber numberWithInteger: 0] forKey:@"hasPlanPicture"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myNumber = [f numberFromString:@"0"];
    [myMO setValue:myNumber forKey:@"hasPlanPicture"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }
    
    [myPlanImage removeFromSuperview];
    
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"I am  in view will");
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    timer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                             target: self
                                           selector:@selector(onTick:)
                                           userInfo: nil repeats:YES];
    
    

    
    
    //UIButton *aButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //aButton.frame = CGRectMake(289, 67, 50, 100);
    //[aButton addTarget:self action:@selector(showPhotoSheet) forControlEvents:UIControlEventTouchUpInside];
    //[[self view] insertSubview:aButton atIndex:102];
}

-(void) downloadPicture:(NSString *)planID{
    NSData * imageData;
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Getting photo...";
    NSString *path=[NSString stringWithFormat:@"http://www.when.me/iOScode/getPlanPhoto.aspx?planID=%@",planID];
    NSLog(@"getting photo %@",path);
    NSURL *url = [NSURL URLWithString:path];
    imageData = [NSData dataWithContentsOfURL:url];
    UIImage *img=[UIImage imageWithData:imageData];
    
    //add 1px transparent border to image for anti aliased rotation
    CGRect imageRrect = CGRectMake(0, 0, img.size.width, img.size.height);
    UIGraphicsBeginImageContext( imageRrect.size ); 
    [img drawInRect:CGRectMake(1,1,img.size.width-2,img.size.height-2)];
    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    myPlanImage= [[UIImageView alloc] init];
    myPlanImage.image = img;
    
    myPlanImage.frame = CGRectMake(269, 83,50,50);
    myPlanImage.transform = CGAffineTransformMakeRotation(.34906585);
    
    [[self view] insertSubview:myPlanImage atIndex:100];


    UIImageView *paperClip=  [[UIImageView alloc] init];
    paperClip.image=[UIImage imageNamed:@"paperClip.png"];
    paperClip.frame = CGRectMake(289, 67,21,28);
    [[self view] insertSubview:paperClip atIndex:101];
}

- (void)viewDidAppear:(BOOL)animated{
    NSLog(@"I am  in view did");
    
}

-(void)onTick:(NSTimer *)timer {
	//NSLog(@"Timer Ticked");
	[self clockTick:[myPlanData objectForKey:@"planDate"]];
	
}

- (void) clockTick:(NSString *)myDate
{
    
	
	//myDate=[myDate stringByAppendingString:@" 00:00:00"];
	
	NSDate *todayDate = [NSDate date];
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
	NSString *dateString = [dateFormat stringFromDate:todayDate];  
	
	NSDate *today=[dateFormat dateFromString:dateString];
	NSDate *movieReleaseDate=[dateFormat dateFromString:myDate];
	
	
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
	NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
											   fromDate:today
												 toDate:movieReleaseDate
												options:0];
    
	self.timerDisplay.text=[NSString stringWithFormat:@"%.2i:%.2i:%.2i:%.2i", components.day, components.hour,components.minute,components.second];
    
    if(self.timerDisplay.text==@"00:00:00:00"){
        
		self.timerDisplay.text=@"00:00:00:00";
		
	}
	
	
	if ([self.timerDisplay.text rangeOfString:@"-"].location != NSNotFound) {
        
		self.timerDisplay.text=@"00:00:00:00";
		
	}
    
    
}





- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSString *)escape:(NSString *)text
{
    return (__bridge NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                        (__bridge CFStringRef)text, NULL,
                                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                        kCFStringEncodingUTF8);
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    NSLog(@"%@",error);
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	if ([s rangeOfString:@"success"].location == NSNotFound){ 
        
        NSLog(@"In connection did fail with error");
        [self.hud hide:YES];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                            message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
        
       
        
    }
    else { //success! ad the plan
       [self performSelector:@selector(addPlan) withObject:nil]; 
      
    }
    
    
    
	
	
}

-(void)checkIt{
    
    //[self.hud hide:YES];
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	NSLog(@"%@",s);
    
    if ([s rangeOfString:@"success"].location == NSNotFound){
        
        //something went wrong
        [self.hud hide:YES];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                            message:s
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
        
        
    }
    
    else {
        
        //update the plan ID
        NSArray *split = [s componentsSeparatedByString: @"_"];
        NSString *newPlanID=[split objectAtIndex:1];
        NSString *uniqueID=[split objectAtIndex:2];
        uniqueIDString=uniqueID;
        
        //update the plan with server ID
        //get the id of current plan
        NSData *uriData;
        NSPersistentStoreCoordinator *psc;
        NSManagedObjectContext *moc;
        moc=[self managedObjectContext];
        psc = [moc persistentStoreCoordinator];
        uriData=[myPlanData objectForKey:@"localID"];
        NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
        NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:uri];
        NSError *error = nil;
        NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterNoStyle];
        NSNumber * myNumber = [f numberFromString:newPlanID];
        [myMO setValue:myNumber forKey:@"planID"];
        [myMO setValue:uniqueID forKey:@"uniqueID"];
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }
    }
    
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
        [self uploadPhoto];
    }
    
    else {
        [self performSelector:@selector(checkInOther) withObject:nil];
    } 
    
}

-(void)checkInOther{
    
    [self.hud hide:YES];
    if (facebookShare==YES || twitterShare==YES){
        self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    
    if (facebookShare==NO && twitterShare==NO){
        self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        _hud.labelText = @"Finishing Up...";
    }
    
    
    NSLog(@" authroized= %d share= %d",(int)[SHKFacebook isServiceAuthorized],(int)facebookShare);
    if ([SHKFacebook isServiceAuthorized] && facebookShare==YES){
        
        _hud.labelText = @"Sharing on services...";
        [self writeFacebook];
    }
    
    if ([SHKTwitter isServiceAuthorized] && twitterShare==YES){
        _hud.labelText = @"Sharing on services...";
        [self writeTwitter];
    }
    
    [self performSelector:@selector(showShareSuccess) withObject:nil afterDelay:2.0];
}

-(void)showShareSuccess{
    [self.hud hide:YES];
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Success!";
    [self performSelector:@selector(finishUp) withObject:nil afterDelay:1.0];
    
}

-(void) finishUp {
    [self.hud hide:YES];
    
    //[self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:([self.navigationController.viewControllers count] -3)] animated:YES];
}

- (void) writeFacebook {
    NSLog(@"writing to facebook");
    
    
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){ //share the iamge
        
        //get the image
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
        NSString *folderPath = [uri absoluteString];
        
        NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
        
        if(rangeOfSubstring.location == NSNotFound)
        {
            
        }
        
        folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
        
        NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
        NSLog(@"The image path is %@",imagePath);
        UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
        
        NSString *URLString;
        NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
        if (uniqueIDString!=nil){
            URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
        }
        else {
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
        }
        shareTitle=[NSString stringWithFormat:@"%@ %@",shareTitle,URLString];
        
        
        SHKItem *item = [SHKItem image:image title:shareTitle];
        [SHKFacebook shareItem:item];
    }
    else {
        
        
        NSString *URLString;
        NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
        if (uniqueIDString!=nil){
            URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
        }
        else {
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
        }
        
        NSURL *url = [NSURL URLWithString:URLString];
        SHKItem *item = [SHKItem URL:url title:shareTitle text:@"Join me!"];
        
        NSString *urlImage = @"http://www.when.me//images/icon.png";
        
        [item setCustomValue:urlImage forKey:@"image"];
        
        // Share the item
        [SHKFacebook shareItem:item];
    }
    
    
}

- (void) writeTwitter {
    NSLog(@"writing to twitter");
    
    
    
    /*NSString *twitterHash=[movieTitle stringByReplacingOccurrencesOfString:@" " withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@":" withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"-" withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"'" withString:@""];
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"." withString:@""]; 
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"?" withString:@""]; 
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"!" withString:@""];
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"," withString:@""];*/
    
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){ //share the iamge
        
        //get the image
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
        NSString *folderPath = [uri absoluteString];
        
        NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
        
        if(rangeOfSubstring.location == NSNotFound)
        {
            
        }
        
        folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
        
        NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
        NSLog(@"The image path is %@",imagePath);
        UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
        
        NSString *URLString;
        NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
        if (uniqueIDString!=nil){
            URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
        }
        else {
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
        }
        shareTitle=[NSString stringWithFormat:@"%@ %@ via @WhenMeApp",shareTitle,URLString];
        
        
        SHKItem *item = [SHKItem image:image title:shareTitle];
        [SHKTwitter shareItem:item];
    }
    else {
        
        
        NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
        NSString *URLString;
        shareTitle=[NSString stringWithFormat:@"%@ via @WhenMeApp", shareTitle];
        if (uniqueIDString!=nil){
            URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
        }
        else {
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
        }
        
        NSURL *url = [NSURL URLWithString:URLString];
        SHKItem *item = [SHKItem URL:url title:shareTitle];
        
        // Share the item
        [SHKTwitter shareItem:item];
    }
    
}





#pragma mark -
#pragma mark Location manager

/**
 Return a location manager -- create one if necessary.
 */

- (CLLocationManager *)locationManager 
{
	
    if (locationManager != nil) 
    {
		return locationManager;
	}
	
	locationManager = [[CLLocationManager alloc] init];
	[locationManager setDesiredAccuracy:kCLLocationAccuracyNearestTenMeters];
	[locationManager setDelegate:self];
	
	return locationManager;
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation 
{
    
    NSLog(@"I am in the locationManger did update");
    
    currentLocation = newLocation;
    CLLocationCoordinate2D coords=CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    NSLog(@"The corrdinate is %f",coords.latitude);
    NSString *latString=[NSString stringWithFormat:@"%f", coords.latitude];   
    NSString *longString=[NSString stringWithFormat:@"%f", coords.longitude]; 
    [myPlanData setObject:latString forKey:@"latitude"];
    [myPlanData setObject:longString forKey:@"longitude"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myLat = [f numberFromString:latString];
    NSNumber * myLong = [f numberFromString:longString];
    [myMO setValue:myLat forKey:@"latitude"];
    [myMO setValue:myLong forKey:@"longitude"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }
    
    [self.hud hide:YES];
    [locationManager stopUpdatingLocation];
    
    
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error 
{
    NSLog(@"locationManager FAIL");
    NSLog(@"%@", [error description]);
    [self.hud hide:YES];
    //[locationSwitch setOn:false animated:YES];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"You have disabled location sharing for when.me or no network connection is available. To re-enable location sharing please switch 'Location Services' to 'On' for when.me in your device settings." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
    
}

-(void) getImageFromCamera {
    UIImagePickerController *imagePicker =
    [[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    
    imagePicker.sourceType = 
    UIImagePickerControllerSourceTypeCamera;
    //imagePicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    
    imagePicker.mediaTypes = [NSArray arrayWithObjects:
                              (NSString *) kUTTypeImage,
                              nil];
    
    imagePicker.allowsEditing = YES;
    [self presentModalViewController:imagePicker 
                            animated:YES];
}

-(void) loadImageFromPicker{
    
    UIImagePickerController *pickerC = 
    [[UIImagePickerController alloc] init];
    pickerC.delegate = self;
    [self presentModalViewController:pickerC animated:YES];
    
}

#pragma imagepicker deletgate

- (void)imagePickerController:(UIImagePickerController *)picker 
didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *gotImage = 
    [info objectForKey:UIImagePickerControllerOriginalImage];
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera){
        UIImageWriteToSavedPhotosAlbum(gotImage, nil, nil, nil);
    }
    CGSize sizeOfPhoto = CGSizeMake(500, 500);
    gotImage=[self imageWithImage:gotImage scaledToSizeKeepingAspect:(sizeOfPhoto)];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
        
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:folderPath];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:YES attributes:nil error:nil]; //Create folder
    
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
    NSLog(@"I am here photo path:%@",photoPath);
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
    NSData *webData = UIImagePNGRepresentation(gotImage);
    [webData writeToFile:imagePath atomically:YES];
    
    //update view
    [myPlanData setObject:[NSNumber numberWithInteger: 1] forKey:@"hasPlanPicture"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myNumber = [f numberFromString:@"1"];
    [myMO setValue:myNumber forKey:@"hasPlanPicture"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }
    
    
    
    
    [self dismissModalViewControllerAnimated:YES];
    
}



- (void)imagePickerControllerDidCancel:
(UIImagePickerController *)picker {
    [self dismissModalViewControllerAnimated:YES];
}

- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSizeKeepingAspect:(CGSize)targetSize
{  
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
        {
            scaleFactor = widthFactor; // scale to fit height
        }
        else
        {
            scaleFactor = heightFactor; // scale to fit width
        }
        
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5; 
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }     
    
    CGContextRef bitmap;
    CGImageRef imageRef = [sourceImage CGImage];
    CGColorSpaceRef genericColorSpace = CGColorSpaceCreateDeviceRGB();
    if (sourceImage.imageOrientation == UIImageOrientationUp || sourceImage.imageOrientation == UIImageOrientationDown)
    {
        bitmap = CGBitmapContextCreate(NULL, targetWidth, targetHeight, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }
    else
    {
        bitmap = CGBitmapContextCreate(NULL, targetHeight, targetWidth, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }   
    
    CGColorSpaceRelease(genericColorSpace);
    CGContextSetInterpolationQuality(bitmap, kCGInterpolationDefault);
    
    // In the right or left cases, we need to switch scaledWidth and scaledHeight,
    // and also the thumbnail point
    if (sourceImage.imageOrientation == UIImageOrientationLeft)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(90));
        CGContextTranslateCTM (bitmap, 0, -targetHeight);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationRight)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(-90));
        CGContextTranslateCTM (bitmap, -targetWidth, 0);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationUp)
    {
        // NOTHING
    }
    else if (sourceImage.imageOrientation == UIImageOrientationDown)
    {
        CGContextTranslateCTM (bitmap, targetWidth, targetHeight);
        CGContextRotateCTM (bitmap, radians(-180.));
    }
    
    CGContextDrawImage(bitmap, CGRectMake(thumbnailPoint.x, thumbnailPoint.y, scaledWidth, scaledHeight), imageRef);
    CGImageRef ref = CGBitmapContextCreateImage(bitmap);
    UIImage* newImage = [UIImage imageWithCGImage:ref];
    
    CGContextRelease(bitmap);
    CGImageRelease(ref);
    
    return newImage; 
}

-(void)uploadPhoto{
    NSLog(@"I am in the uploadPhoto method");
    
    //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Uploading Picture...";
    
    NSString *URLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/uploadPlanPhoto.aspx?secretkey=387213549&userID=%@&password=%@&planID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"],[[NSUserDefaults standardUserDefaults] valueForKey:@"password"],uniqueIDString];
    //NSLog(@"%@",URLString);
    NSURL *url = [NSURL URLWithString:URLString];
    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    [request setUseKeychainPersistence:YES];
    
    
    NSString *fileName = [NSString stringWithFormat:@"planPhoto_%@.jpg",uniqueIDString];
    [request addPostValue:fileName forKey:@"name"];
    
    // Upload an image
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
        
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
    NSLog(@"The image path is %@",imagePath);
    UIImage *img = [UIImage imageWithContentsOfFile:imagePath]; 
    NSData *imageData = UIImageJPEGRepresentation(img,0.66);
    
    
    [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"userfile"];
    
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(uploadRequestFinished:)];
    [request setDidFailSelector:@selector(uploadRequestFailed:)];
    
    [request startAsynchronous];
}

- (void)uploadRequestFinished:(ASIHTTPRequest *)request{    
    NSString *responseString = [request responseString];
    NSLog(@"Upload response %@", responseString);
    _hud.labelText = @"Success!";
    [self performSelector:@selector(checkInOther) withObject:nil afterDelay:0.5];
}

- (void)uploadRequestFailed:(ASIHTTPRequest *)request{
    
    NSLog(@" Error - Statistics file upload failed: \"%@\"",[[request error] localizedDescription]); 
    
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
}






@end
