//
//  SignupTableViewController.h
//  ExSignup
//
//  Created by Nada Jaksic on 7/13/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "whenMeConstants.h"
#import <Accounts/Accounts.h>




@interface UserTableViewController : UITableViewController<UITextFieldDelegate, UIAlertViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate>
{

    IBOutlet UITableViewCell *cellUsername;
    IBOutlet UITableViewCell *cellEmail;
    IBOutlet UITableViewCell *cellPicture;

	

	IBOutlet UITextField* txtUsername;
	IBOutlet UITextField* txtEmail;
    IBOutlet UIImageView* myPicture;



	UIActivityIndicatorView* activityIndicator;
    
    NSMutableData *responseData;
    
    MBProgressHUD *_hud;
    
    BOOL tryFaceBookPic;
    


    


}

@property (nonatomic, retain) IBOutlet UITableViewCell *cellUsername;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellEmail;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellPicture;


@property (nonatomic, retain) IBOutlet UITextField* txtUsername;
@property (nonatomic, retain) IBOutlet UITextField* txtEmail;
@property (nonatomic, retain) IBOutlet UIImageView* myPicture;


@property (nonatomic, retain) IBOutlet NSMutableData* responseData;

@property (retain) MBProgressHUD *hud;


@property (strong, nonatomic) ACAccountStore *accountStore; 
@property (strong, nonatomic) NSArray *accounts;

@property (strong, nonatomic) NSTimer *timer;








@end
