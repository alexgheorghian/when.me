//
//  LeaderBoardViewController.h
//  whenme
//
//  Created by Eric English on 6/14/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//



#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface LeaderBoardViewController : UIViewController<UITableViewDelegate,UIActionSheetDelegate>
{ 
    NSMutableData *responseData;
    MBProgressHUD *_hud;
    NSMutableArray *plansArray;
    int feedType;
    int phoneVersion;
    NSManagedObjectContext *managedObjectContext;
}

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;
@property (nonatomic, retain) NSMutableArray *leadersArray;
@property (retain) MBProgressHUD *hud;
@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;
@property (strong, nonatomic) IBOutlet UITableView *tv;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;


@end
