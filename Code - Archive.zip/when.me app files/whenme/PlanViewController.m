//
//  FirstViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "PlanViewController.h"
#import "Plan.h"
#import "SignupTableViewController.h"
#import "UserTableViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>
#import "whenMeConstants.h"
#import "CMPopTipView.h"
#import "GAI.h"


@interface PlanViewController ()


@end

@implementation PlanViewController


@synthesize backGround; 
@synthesize logo;
@synthesize iamgoingto;
@synthesize iamat;
@synthesize addButton;
@synthesize mapButton;
@synthesize thereButton;
@synthesize aButton;
@synthesize aButton2;
@synthesize calendarButton;
@synthesize myDigitPickerView;
@synthesize myTimeFramePickerView;
@synthesize myDateTimePickerView;
@synthesize digitsArray;
@synthesize timeFrameArray;
@synthesize planTextView;
@synthesize myPhoto;
@synthesize placesView;
@synthesize navController;
@synthesize hud = _hud;
@synthesize managedObjectContext;
@synthesize segControl;
@synthesize planLatitude;
@synthesize planLongitude;
@synthesize locationGray;
@synthesize planPickerMaskView;
@synthesize planPickerDateMaskView;
@synthesize isLoggedIn;
@synthesize toolbar;
@synthesize planArrow;
@synthesize planArrowBack;
@synthesize photoButton;
@synthesize buttonImage2;
@synthesize photoButtonImage;
@synthesize PopTipView;
@synthesize PopTipView2;
@synthesize PopTipViewFirstTime;
@synthesize imgView;
@synthesize tutorialPop;
@synthesize playSound;





- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"New Plan";
        self.tabBarItem.image = [UIImage imageNamed:@"704-compose"];
       
    }
    return self;
}
							
- (void)viewDidLoad
{
    self.title=@"New Plan";
     self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    //self.navigationController.navigationBar.titleTextAttributes=[UIColor darkGrayColor];
    
     self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    NSLog(@"The value for isLoggedIn is %d",(int)isLoggedIn); 
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
     //[backGround setImage:[UIImage imageNamed:@"background-tan.png"]] ;
     //[logo setImage:[UIImage imageNamed:@"whenmebar.png"]];
    [iamgoingto setImage:[UIImage imageNamed:@"iamgoingto.png"]];
    [iamat setImage:[UIImage imageNamed:@"iamat.png"]];
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }
    
    
    
    toolbar = [[UIToolbar alloc] init];
    //toolbar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    toolbar.tintColor = [UIColor colorWithRed:200.0f/255.0f green:176.0f/255.0f blue:156.0f/255.0f alpha:1.0f];
    if (phoneVersion<5){
     toolbar.frame=CGRectMake(0,387,320, 44);
    }
    else {
        toolbar.frame=CGRectMake(0,475,320, 44);
    }
    segControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Timespan", @"Time & Date", nil]];
    segControl.selectedSegmentIndex=0;
    segControl.segmentedControlStyle=UISegmentedControlStyleBar;
    [segControl addTarget:self
                         action:@selector(segmentSwitch)
               forControlEvents:UIControlEventValueChanged];
    
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:segControl];
    
    UIImage *buttonImage = [UIImage imageNamed:@"mapButton-brown.png"];
    aButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aButton setImage:buttonImage forState:UIControlStateNormal];
    aButton.frame = CGRectMake(0.0, 0.0, buttonImage.size.width, buttonImage.size.height);
    [aButton addTarget:self action:@selector(showMap) forControlEvents:UIControlEventTouchUpInside];
    
 

    /*if (!isLoggedIn){
        buttonImage2 = [UIImage imageNamed:@"mebutton-gray.png"];}
        else {
            buttonImage2 = [UIImage imageNamed:@"mebuttonOn-gray.png"];
        }
 

        aButton2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [aButton2 setImage:buttonImage2 forState:UIControlStateNormal];
        aButton2.frame = CGRectMake(0.0, 0.0, buttonImage2.size.width, buttonImage2.size.height);
        [aButton2 addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
    
    // Initialize the UIBarButtonItem
     
     */
  
   
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:@"Save plan" style:UIBarButtonItemStylePlain target:self action:@selector(savePlan)];          
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
 

    toolbar.items = [NSArray arrayWithObjects:flexibleSpace,btnItem,flexibleSpace,nil];
    
    //planTextView.text=@"Enter a plan";
   // planTextView.layer.cornerRadius = 10;
    planTextView.contentInset = UIEdgeInsetsMake(10, 10, 10, 10);
    planTextView.returnKeyType=UIReturnKeyDone;
    planTextView.backgroundColor= [UIColor colorWithRed:249.0f/255 green:247.0f/255 blue:243.0f/255 alpha:1];
    //planTextView.layer.borderWidth=1;
    //planTextView.layer.borderColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1].CGColor;
    planTextView.scrollEnabled=NO;
    if (phoneVersion<5){
        
    }
    else {
        planTextView.frame=CGRectMake(0,102, 320, 130);

    }

    mapButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    mapButton.frame = CGRectMake(239,84, 76,35);
    mapButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [mapButton addTarget:self action:@selector(showMap) forControlEvents:UIControlEventTouchUpInside];
    [mapButton setBackgroundImage:[UIImage imageNamed:@"map-tab.png"] forState:UIControlStateNormal]; //sets the Background image 
    
    [mapButton setImage:[UIImage imageNamed:@"map-tab.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:mapButton ];
    
    
    
    pickerSelected=0;
    myDateTimePickerView = [[UIDatePicker alloc] init];
   if (phoneVersion<5){
    myDateTimePickerView.frame = CGRectMake(320,225, 320, 162);
   }
   else{
        myDateTimePickerView.frame = CGRectMake(320,259, 320, 216);
   }
    myDateTimePickerView.datePickerMode = UIDatePickerModeDateAndTime;
    myDateTimePickerView.hidden = NO;
    myDateTimePickerView.minuteInterval = 15;
    myDateTimePickerView.date = [NSDate date];
    myDateTimePickerView.tag=2;
    
    
    [myDateTimePickerView addTarget:self
                   action:@selector(dateTimePickerChange)
         forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:myDateTimePickerView];
    
    
    
    digitsArray=[NSArray arrayWithObjects:@"--",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"30",@"60",nil];
    
    if (phoneVersion<5){
    myDigitPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(15, 225, 70, 162)];
    }
    else{
        myDigitPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(15, 259, 70, 216)];
    }
    myDigitPickerView.delegate = self;
    myDigitPickerView.showsSelectionIndicator = NO;
    [myDigitPickerView selectRow:15 inComponent:0 animated:NO];
    myDigitPickerView.backgroundColor = [UIColor whiteColor];
    myDigitPickerView.tintColor=[UIColor whiteColor];
    myDigitPickerView.tag=0;
    [self.view addSubview:myDigitPickerView];
    
    
    
    timeFrameArray=[NSArray arrayWithObjects:@"right now",@"today", @"tonight", @"tomorrow",@"minutes from now",@"hours from now",@"days from now",@"weeks from now",@"months from now", @"years from now",nil];
    
    if (phoneVersion<5){
    myTimeFramePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(80, 225, 225, 162)];
    }
    else{
        myTimeFramePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(80,259, 225, 216)];
        
    }
    myTimeFramePickerView.delegate = self;
    myTimeFramePickerView.showsSelectionIndicator = NO;
    [myTimeFramePickerView selectRow:4 inComponent:0 animated:NO];
    myTimeFramePickerView.backgroundColor=[UIColor colorWithRed:247.0f/255 green:245.0f/255 blue:240.0f/255 alpha:1];
    myTimeFramePickerView.tintColor=[UIColor colorWithRed:247.0f/255 green:245.0f/255 blue:240.0f/255 alpha:1];
    myTimeFramePickerView.tag=1;
   
    [self.view addSubview:myTimeFramePickerView];
    

    if (phoneVersion<5){
    planPickerDateMaskView = [[UIImageView alloc] initWithFrame:CGRectMake(320, 225, 320, 173)];
    planPickerDateMaskView.image = [UIImage imageNamed:@"planPickerMaskDate.png"];
    }

    else{
        planPickerDateMaskView = [[UIImageView alloc] initWithFrame:CGRectMake(320, 259, 320, 225)];
        planPickerDateMaskView.image = [UIImage imageNamed:@"planPickerMaskDateTall.png"];
    }
    //[self.view addSubview:planPickerDateMaskView];
   
    
  
    if (phoneVersion<5){
    planPickerMaskView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 225, 320, 173)];
    planPickerMaskView.image = [UIImage imageNamed:@"planPickerMask.png"];
    }
    else {
        planPickerMaskView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 259, 320, 225)];
        planPickerMaskView.image = [UIImage imageNamed:@"planPickerMaskTall.png"];
    }
    //[self.view addSubview:planPickerMaskView];
    
    [[self view] addSubview:addButton ];
    
    if(phoneVersion<5){
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 194, 95, 40)];
    }
    else{
         imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 226, 95, 40)];
    }
    imgView.image = [UIImage imageNamed:@"when.png"];
    [self.view addSubview:imgView];
    
    UISwipeGestureRecognizer *swipeGestureLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swapPickerLeft)];
    swipeGestureLeft.numberOfTouchesRequired = 1;
    swipeGestureLeft.direction = (UISwipeGestureRecognizerDirectionLeft);
    
    [self.view addGestureRecognizer:swipeGestureLeft];
    
    UISwipeGestureRecognizer *swipeGestureRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swapPickerRight)];
    swipeGestureRight.numberOfTouchesRequired = 1;
    swipeGestureRight.direction = (UISwipeGestureRecognizerDirectionRight);
    
    [self.view addGestureRecognizer:swipeGestureRight];
    
    /*UISwipeGestureRecognizer *swipeGestureUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(showMap)];
    swipeGestureUp.numberOfTouchesRequired = 1;
    swipeGestureUp.direction = (UISwipeGestureRecognizerDirectionUp);
    
    [self.view addGestureRecognizer:swipeGestureUp];*/
    
    NSManagedObjectContext *context = [self managedObjectContext];
    if (!context) {
        // Handle the error.
    }
    // Pass the managed object context to the view controller.
    self.managedObjectContext = context;
    
    planLatitude=0;
    planLongitude=0;

    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
    }
    else {
         photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
        
    }


    
    photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    photoButton.frame = CGRectMake(0, 0, 41, 41);
    [photoButton addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
   
  // photoButton.layer.borderWidth=1;
  // photoButton.layer.borderColor=[UIColor lightGrayColor].CGColor;
    
    UIBarButtonItem *aBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:photoButton];
    self.navigationController.topViewController.navigationItem.leftBarButtonItem = aBarButtonItem2;
    
    thereButtonPressed=0;
    thereButton = [UIButton buttonWithType:UIButtonTypeSystem]; //sets the type of UIButton
    
    if (phoneVersion<5){
    thereButton.frame = CGRectMake(200 ,194, 100,39);
    }
    else {
        thereButton.frame = CGRectMake(200 ,226, 100,39);
    }
    thereButton.backgroundColor = [UIColor clearColor]; //sets the background color
    thereButton.tintColor =[UIColor colorWithRed:171.0f/255.0f green:131.0f/255.0f blue:89.0f/255.0f alpha:1.0f];
    [thereButton addTarget:self action:@selector(swapPlanType) forControlEvents:UIControlEventTouchUpInside];
    [thereButton setTitle:@"I'm There Now" forState:UIControlStateNormal]; //sets the Background image
    [[self view] addSubview:thereButton ];
    
    keyBoardVisible=0;
    
    tutorialPop=[[UIView alloc] initWithFrame:CGRectMake(160, 221, 1, 1)];
    [self.view addSubview:tutorialPop];
    PopTipViewFirstTime = [[CMPopTipView alloc] initWithMessage:@"WELCOME TO WHEN.ME! \n Let's get started, shall we? \n Tap the text area above to enter a plan that completes \n the phrase 'I am going to...'"];
    PopTipViewFirstTime.delegate = self;
    PopTipViewFirstTime.backgroundColor = [UIColor whiteColor];
    PopTipViewFirstTime.textColor = [UIColor darkTextColor];
    PopTipViewFirstTime.animation = CMPopTipAnimationPop;
    firstPopSeen=0;
    //[PopTipView2 presentPointingAtBarButtonItem:self.navigationController.topViewController.navigationItem.rightBarButtonItem animated:YES];
    
    
    
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"tutorialSeen"]){
    NSString *myExamplePath = [[NSBundle mainBundle] pathForResource:@"33369__herbertboland__mouthpop" ofType:@"wav"];
    
    playSound =[[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:myExamplePath] error:NULL];
    
    playSound.delegate = self;
    [playSound prepareToPlay];
    }
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"new_plan"];
       

    
    
   
}

-(void) swapPlanType{
   
    
    if (thereButtonPressed==0){
        if (segControl.selectedSegmentIndex == 1) {
            [self swapPickerRight];
            segControl.selectedSegmentIndex = 0;
        }
        [myDigitPickerView selectRow:0 inComponent:0 animated:YES];
        [myTimeFramePickerView selectRow:0 inComponent:0 animated:YES];
        
        //[UIView beginAnimations:nil context:nil];
        //[UIView setAnimationDuration:0.3];
        //CGAffineTransform transform = CGAffineTransformMakeTranslation(-300, 0);
        //iamgoingto.transform = transform;
        
        [UIView animateWithDuration:0.3
                              delay:0.0
                            options: UIViewAnimationCurveEaseOut
                         animations:^{
                            iamgoingto.frame = CGRectMake(-300, 66, 215, 55);
                         } 
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];
        [UIView animateWithDuration:0.3
                              delay:0.3
                            options: UIViewAnimationCurveEaseOut
                         animations:^{
                             iamat.frame = CGRectMake(13, 66, 215, 55);
                         } 
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];

        
        //[UIView commitAnimations];

        
        
        thereButtonPressed=1;
      
    }
    
    else {
        
        //[UIView beginAnimations:nil context:nil];
        //[UIView setAnimationDuration:0.3];
        //CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
        //iamgoingto.transform = transform;
        
        //[UIView commitAnimations];
        [UIView animateWithDuration:0.3
                              delay:0.0
                            options: UIViewAnimationCurveEaseOut
                         animations:^{
                             iamat.frame = CGRectMake(-300, 66, 215, 55);
                         } 
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];

        [UIView animateWithDuration:0.3
                              delay:0.3
                            options: UIViewAnimationCurveEaseOut
                         animations:^{
                             iamgoingto.frame = CGRectMake(13,66, 215, 55);
                         } 
                         completion:^(BOOL finished){
                             NSLog(@"Done!");
                         }];
        
        thereButtonPressed=0;
       
    }
}

- (void)viewWillAppear:(BOOL)animated{
  
    //[self.navigationController setNavigationBarHidden:NO animated:NO];
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    self.navigationController.navigationBar.barTintColor=[UIColor blackColor];
    
    popTipSeen=0;
    popTip2Seen=0;
    keyBoardVisible=0;
    
    thereButtonPressed=1;
    [self swapPlanType];
    [PopTipView dismissAnimated:YES];
    [PopTipView2 dismissAnimated:YES];
    [PopTipViewFirstTime dismissAnimated:YES];
  
  
    /*if (!isLoggedIn){
        buttonImage2 = [UIImage imageNamed:@"mebutton-gray.png"];}
    else {
        buttonImage2 = [UIImage imageNamed:@"mebuttonOn-gray.png"];
    }
    
    
    aButton2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [aButton2 setImage:buttonImage2 forState:UIControlStateNormal];
    aButton2.frame = CGRectMake(0.0, 0.0, buttonImage2.size.width, buttonImage2.size.height);
    [aButton2 addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
     UIBarButtonItem *aBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:aButton2];
    self.navigationController.topViewController.navigationItem.leftBarButtonItem = aBarButtonItem2;*/
    
 
    
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
        //[myPicture setImage:img]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
    }

    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    [self.view addSubview:toolbar];
    //planLatitude=nil;
    //planLongitude=nil;
    //planTextView.text=@"";
    
    if(isLoggedIn==0 && ![[NSUserDefaults standardUserDefaults] boolForKey:@"tutorialSeen"] && firstPopSeen==0){
    [self performSelector:@selector(popTutorial) withObject:nil afterDelay:2.5];
        firstPopSeen=1;
    }
    
}

-(void)popTutorial{
    [PopTipViewFirstTime presentPointingAtView:tutorialPop inView:self.view animated:YES];
    [playSound play];
  
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)segmentSwitch{
    if (segControl.selectedSegmentIndex == 0) {
        //planTextView.textColor=[UIColor lightGrayColor];
        //planTextView.text=@"...enter a plan or use";
        //locationGray.hidden=NO;
        [self swapPickerRight];
    } else {
        //planTextView.textColor=[UIColor lightGrayColor];
        //planTextView.text=@"...enter a plan or use";
        //locationGray.hidden=NO;
        [self swapPickerLeft];
    }
}

- (void) addPlan
{
    [self.hud hide:YES];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"tutorialSeen"];
     [[NSUserDefaults standardUserDefaults] synchronize];
    //create a dictionary object with all of the collected data
    BOOL error=NO;
    NSDate *myPlanDate;
    NSString *dateString;
    NSString *digitPicked;
    NSString *timeFramePicked;
    if (pickerSelected==1){ //we have a concrete date
        
        NSTimeZone *timeZone = [NSTimeZone localTimeZone];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setTimeZone:timeZone];	
        [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];

        myPlanDate=self.myDateTimePickerView.date;
        dateString = [dateFormat stringFromDate:myPlanDate];  
        
        
        //convert date to timeframe
        
        NSDate *todayDate = [NSDate date];
        NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
        
        NSDate *today=[dateFormat dateFromString:todayDateString];
        NSDate *strDate=[dateFormat dateFromString:dateString];
        
        
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                                   fromDate:today
                                                     toDate:strDate
                                                    options:0];
        
        
        NSLog(@"%d days %d hours %d minutes %d seconds",components.day,components.hour,components.minute,components.second);

        
        if (components.day>0) {
        digitPicked=[NSString stringWithFormat:@"%d", components.day];
        timeFramePicked=@"days from now";
        }
        else if (components.hour>0){
            digitPicked=[NSString stringWithFormat:@"%d", components.hour];
            timeFramePicked=@"hours from now";
        }
        
        else if (components.minute>0){
            digitPicked=[NSString stringWithFormat:@"%d", components.minute];
            timeFramePicked=@"minutes from now";
        }
        
        else{
            digitPicked=@"--";
            timeFramePicked=@"right now";
        }
        
    }
    else { //need to figure out date from entered data
        
        NSInteger row,row2;
        row = [myDigitPickerView selectedRowInComponent:0];
        row2 = [myTimeFramePickerView selectedRowInComponent:0];
        if (row==0 && (row2>3)){ 
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops!" 
                                                                message:@"You must select a valid timeframe. Did you mean 'Right Now'?" 
                                                               delegate:self 
                                                      cancelButtonTitle:@"Try Again" 
                                                      otherButtonTitles:nil];
            [alertView show];
            error=YES;
        }
        
        else { //time frame is valid lets convert it to a date
            
            digitPicked=[digitsArray objectAtIndex:row];
            timeFramePicked=[timeFrameArray objectAtIndex:row2];
            
            NSTimeZone *timeZone = [NSTimeZone localTimeZone];
            NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
            [dateFormat setTimeZone:timeZone];	
            [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
            
            int pickednumber = [[digitsArray objectAtIndex:row] intValue];
            int secondsToAdd = 0;    
            if(row2==0){ //right now
                myPlanDate=[NSDate date]; 
            }
            else if (row2==1){ //today
                
                NSDate *today = [NSDate date];
                NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateComponents *components = [gregorian components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) 
                                                            fromDate:today];
                [components setMinute:00];
                [components setHour:17];
                
                NSDate * endOfDay = [gregorian dateFromComponents:components];
                
                secondsToAdd=[endOfDay timeIntervalSinceNow];
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
             
            }
            
            else if (row2==2){ //tonight
                
                NSDate *today = [NSDate date];
                NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateComponents *components = [gregorian components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) 
                                                            fromDate:today];
                [components setMinute:59];
                [components setHour:23];
                
                NSDate * endOfDay = [gregorian dateFromComponents:components];
              
                secondsToAdd=[endOfDay timeIntervalSinceNow];
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
               
              
            }
            
            else if (row2==3){ //tomorrow
             secondsToAdd=60*60*24;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
       
            }

            else if (row2==4){ //minutes from now
                secondsToAdd=pickednumber*60;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
            else if (row2==5){ //hours from now
                secondsToAdd=pickednumber*60*60;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
            else if (row2==6){ //days from now
                secondsToAdd=pickednumber*60*60*24;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
            
            else if (row2==7){ //weeks from now
                secondsToAdd=pickednumber*60*60*24*7;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
            else if (row2==8){ //months from now
                secondsToAdd=pickednumber*60*60*24*30;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
            
            else if (row2==9){ //years from now
                secondsToAdd=pickednumber*60*60*24*365;
                myPlanDate=[NSDate date];
                myPlanDate=[myPlanDate dateByAddingTimeInterval: secondsToAdd];
            }
               
                dateString = [dateFormat stringFromDate:myPlanDate]; 
        
        }
       
       
        
    }
    
    if ([planTextView.text isEqualToString:@""] || [planTextView.text isEqualToString:@"...enter a personal goal"] || [planTextView.text isEqualToString:@"...enter a plan or find place"] || [planTextView.text isEqualToString:@"...plant a vegetable garden"]){
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops!" 
                                                                message:@"You must enter a plan. Try tapping the text area." 
                                                               delegate:self 
                                                      cancelButtonTitle:@"Try Again" 
                                                      otherButtonTitles:nil];
            [alertView show];
        error=YES;
    }
    
    if ([planTextView.text rangeOfString:@"i am going to" options:NSCaseInsensitiveSearch].location == NSNotFound || [planTextView.text rangeOfString:@"i am at" options:NSCaseInsensitiveSearch].location == NSNotFound){

    }
    else{
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops!" 
                                                            message:@"You should not include the words 'I am going to' in your plan. Plan text should be a short phrase or place name that completes 'I am going to...' such as 'plant a vegetable garden'"
                                                           delegate:self 
                                                  cancelButtonTitle:@"Ok, got it!" 
                                                  otherButtonTitles:nil];
        [alertView show];
        error=YES;
    }
        
    
    if (error==NO){
  
        //store the plan locally using core data
        
        Plan *plan = (Plan *)[NSEntityDescription insertNewObjectForEntityForName:@"Plan" inManagedObjectContext:managedObjectContext];
        
        [plan setPlanID:nil];
        [plan setUniqueID:nil];
        [plan setPlanText:planTextView.text];
        [plan setPlanDigit:digitPicked];
        [plan setPlanTimeFrame:timeFramePicked];
        [plan setPlanDate:myPlanDate];
        [plan setLatitude:planLatitude];
        [plan setLongitude:planLongitude];
        [plan setCreateDate:[NSDate date]];
        [plan setActive:[NSNumber numberWithInteger: 1]];
        [plan setHasPlanPicture:[NSNumber numberWithInteger: 0]];
        [plan setHasCompletePicture:[NSNumber numberWithInteger: 0]];
        [plan setLocationOverride:[NSNumber numberWithInteger: 0]];
        
        NSError *error = nil;
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }
        
        NSManagedObjectID *localID = [plan objectID];
        NSURL *uri = [localID URIRepresentation];
        NSData *uriData = [NSKeyedArchiver archivedDataWithRootObject:uri];
        
        NSString *hasPlanPicture=@"0";
        NSString *hasCompletePicture=@"0";
        NSString *locationOverride=@"0";
        
        NSString *planPrefix;
        if (thereButtonPressed==1){
            planPrefix=@"I am at";
        }
        else{
            planPrefix=@"I am going to";
        }
        
        NSMutableDictionary *myPlan = [[NSMutableDictionary alloc] initWithObjectsAndKeys:planPrefix,@"planPrefix", dateString, @"planDate", planTextView.text, @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",uriData,@"localID", hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",locationOverride,@"locationOverride", planLatitude,@"latitude",planLongitude,@"longitude", nil];
 
   
        
        //CLLocationCoordinate2D coordinate = [location coordinate];
       // [event setLatitude:[NSNumber numberWithDouble:coordinate.latitude]];
        //[event setLongitude:[NSNumber numberWithDouble:coordinate.longitude]];
        //[event setCreationDate:[NSDate date]];
        
        //set the local alert
        NSTimeZone *timeZone = [NSTimeZone localTimeZone];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setTimeZone:timeZone];	
        [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
        
        /*NSString *customTime = [[NSUserDefaults standardUserDefaults]
                                stringForKey:@"customTime"];
        if (!customTime){
            customTime=@" 9:00:00";
        }*/
        NSString *myFireDateString=dateString;
        NSLog(@"%@",myFireDateString);
        NSDate *myFireDate = [dateFormat dateFromString:myFireDateString];

        
        UILocalNotification *scheduledAlert;
        scheduledAlert = [[UILocalNotification alloc] init];
        scheduledAlert.applicationIconBadgeNumber=-1;
        scheduledAlert.fireDate = myFireDate;
        scheduledAlert.timeZone = [NSTimeZone localTimeZone];
        scheduledAlert.userInfo = myPlan;
        scheduledAlert.soundName= UILocalNotificationDefaultSoundName;
        scheduledAlert.alertBody = [NSString stringWithFormat:@"Reminder: \"%@\" ", planTextView.text];
        [[UIApplication sharedApplication] scheduleLocalNotification:scheduledAlert];
    
      
        SharePlanViewController *sharePlanView=[[SharePlanViewController alloc] initWithData:myPlan nibName:@"SharePlanViewController" bundle:nil];
        
        sharePlanView.managedObjectContext = self.managedObjectContext;
        
        
    
    [self.navigationController pushViewController:sharePlanView animated:YES];
    }
    
    
}

-(void)savePlan{
    if (keyBoardVisible==0){
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Saving Plan...";
    [self performSelector:@selector(addPlan) withObject:nil afterDelay:1.0];
    
    }
    else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops!" 
                                                            message:@"You must click Done on the keyboard and choose a timeframe before saving ." 
                                                           delegate:self 
                                                  cancelButtonTitle:@"Try Again" 
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}
- (void)didSelectPlace:(NSNotification*)myPlace{
   [self.navigationController setNavigationBarHidden:NO animated:YES];
    NSDictionary *userInfo = [myPlace userInfo];
    NSString *myPlaceName = [userInfo valueForKey:@"myTitle"];
    planLatitude=[userInfo valueForKey:@"planLatitude"];
    planLongitude=[userInfo valueForKey:@"planLongitude"];
    NSLog(@"setting longitude to %@",planLongitude);
    planTextView.text=myPlaceName;


}

- (void) showMap
{
    
    aButton.enabled=NO;

    
    placesView = [[PlacesTableViewController alloc]init];
    placesView.title = @"Find Places";
    [self.navigationController pushViewController:placesView animated:YES];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didSelectPlace:) name:@"DidSelectPlace" object:nil];

}

- (void) showSignUp{
  
}

- (void) showUserPage{
    NSLog(@"I am in here");
    if (!isLoggedIn){
        SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"SignUp", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
    else{
    UserTableViewController* signupVC = [[UserTableViewController alloc]initWithNibName:@"UserTableViewController" bundle:nil];
	signupVC.title = NSLocalizedString(@"About me", @"");
    [self.navigationController pushViewController:signupVC  animated:YES];
    }
}

- (void) dismissPlaces
{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    [UIView animateWithDuration:0.3
                     animations:^{navController.view.frame = CGRectMake(0, 420, 320, 420);}
                     completion:^(BOOL finished){ [navController.view removeFromSuperview]; }];
}

- (void) dateTimePickerChange
{
    [PopTipView2 dismissAnimated:YES];
    NSLog(@"dateTimePickerChange");
}

- (void) swapPickerLeft
{
    NSLog(@"swapping picker");
    
    if (pickerSelected==0){
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform = CGAffineTransformMakeTranslation(-300, 0);
	myTimeFramePickerView.transform = transform;

	[UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform2 = CGAffineTransformMakeTranslation(-380, 0);
	myDigitPickerView.transform = transform2;
	[UIView commitAnimations];
        
     
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform3 = CGAffineTransformMakeTranslation(-320, 0);
	myDateTimePickerView.transform = transform3;
    planPickerDateMaskView.transform = transform3;
        planPickerMaskView.transform = transform3;
        //planArrowBack.transform = transform3;
	[UIView commitAnimations];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.3];
        //planArrow.transform = transform4;
        [UIView commitAnimations];
    pickerSelected=1;
    }
        
}

-(void) swapPickerRight
{
    if(pickerSelected==1){
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
    myTimeFramePickerView.transform = transform;
    
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform2 = CGAffineTransformMakeTranslation(0, 0);
    myDigitPickerView.transform = transform2;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform3 = CGAffineTransformMakeTranslation(0, 0);
    myDateTimePickerView.transform = transform3;
    planPickerDateMaskView.transform = transform3;
    planPickerMaskView.transform = transform3;
    [UIView commitAnimations];
    pickerSelected=0;
    }
}

#pragma Uipicker delegate methods
- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component {
     [PopTipView2 dismissAnimated:YES];
    if (pickerView==myDigitPickerView){
        NSLog(@"%@",[digitsArray objectAtIndex:row]);
        
        int pickednumber = [[digitsArray objectAtIndex:row] intValue];
        
        if (pickednumber>1){
            timeFrameArray=[NSArray arrayWithObjects:@"right now",@"today", @"tonight", @"tomorrow",@"minutes from now",@"hours from now",@"days from now",@"weeks from now",@"months from now", @"years from now",nil];
            [myTimeFramePickerView reloadAllComponents];

        }
        else{
            timeFrameArray=[NSArray arrayWithObjects:@"right now",@"today", @"tonight", @"tomorrow",@"minute from now",@"hour from now",@"day from now",@"week from now",@"month from now", @"year from now",nil];
            [myTimeFramePickerView reloadAllComponents];
        }
        
        if (row==0){
            [myTimeFramePickerView selectRow:0 inComponent:0 animated:YES];
        }
       
        
    }
    
    if(pickerView==myTimeFramePickerView){
        if (row==0 || row==1 || row==2 || row==3){
            [myDigitPickerView selectRow:0 inComponent:0 animated:YES];
        }
    }
}

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return ( pickerView == myDigitPickerView ? 27 : 10 );
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return ( pickerView == myDigitPickerView ? 1 : 1 );
}

// tell the picker the title for a given component
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    NSArray *values = ( pickerView == myDigitPickerView ? digitsArray : timeFrameArray );
    return [values objectAtIndex: row];
   
}

// tell the picker the width of each row for a given component
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return ( pickerView == myDigitPickerView ? 50 : 200 );
    
  
}



#pragma textview delegate methods

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range  replacementText:(NSString *)text
{
    if (range.length==0) {
		if ([text isEqualToString:@"\n"]) {
			keyBoardVisible=0;
            [textView resignFirstResponder];
            
            [PopTipView dismissAnimated:YES];
            if (popTip2Seen==0 && ![textView.text isEqualToString:@""] && ![[NSUserDefaults standardUserDefaults] boolForKey:@"tutorialSeen"]){
            PopTipView2 = [[CMPopTipView alloc] initWithMessage:@"Nice! When are you doing it?"];
            PopTipView2.delegate = self;
            PopTipView2.backgroundColor = [UIColor whiteColor];
            PopTipView2.textColor = [UIColor darkTextColor];
            PopTipView2.animation = CMPopTipAnimationPop;
     
            [PopTipView2 presentPointingAtView:imgView inView:self.view animated:YES];
                [playSound play];
                popTip2Seen=1;
            }
			return NO;
		}
	}
	
    return YES;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component
reusingView:(UIView *)view {
    UILabel *pickerLabel = (UILabel *)view;
    
    if (pickerView.tag==0){
        
        
        if (pickerLabel == nil) {
            //label size
            CGRect frame = CGRectMake(0.0, 0.0, 70, 50);
            
            pickerLabel = [[UILabel alloc] initWithFrame:frame] ;
            
            [pickerLabel setTextAlignment:NSTextAlignmentCenter];
            
            [pickerLabel setBackgroundColor:[UIColor clearColor]];
            pickerLabel.textColor=[UIColor darkGrayColor];
             [pickerLabel setFont:[UIFont systemFontOfSize:20.0f]];
            
        }
        //picker view array is the datasource
        [pickerLabel setText:[digitsArray objectAtIndex:row]];
        
        
    }

    
    if (pickerView.tag==1){
    
    
    if (pickerLabel == nil) {
        //label size
        CGRect frame = CGRectMake(0.0, 0.0, 250, 50);
        
        pickerLabel = [[UILabel alloc] initWithFrame:frame] ;
        
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        pickerLabel.textColor=[UIColor brownColor];
        //here you can play with fonts
        [pickerLabel setFont:[UIFont systemFontOfSize:20.0f]];
        
    }
    //picker view array is the datasource
    [pickerLabel setText:[timeFrameArray objectAtIndex:row]];
    
   
    }
     return pickerLabel;
    
}


- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    if ([planTextView.text isEqualToString:@""] || [planTextView.text isEqualToString:@"...enter a personal goal"] || [planTextView.text isEqualToString:@"...enter a plan or find place"] || [planTextView.text isEqualToString:@"...plant a vegetable garden"]){
        textView.text = @"";
        textView.textColor=[UIColor brownColor];
        //locationGray.hidden=YES;
    }
    if(![textView.text isEqualToString:@""]){
        //textView.text = @"";
        textView.textColor=[UIColor brownColor];
        //locationGray.hidden=YES;
    }
    keyBoardVisible=1;
     [PopTipViewFirstTime dismissAnimated:YES];
    if (popTipSeen==0 && [textView.text isEqualToString:@""] && ![[NSUserDefaults standardUserDefaults] boolForKey:@"tutorialSeen"]){
    PopTipView = [[CMPopTipView alloc] initWithMessage:@"TIP! Don't forget to pick 'when' below before saving your plan!"];
    PopTipView.delegate = self;
    PopTipView.backgroundColor = [UIColor whiteColor];
    PopTipView.textColor = [UIColor darkTextColor];
    PopTipView.animation = CMPopTipAnimationPop;
    [PopTipView presentPointingAtView:imgView inView:self.view animated:YES];
        [playSound play];
    }
   
    
  
  
    

}

- (void)textViewDidChange:(UITextView *)textView {
    if ([textView.text isEqualToString:@""]){
        NSLog(@"reset the location");
        planLatitude=nil;
        planLongitude=nil;
    }
    
    if (![textView.text isEqualToString:@""]){
    [PopTipView dismissAnimated:YES];
    popTipSeen=1;
    }
    
   
}
- (void)popTipViewWasDismissedByUser:(CMPopTipView *)popTipView {
    // User can tap CMPopTipView to dismiss it
   
}


@end
