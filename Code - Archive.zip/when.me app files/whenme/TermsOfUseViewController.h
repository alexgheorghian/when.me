//
//  TermsOfUseViewController.h
//  whenme
//
//  Created by Eric English on 5/31/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsOfUseViewController : UIViewController

@end
