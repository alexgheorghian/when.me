//
//  TokenCountViewController.m
//  whenme
//
//  Created by Eric English on 6/13/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "TokenCountViewController.h"
#import "LeaderBoardViewController.h"
#import "GAI.h"
#import <QuartzCore/QuartzCore.h>

@interface TokenCountViewController ()



@end

@implementation TokenCountViewController

@synthesize tokensEarned;
@synthesize myTokensData;
@synthesize responseData;
@synthesize playSound;

- (id)initWithNibName:(NSString *)nibNameOrNil andData:(NSMutableDictionary*)myData bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        myTokensData=myData;
        //NSLog(@"Received Data: %@",myTokensData);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }
    
    UIImageView *topBanner;
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background-tan.png"]];
    topBanner = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"niceShare.png"]];
    topBanner.frame= CGRectMake(0.0, 64, 320, 49);
    [self.view addSubview:topBanner];
    
    NSString *myString = [[myTokensData objectForKey:@"tokensEarned"] stringValue];
    tokensEarned.layer.cornerRadius = 10;
    //tokensEarned.contentInset = UIEdgeInsetsMake(-8,-8,-8,-8);
    tokensEarned.textColor=[[UIColor alloc] initWithRed:152.0 / 255 green:123.0 / 255 blue:94.0 / 255 alpha:1.0];
    tokensEarned.layer.borderWidth=1;
    tokensEarned.layer.borderColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1].CGColor;
    tokensEarned.text=myString;
    
    UIImageView *youEarned;
    youEarned = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"youEarned.png"]];
    youEarned.frame= CGRectMake(10.0, 114.0, 140, 49);
    [self.view addSubview:youEarned];
    
    UIImageView *tokenBanner;
  
    tokenBanner = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"meTokens.png"]];
    
    if (phoneVersion<5)
    {
        tokenBanner.frame= CGRectMake(0.0, 293, 320, 36);
        
    }
    else {
        tokenBanner.frame= CGRectMake(0.0, 293+64, 320, 36);
    }
    [self.view addSubview:tokenBanner];
    
    UIImageView *token;
    UIImageView *token2;
    UIImageView *token3;
    UILabel *label1;
    UILabel *label2;
    UILabel *label3;
    UILabel *label12;
    UILabel *label22;
    UILabel *label32;
    
    UIView *rectangle;
    
    if (phoneVersion<5)
    {
    rectangle =[[UIView alloc] initWithFrame:CGRectMake(20, 266+64, 280, 80)];
    rectangle.backgroundColor=[UIColor whiteColor];
    rectangle.layer.cornerRadius = 10;
    [self.view addSubview:rectangle];
    
    label1 = [[UILabel alloc] initWithFrame:CGRectMake(70, 269+64, 300, 24)];
    label2 = [[UILabel alloc] initWithFrame:CGRectMake(70, 294+64, 300, 24)];
    label3 = [[UILabel alloc] initWithFrame:CGRectMake(70, 319+64, 300, 24)];
    
    label12 = [[UILabel alloc] initWithFrame:CGRectMake(90, 269+64, 300, 24)];
    label22 = [[UILabel alloc] initWithFrame:CGRectMake(90, 294+64, 300, 24)];
    label32 = [[UILabel alloc] initWithFrame:CGRectMake(90, 318+64, 300, 24)];
    }
    else {
        
        rectangle =[[UIView alloc] initWithFrame:CGRectMake(20, 266+128, 280, 80)];
        rectangle.backgroundColor=[UIColor whiteColor];
        rectangle.layer.cornerRadius = 10;
        [self.view addSubview:rectangle];
        
        label1 = [[UILabel alloc] initWithFrame:CGRectMake(70, 269+128, 300, 24)];
        label2 = [[UILabel alloc] initWithFrame:CGRectMake(70, 294+128, 300, 24)];
        label3 = [[UILabel alloc] initWithFrame:CGRectMake(70, 319+128, 300, 24)];
        
        label12 = [[UILabel alloc] initWithFrame:CGRectMake(90, 269+128, 300, 24)];
        label22 = [[UILabel alloc] initWithFrame:CGRectMake(90, 294+128, 300, 24)];
        label32 = [[UILabel alloc] initWithFrame:CGRectMake(90, 318+128, 300, 24)];
        
    }
    
    if ([[myTokensData objectForKey:@"tokenForWhenMe"] intValue]==1){
    label1.text=@"+2";
    label12.text=@" for sharing on when.me!";
        token = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"goldToken.png"]];
    }
    else {
      label1.text=@"+0";  
       label12.text=@" not shared on when.me";
        token = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"grayToken.png"]];
    }
    
    if ([[myTokensData objectForKey:@"tokenForFaceBook"] intValue]==1){
    label2.text=@"+1";
    label22.text=@" for sharing on facebook!";
        token2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"goldToken.png"]];
    }
    else {
         label2.text=@"+0";
         label22.text=@" not shared on facebook.";
        token2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"grayToken.png"]];
    }
    
    if ([[myTokensData objectForKey:@"tokenForTwitter"] intValue]==1){
    label3.text=@"+1";
    label32.text=@" for sharing on twitter!";
        token3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"goldToken.png"]];
    }
    else {
        label3.text=@"+0";
        label32.text=@" not shared on twitter.";
        token3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"grayToken.png"]];
    }
    
    label1.backgroundColor=[UIColor clearColor];
    label2.backgroundColor=[UIColor clearColor];
    label3.backgroundColor=[UIColor clearColor];
    
    label1.textColor = [UIColor darkGrayColor];
    label1.font = [UIFont systemFontOfSize:16];
    
    label2.textColor = [UIColor darkGrayColor];
    label2.font = [UIFont systemFontOfSize:16];
    
    label3.textColor = [UIColor darkGrayColor];
    label3.font = [UIFont systemFontOfSize:16];
    
  

    label12.backgroundColor=[UIColor clearColor];
    label22.backgroundColor=[UIColor clearColor];
    label32.backgroundColor=[UIColor clearColor];
    
    label12.textColor = [UIColor lightGrayColor];
    label12.font = [UIFont systemFontOfSize:16];
    
    label22.textColor = [UIColor lightGrayColor];
    label22.font = [UIFont systemFontOfSize:16];
    
    label32.textColor = [UIColor lightGrayColor];
    label32.font = [UIFont systemFontOfSize:16];


    //label1.textcolor
    
    [self.view addSubview:label1];
    [self.view addSubview:label2];
    [self.view addSubview:label3];
    
    [self.view addSubview:label12];
    [self.view addSubview:label22];
    [self.view addSubview:label32];

    
    if (phoneVersion<5){
    token.frame= CGRectMake(45, 270+64, 22, 24);
    [self.view addSubview:token];
    token2.frame= CGRectMake(45, 295+64, 22, 24);
    [self.view addSubview:token2];
    token3.frame= CGRectMake(45, 320+64, 22, 24);
    [self.view addSubview:token3];
    
    UIImageView *myTokens;
    
    myTokens = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"myTokens.png"]];
    myTokens.frame= CGRectMake(190, 342+64, 62, 25);
    [self.view addSubview:myTokens];
    }
    else {
        token.frame= CGRectMake(45, 270+128, 22, 24);
        [self.view addSubview:token];
        token2.frame= CGRectMake(45, 295+128, 22, 24);
        [self.view addSubview:token2];
        token3.frame= CGRectMake(45, 320+128, 22, 24);
        [self.view addSubview:token3];
        
        UIImageView *myTokens;
        
        myTokens = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"myTokens.png"]];
        myTokens.frame= CGRectMake(190, 342+128, 62, 25);
        [self.view addSubview:myTokens];
     
    }
    
    
    //update users total on when.me
    
    NSNumber *totalTokens=[[NSUserDefaults standardUserDefaults] valueForKey:@"totalTokens"];
    if (totalTokens==nil){
       NSLog(@"I am in the nil value");
        NSNumber *zero=[[NSNumber alloc] initWithInt:0];
        [[NSUserDefaults standardUserDefaults] setValue:zero forKey:@"totalTokens"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        totalTokens=[[NSUserDefaults standardUserDefaults] valueForKey:@"totalTokens"];
    }
    
    int tokensToAdd=[[myTokensData objectForKey:@"tokensEarned"] intValue];
    int myTotalTokens=[totalTokens intValue];
    int myTotalTokensAdded=myTotalTokens+tokensToAdd;
    
    NSLog(@"tokenstoadd=%d myCurrentTotalTokens=%d Total tokens=%d",tokensToAdd,myTotalTokens,myTotalTokensAdded);
    
    
    NSNumber *finalTokens=[[NSNumber alloc] initWithInt:myTotalTokensAdded];
    NSString *finalTokensString=[[NSString alloc] initWithFormat:@"%d",myTotalTokensAdded];
    
    [[NSUserDefaults standardUserDefaults] setValue:finalTokens forKey:@"totalTokens"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
    NSString *passwordToSend=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
    
    responseData = [NSMutableData data];
    const char *bytes = [[NSString stringWithFormat:@"userID=%@&password=%@&tokens=%@&secretKey=387213549",userID,passwordToSend,finalTokensString] UTF8String];
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/updateTokens.aspx"];
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
    [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    
    UILabel *tokens;
    if (phoneVersion<5){
    tokens = [[UILabel alloc] initWithFrame:CGRectMake(255, 341+64, 300, 24)];
    }
    else {
        tokens = [[UILabel alloc] initWithFrame:CGRectMake(255, 341+128, 300, 24)];
    }
    tokens.textColor = [UIColor darkGrayColor];
    tokens.backgroundColor= [UIColor clearColor];
    tokens.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(16.0)];
    tokens.text=[finalTokens stringValue];
    [self.view addSubview:tokens];
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:@"Top Users" style:UIBarButtonItemStylePlain target:self action:@selector(showLeaderBoard)];
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
    
    
    NSString *myExamplePath = [[NSBundle mainBundle] pathForResource:@"magic-chime-02" ofType:@"mp3"];
    
    playSound =[[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:myExamplePath] error:NULL];
    
    playSound.delegate = self;
    [playSound prepareToPlay];

  
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"token_count"];
    
    
    
                     
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    NSLog(@"%@",error);
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"Your tokens were not saved. It's not your fault - when.me may be over capacity. They should update correctly when you earn more tokens." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	
    NSLog(@"%@",s);
      [playSound play];
    
    
	
	
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)showLeaderBoard
{
    LeaderBoardViewController* leaderVC = [[LeaderBoardViewController alloc]initWithNibName:@"LeaderBoardViewController" bundle:nil];
    leaderVC.title = NSLocalizedString(@"Leaderboard", @"");
    [self.navigationController pushViewController:leaderVC  animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
