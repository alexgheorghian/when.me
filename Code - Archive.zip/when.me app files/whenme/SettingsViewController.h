//
//  SettingsViewController.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import <MessageUI/MFMailComposeViewController.h>

@interface SettingsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,UIAlertViewDelegate,FBDialogDelegate, FBSessionDelegate, FBRequestDelegate,MFMailComposeViewControllerDelegate>{

IBOutlet UITableView *tblSimpleTable;
NSArray *arrShareKit;
NSArray *arrPrivacy;
NSArray *arrAccount;
NSArray *arrGeneral;
BOOL facebookConnected;
BOOL twitterConnected;
}

@property (strong, nonatomic) UIImage *photoButtonImage;
@property (strong, nonatomic) UIButton *photoButton;
@property (nonatomic) BOOL isLoggedIn;

@end
