//
//  UserViewController.h
//  whenme
//
//  Created by Eric English on 6/25/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface UserViewController : UIViewController<UITableViewDelegate>
{
    NSMutableData *responseData;
    
    MBProgressHUD *_hud;
    NSMutableArray *plansArray;
    NSManagedObjectContext *managedObjectContext;
}

@property (strong, nonatomic) NSString *myUserName;
@property (strong, nonatomic) NSString *myPhotoURL;
@property (strong, nonatomic) NSString *myUserID;

@property (strong, nonatomic) UISwitch *friendSwitch;

@property (nonatomic) BOOL isLoggedIn;

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;

@property (retain) MBProgressHUD *hud;

@property (strong, nonatomic) IBOutlet UITableView *tv;
@property (nonatomic, retain) NSMutableArray *plansArray;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

- (id)initWithID:(NSString *)userID andUsername:(NSString *)userName andPhoto:(NSString *)photoURL;
@end
