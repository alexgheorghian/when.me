//
//  Plan.m
//  whenme
//
//  Created by Eric English on 4/27/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "Plan.h"


@implementation Plan

@dynamic planID;
@dynamic planText;
@dynamic planDigit;
@dynamic uniqueID;
@dynamic planTimeFrame;
@dynamic planDate;
@dynamic planCompleteDate;
@dynamic createDate;
@dynamic latitude;
@dynamic longitude;
@dynamic active;
@dynamic hasPlanPicture;
@dynamic hasCompletePicture;
@dynamic locationOverride;

@end
