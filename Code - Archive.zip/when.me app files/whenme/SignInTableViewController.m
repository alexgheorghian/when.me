//
//  SignupTableViewController.m
//  ExSignup
//
//  Created by Nada Jaksic on 7/13/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SignInTableViewController.h"
#import "KeychainWrapper.h"
#import "whenMeConstants.h"
#import "GAI.h"

@implementation SignInTableViewController
@synthesize cellUsername, cellPassword;
@synthesize txtUsername, txtPassword;
@synthesize responseData;
@synthesize hud = _hud;
@synthesize segControl;
@synthesize toolbar;

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad 
{
    [super viewDidLoad];
   
  
    self.title= @"Login";
    self.view.backgroundColor=[UIColor whiteColor];

    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
	UIBarButtonItem* btnLogin = [[UIBarButtonItem alloc]initWithTitle:NSLocalizedString(@"Login",@"") style:UIBarButtonItemStylePlain target:self action:@selector(login)];
    btnLogin.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
	[[self navigationItem] setRightBarButtonItem:btnLogin];
    
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(10, 150, 300, 200)] autorelease];
    label.text = @"Optional sharing of plans and places on when.me requires a free account. Once signed up you'll be able to join your friends and others around the world in sharing their upcoming plans and destinations.";
    // Colors and font
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:13];
    label.shadowColor = [UIColor colorWithWhite:0.8 alpha:0.8];
    label.textColor = [UIColor grayColor];
    // Automatic word wrap
    label.lineBreakMode = UILineBreakModeWordWrap;
    label.textAlignment = UITextAlignmentCenter;
    label.numberOfLines = 0;
    // Autosize
    [label sizeToFit];
    // Add the UILabel to the tableview
    [self.view addSubview:label];
    //self.tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background-tan.png"]];
  
    
    txtUsername.autocorrectionType=UITextAutocorrectionTypeNo;
    txtUsername.autocapitalizationType = UITextAutocapitalizationTypeNone;
    
    toolbar = [[UIToolbar alloc] init];
    toolbar.tintColor = [UIColor colorWithRed:200.0f/255.0f green:176.0f/255.0f blue:156.0f/255.0f alpha:1.0f];
    if (phoneVersion<5){
    toolbar.frame=CGRectMake(0,324, 320, 44);
    }
    else {
       toolbar.frame=CGRectMake(0,411, 320, 44);
    }
    segControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Sign Up", @"Login", nil]];
    segControl.selectedSegmentIndex=1;
    segControl.segmentedControlStyle=UISegmentedControlStyleBar;
    [segControl addTarget:self
                   action:@selector(segmentSwitch)
         forControlEvents:UIControlEventValueChanged];
    
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:segControl];
    
    toolbar.items = [NSArray arrayWithObjects:flexibleSpace,btnItem,flexibleSpace, nil];
    [self.view addSubview:toolbar];
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"sign_in"];

    
    NSLog(@"I am done loading the view");
}
-(void) segmentSwitch{
    
  
    
    [self.navigationController popViewControllerAnimated:YES];
}



/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 2;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{		
		if (indexPath.row == 0) {
			return cellUsername;
		}
		
		if (indexPath.row == 1) {
			return cellPassword;
		}

	
	
		return nil;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
	/*
	 <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
	 [self.navigationController pushViewController:detailViewController animated:YES];
	 [detailViewController release];
	 */
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{ 
	[textField resignFirstResponder];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
	
}




#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}



- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result

	[self performSelector:@selector(checkIt) withObject:nil afterDelay:1.5];
    [connection release];
	
}

-(void) login
{
	// make sure the keyboard is hidden
	[txtUsername resignFirstResponder];
	[txtPassword resignFirstResponder];
	
    
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Logging in...";
    
    //create password to send
    //[[NSUserDefaults standardUserDefaults] setValue:txtUsername.text forKey:USERNAME];
    //[[NSUserDefaults standardUserDefaults] synchronize];
    
    //NSUInteger fieldHash = [txtPassword.text hash];
    
    //NSString *fieldString = [KeychainWrapper securedSHA256DigestHashForPIN:fieldHash];
    
    responseData = [[NSMutableData data] retain];
    
    const char *bytes = [[NSString stringWithFormat:@"username=%@&password=%@&secretKey=387213549", txtUsername.text,txtPassword.text] UTF8String];
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/login.aspx"];
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
    [[NSURLConnection alloc] initWithRequest:request delegate:self];

	
}

-(void)checkIt{
    
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	NSLog(@"%@",s);
    
    if ([s rangeOfString:@"success"].location == NSNotFound){
        
        //something went wrong
        [self.hud hide:YES];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                            message:s
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
        
        
    }
    
    else {
        
        _hud.labelText = @"Success!";
        
        //do app registration here
        NSLog(@"%@",s);
        NSArray *split = [s componentsSeparatedByString: @"_"];
        NSString *newUserID=[split objectAtIndex:1];
        NSString *passwordHash=[split objectAtIndex:2];
        NSString *newUserEmail=[split objectAtIndex:3];
        NSString *hasPicture=[split objectAtIndex:4];
        NSLog (@"The new user ID is: %@",newUserID);
        NSLog (@"The new user pass is: %@",passwordHash);
        
        [[NSUserDefaults standardUserDefaults] setValue:txtUsername.text forKey:USERNAME];
        [[NSUserDefaults standardUserDefaults] setValue:newUserEmail forKey:@"emailaddress"];
        [[NSUserDefaults standardUserDefaults] setValue:newUserID forKey:@"userID"];
         [[NSUserDefaults standardUserDefaults] setValue:passwordHash forKey:@"password"];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:PIN_SAVED];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        
        
        //NSUInteger fieldHash = [txtPassword.text hash];
        
        //NSString *fieldString = [KeychainWrapper securedSHA256DigestHashForPIN:fieldHash];
        //NSLog(@"** Password Hash - %@", fieldString);
        // Save PIN hash to the keychain (NEVER store the direct PIN)
        //if ([KeychainWrapper createKeychainValue:fieldString forIdentifier:PIN_SAVED]) {
          //  [[NSUserDefaults standardUserDefaults] setBool:YES forKey:PIN_SAVED];
            //[[NSUserDefaults standardUserDefaults] synchronize];
            
            //NSLog(@"** Key saved successfully to Keychain!!");
        //}                
        
        
        if ([hasPicture isEqualToString:@"1"]){
            [self downloadPicture:newUserID];
        }
        else{
        [self performSelector:@selector(finishUp) withObject:nil afterDelay:1.5];
        }
        
    }
	[responseData release];
    
}

-(void) downloadPicture:(NSString *)userID{
    NSData * imageData;
    _hud.labelText = @"Getting photo...";
    NSString *path=[NSString stringWithFormat:@"http://www.when.me/iOScode/getPhoto.aspx?userID=%@",userID];
    NSLog(@"getting photo %@",path);
    NSURL *url = [NSURL URLWithString:path];
    imageData = [NSData dataWithContentsOfURL:url];
    UIImage *gotImage=[UIImage imageWithData:imageData];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
    NSData *webData = UIImagePNGRepresentation(gotImage);
    [webData writeToFile:imagePath atomically:YES];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self performSelector:@selector(finishUp) withObject:nil afterDelay:1.5];

    
}






-(void) finishUp {
  [self.hud hide:YES];
  [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:([self.navigationController.viewControllers count] -3)] animated:YES];
}




- (void)dealloc {
	[cellUsername release];
	[cellPassword release];


	[txtUsername release];
	[txtPassword release];


	[activityIndicator release];
    [super dealloc];
}


@end

