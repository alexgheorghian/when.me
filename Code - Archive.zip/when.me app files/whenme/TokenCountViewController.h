//
//  TokenCountViewController.h
//  whenme
//
//  Created by Eric English on 6/13/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

int phoneVersion;
@interface TokenCountViewController : UIViewController<AVAudioPlayerDelegate>



@property  (nonatomic,retain) IBOutlet UITextView *tokensEarned; 
@property (nonatomic,retain) NSMutableDictionary *myTokensData;
@property (nonatomic, retain) IBOutlet NSMutableData* responseData;
@property (strong,retain) AVAudioPlayer *playSound;

- (id)initWithNibName:(NSString *)nibNameOrNil andData:(NSMutableDictionary*)myData bundle:(NSBundle *)nibBundleOrNil;
@end
