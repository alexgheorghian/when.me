//
//  AppDelegate.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "PlanViewController.h"
#import "MyPlansViewController.h"
#import "FeedViewController.h"
#import "FriendsViewController.h"
#import "SettingsViewController.h"
#import "SHK.h"
#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "SHKConfig.h"
#import "Flurry.h"
#import "FBConnect.h"
#import "Facebook.h"
#import "GAI.h"

@protocol planTextDelegate
-(void) updatePlan:(NSString*)myText;
@end

//@class PlanViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,FBSessionDelegate>{
    Facebook *facebook;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UITabBarController *tabBarController;
@property (strong, nonatomic) UINavigationController *mainNavController;
@property (strong, nonatomic) UINavigationController *myPlansNavController;
@property (strong, nonatomic) UINavigationController *friendsNavController;
@property (strong, nonatomic) UINavigationController *feedNavController;
@property (strong, nonatomic) UINavigationController *settingsNavController;

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (NSURL *)applicationDocumentsDirectory;
- (void)saveContext;

@property (strong, nonatomic) PlanViewController *planViewController;
@property (strong, nonatomic) MyPlansViewController *myPlansViewController;
@property (strong, nonatomic) FriendsViewController *friendsViewController;
@property (strong, nonatomic) FeedViewController *feedViewController;
@property (strong, nonatomic) SettingsViewController *settingsViewController;

@property (nonatomic, retain) Facebook *facebook;


@end
