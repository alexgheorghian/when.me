//
//  UserViewController.m
//  whenme
//
//  Created by Eric English on 6/25/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "UserViewController.h"
#import "GAI.h"
#import "JSON.h"
#import "SignUpTableViewController.h"
#import "JoinPlanViewController.h"
#import "SDWebImage/UIImageView+WebCache.h"

@interface UserViewController ()


@end

@implementation UserViewController
@synthesize myUserName;
@synthesize myPhotoURL;
@synthesize myUserID;
@synthesize friendSwitch;
@synthesize isLoggedIn;
@synthesize responseData;
@synthesize hud = _hud;
@synthesize tv;
@synthesize plansArray;
@synthesize managedObjectContext;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithID:(NSString *)userID andUsername:(NSString *)userName andPhoto:(NSString *)photoURL
{
    self = [super initWithNibName:@"UserViewController" bundle:nil];
    if (self) {
        myUserName=userName;
        myPhotoURL= photoURL;
        myUserID=userID;
        plansArray = [[NSMutableArray alloc]init];
        self.title=userName;
   
    }
   
    
    self.title=userName;
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
       self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background-tan.png"]];
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 32)];
    imgView.image = [UIImage imageNamed:@"offwhite-bar.png"];
    [self.view addSubview:imgView];
    
    UIImageView *imgView2 = [[UIImageView alloc] initWithFrame:CGRectMake(165, 6, 71, 20)];
    imgView2.image = [UIImage imageNamed:@"addFriend.png"];
    [[self view] addSubview:imgView2];
    
    
    
    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,40,40)];
    [iv setImage:[UIImage imageNamed:@"myImage.png"]];
    
    [iv setImageWithURL:[NSURL URLWithString:myPhotoURL]
                   placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:iv];
    
    friendSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(240, 2, 0, 0)];
    [friendSwitch addTarget: self action: @selector(makeFriends) forControlEvents: UIControlEventValueChanged];
    [self.view addSubview: friendSwitch];
    
    UILabel *userLabel = [ [UILabel alloc ] initWithFrame:CGRectMake(8, 0, 150.0, 32.0) ];
    userLabel.textAlignment =  UITextAlignmentLeft;
    userLabel.textColor = [UIColor brownColor];
    userLabel.backgroundColor = [UIColor clearColor];
    userLabel.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(12.0)];
    [self.view addSubview:userLabel];
    userLabel.text=@"recent plans";
    
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    
    if (isLoggedIn){
        NSLog(@"checking if following");
        responseData = [NSMutableData data];
        NSString *followerID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
        const char *bytes = [[NSString stringWithFormat:@"followerID=%@&followingID=%@&secretKey=387213549",followerID,myUserID] UTF8String];
        NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/checkFollow.aspx"];
        NSMutableURLRequest *request =
        [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
        [[NSURLConnection alloc] initWithRequest:request delegate:self];
    }
    else {
        [self refreshTimeline];
    }
    
   

    NSString *pageView=[NSString stringWithFormat:@"/user_view/%@", myUserName];
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:pageView];
    

    // Do any additional setup after loading the view from its nib.
}

-(void)refreshTimeline
{
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Loading timeline...";
    responseData = [NSMutableData data];
    
    const char *bytes;
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/userFeed.aspx"];
    
    NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
    if (userID==nil){
        userID=@"0";
    }
   
    bytes= [[NSString stringWithFormat:@"sort=1&userID=%@&toShowID=%@",userID,myUserID] UTF8String];
    

    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

-(void)makeFriends
{
    NSLog(@"In make friends");
    if (friendSwitch.isOn){
         NSLog(@"friend switch on");
        if (!isLoggedIn){
            SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
            signupVC.title = NSLocalizedString(@"SignUp", @"");
            [self.navigationController pushViewController:signupVC  animated:YES];
        }
        else{
            self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            _hud.labelText = @"Following...";
            NSLog(@"setting the response data");
            responseData = [NSMutableData data];
            NSString *followerID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
            NSString *password=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
            const char *bytes = [[NSString stringWithFormat:@"followerID=%@&password=%@&followingID=%@&secretKey=387213549&followtype=1",followerID,password,myUserID] UTF8String];
            //NSString *toSend=[NSString stringWithFormat:@"followerID=%@&password=%@&followingID=%@&secretKey=387213549&followtype=1",followerID,password,myUserID];
            //NSLog(@"Sending data: %@",toSend);
            NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/follow.aspx"];
            NSMutableURLRequest *request =
            [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
            [[NSURLConnection alloc] initWithRequest:request delegate:self];
        }
    }
    else{
        if (!isLoggedIn){
            SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
            signupVC.title = NSLocalizedString(@"SignUp", @"");
            [self.navigationController pushViewController:signupVC  animated:YES];
        }
        else{
            self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            _hud.labelText = @"UnFollowing...";
            NSLog(@"setting the response data");
            responseData = [NSMutableData data];
            NSString *followerID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
            NSString *password=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
            const char *bytes = [[NSString stringWithFormat:@"followerID=%@&password=%@&followingID=%@&secretKey=387213549&followtype=0",followerID,password,myUserID] UTF8String];

            NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/follow.aspx"];
            NSMutableURLRequest *request =
            [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
            [[NSURLConnection alloc] initWithRequest:request delegate:self];
        }
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    
	 NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
    if ([s isEqualToString:@"followSuccess"] || [s isEqualToString:@"followFailure"]){
        if ([s isEqualToString:@"followSuccess"]){
        [self performSelector:@selector(finishFollow) withObject:nil afterDelay:1.0];
        }
        else {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                                message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                               delegate:self 
                                                      cancelButtonTitle:@"OK" 
                                                      otherButtonTitles:nil];
            [alertView show];
            
        }
    }
    else if ([s isEqualToString:@"isfollowing_1"] || [s isEqualToString:@"isfollowing_0"]){
        NSLog(@"Setting the following switch");
    //set the following switch
        if ([s isEqualToString:@"isfollowing_1"]){
            [friendSwitch setOn:YES];
        }
        else {
            [friendSwitch setOn:NO];
        }
        
         [self refreshTimeline]; //connection freed up lets get the plans
    }
    else {  //its the table response
        
        [self.hud hide:YES];
        NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
        NSLog(@"%@",s);
        NSMutableDictionary *myData=[s JSONValue];
        
        plansArray=[myData objectForKey: @"plans"];
        
        //plansArray=[NSArray arrayWithArray:(NSArray *)[values valueForKey:@"plans"]];;
        [self.tv reloadData];
    }
    
}

-(void) finishFollow {
    [self.hud hide:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    NSInteger sections = 1;
	
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSInteger rows = [plansArray count];
	NSLog(@"The number of rows is %d",rows);
    return rows;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    
    [cell.imageView setImageWithURL:[NSURL URLWithString:[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"]]
                   placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
    cell.textLabel.text=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"planText"];
    // Configure the cell...
    //cell.textLabel.text = [[plansArray objectAtIndex:indexPath.row]  stringValue];
    //NSArray *sectionContents = [[self tablePlansArray] objectAtIndex:[indexPath section]];
    //NSString *contentForThisRow = [sectionContents objectAtIndex:[indexPath row]];
    
    //Plan *plan = (Plan *)[sectionContents objectAtIndex:[indexPath row]];
    //NSString *myString = [[plan planID] stringValue];
    //NSString *toShow=[NSString stringWithFormat:@"%@ (%@)",[plan planText],[plan uniqueID]];
    //cell.textLabel.text=toShow;
    //cell.textLabel.text=[plan planText];
    
    
    cell.textLabel.textColor=[UIColor brownColor];
    
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    NSDate *todayDate = [NSDate date];
    NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
    NSDate *planDate =[dateFormat dateFromString:[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"planDate"]];
    NSString *planDateString = [dateFormat stringFromDate:planDate];
    
    NSLog(@"%@",[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"planDate"]);
    NSLog(@"%@",planDateString);
    
    NSDate *today=[dateFormat dateFromString:todayDateString];
    NSDate *strDate=[dateFormat dateFromString:planDateString];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSWeekCalendarUnit|NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                               fromDate:today
                                                 toDate:strDate
                                                options:0];
    
    
    NSLog(@"%d years %d months %d weeks %d days %d hours %d minutes %d seconds",components.year,components.month,components.week,components.day,components.hour,components.minute,components.second);
    
    NSString *digitPicked;
    NSString *timeFramePicked;
    
    int years=components.year+1;
    int months=components.month+1;
    int weeks=components.week+1;
    int days=components.day+1;
    int hours=components.hour+1;
    int minutes=components.minute+1;
    
    if (components.year>0) {
        digitPicked=[NSString stringWithFormat:@"%d", years];
        if (years==1) {
            timeFramePicked=@"year from now";}
        else{
            timeFramePicked=@"years from now";
        }
    }
    else if (components.month>0) {
        digitPicked=[NSString stringWithFormat:@"%d", months];
        if (months==1) {
            timeFramePicked=@"month from now";}
        else{
            timeFramePicked=@"months from now";
        }
    }
    else if (components.week>0) {
        digitPicked=[NSString stringWithFormat:@"%d", weeks];
        if (weeks==1) {
            timeFramePicked=@"week from now";}
        else{
            timeFramePicked=@"weeks from now";
        }
    }
    else if (components.day>0) {
        digitPicked=[NSString stringWithFormat:@"%d", days];
        if (days==1) {
            timeFramePicked=@"day from now";}
        else{
            timeFramePicked=@"days from now";
        }
    }
    else if (components.hour>0){
        digitPicked=[NSString stringWithFormat:@"%d", hours];
        if (hours==1) {
            timeFramePicked=@"hour from now";}
        else{
            timeFramePicked=@"hours from now";
        }
    }
    
    else if (components.minute>0){
        digitPicked=[NSString stringWithFormat:@"%d", minutes];
        if (minutes==1) {
            timeFramePicked=@"minute from now";}
        else{
            timeFramePicked=@"minutes from now";
        }
    }
    
    else{
        digitPicked=@"";
        timeFramePicked=@"in the past";
        cell.textLabel.textColor=[UIColor grayColor];
    }
    UIImage *myImage;
    if ([[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"joined"] isEqualToString:@"0"]){
        myImage= [UIImage imageNamed:@"feedJoinButton.png"];
    }
    else {
        myImage= [UIImage imageNamed:@"feedJoinedButton.png"];
    }
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:myImage];
    
    [cell setAccessoryView:imageView];
    //[cell setAccessoryType:UITableViewCellAccessoryDetailDisclosureButton];
    
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ %@", digitPicked, timeFramePicked];
    cell.textLabel.adjustsFontSizeToFitWidth = YES; 
    cell.textLabel.numberOfLines = 1;
    return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:235.0/255 green:235.0/255 blue:235.0/255 alpha:1]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"You tapped %d",[indexPath row]);   
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //[self showJoinSheet:[indexPath row]];
    //NSString *str = [[plansArray objectAtIndex:indexPath.row] stringValue];
    
    
    NSString *planText=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"planText"];
    NSNumber *planLatitude=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"latitude"];
    NSNumber *planLongitude=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"longitude"];
    
    NSNumber *hasPlanPicture=[NSNumber numberWithInt:0];    
    NSNumber *hasCompletePicture=[NSNumber numberWithInt:0]; 
    NSString *uniqueIDString=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"uniqueID"];
    NSString *username=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"username"];
    NSString *userImage=[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"];
    NSNumber *locationOverride=[NSNumber numberWithInt:0];
    
    
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
    
    NSDateFormatter *dateFormat2 = [[NSDateFormatter alloc] init];
    [dateFormat2 setTimeZone:timeZone];	
    [dateFormat2 setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    
    NSDate *planDate =[dateFormat dateFromString:[[plansArray objectAtIndex:[indexPath row]] valueForKey:@"planDate"]];
    NSString *dateString = [dateFormat2 stringFromDate:planDate];
    
    
    NSDate *todayDate = [NSDate date];
    NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
    
    
    NSString *planDateString = [dateFormat stringFromDate:planDate];
    
    
    NSDate *today=[dateFormat dateFromString:todayDateString];
    NSDate *strDate=[dateFormat dateFromString:planDateString];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                               fromDate:today
                                                 toDate:strDate
                                                options:0];
    
    
    NSLog(@"%d days %d hours %d minutes %d seconds",components.day,components.hour,components.minute,components.second);
    
    NSString *digitPicked;
    NSString *timeFramePicked;
    if (components.day>0) {
        digitPicked=[NSString stringWithFormat:@"%d", components.day+1];
        timeFramePicked=@"days from now";
    }
    else if (components.hour>0){
        digitPicked=[NSString stringWithFormat:@"%d", components.hour];
        timeFramePicked=@"hours from now";
    }
    
    else if (components.minute>0){
        digitPicked=[NSString stringWithFormat:@"%d", components.minute];
        timeFramePicked=@"minutes from now";
    }
    
    else{
        digitPicked=@"";
        timeFramePicked=@"in the past";
    }
    
    
    
    
    
    NSMutableDictionary *myPlan;
    
    if (uniqueIDString==nil){
        
        
        myPlan= [[NSMutableDictionary alloc] initWithObjectsAndKeys:dateString, @"planDate", planText, @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",username,@"username",userImage,@"userImage",locationOverride,@"locationOverride",[NSNull null], @"uniqueID", planLatitude,@"latitude",planLongitude,@"longitude", nil];
        
    } else {
        
        myPlan = [[NSMutableDictionary alloc] initWithObjectsAndKeys:dateString, @"planDate", planText, @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",username,@"username",userImage,@"userImage",locationOverride,@"locationOverride",uniqueIDString, @"uniqueID", planLatitude,@"latitude",planLongitude,@"longitude", nil];
    }
    
    NSLog(@"%@",myPlan);
    JoinPlanViewController *joinPlanView=[[JoinPlanViewController alloc] initWithData:myPlan nibName:@"JoinPlanViewController" bundle:nil];
    
    joinPlanView.managedObjectContext = self.managedObjectContext;
    

    
    [self.navigationController pushViewController:joinPlanView animated:YES];
}    



/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
