//
//  FriendsViewControllerViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "JoinPlanViewController.h"
#import "FriendsViewController.h"
#import "JSON.h"
#import "GAI.h"
#import "UserViewController.h"
#import "whenMeConstants.h"
#import "SignupTableViewController.h"
#import "UserTableViewController.h"
#import "InviteFriendsViewController.h"
#import "CMPopTipView.h"
#import "SDWebImage/UIImageView+WebCache.h"
#import <QuartzCore/QuartzCore.h>

@interface FriendsViewController ()

@end

@implementation FriendsViewController

@synthesize responseData;
@synthesize hud = _hud;
@synthesize friendsArray;
@synthesize toolbar;
@synthesize segControl;
@synthesize tv;
@synthesize managedObjectContext;
@synthesize searchString;
@synthesize photoButton;
@synthesize photoButtonImage;
@synthesize isLoggedIn;
@synthesize PopTipView;
@synthesize searchBar;
@synthesize playSound;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Friends";
        self.tabBarItem.image = [UIImage imageNamed:@"779-users"];
        friendsArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    feedType=0;
    
    [super viewDidLoad];
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }

    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    toolbar = [[UIToolbar alloc] init];
    toolbar.tintColor = [UIColor darkGrayColor];
    
    if (phoneVersion<5){
    toolbar.frame=CGRectMake(0,387, 320, 44);
    }
    else{
        toolbar.frame=CGRectMake(0,475, 320, 44);
    }
    segControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Following", @"Followers", nil]];
    segControl.selectedSegmentIndex=0;
    //segControl.tintColor=[UIColor brownColor];
    segControl.segmentedControlStyle=UISegmentedControlStyleBar;
    [segControl addTarget:self
                   action:@selector(segmentSwitch)
         forControlEvents:UIControlEventValueChanged];
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:segControl];
    toolbar.items = [NSArray arrayWithObjects:flexibleSpace,btnItem,flexibleSpace, nil];
    [self.navigationController.view addSubview:toolbar];
    
    
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:@"Invite" style:UIBarButtonItemStylePlain target:self action:@selector(showInvite)];
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
    //NSManagedObjectContext *context = [self managedObjectContext];
    //if (!context) {
    //    NSLog(@"No context on feed page");
    //}
    // Pass the managed object context to the view controller.
    //self.managedObjectContext = context;
    
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 44, 320, 44)];
    searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    searchBar.delegate =self;
    searchBar.tintColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    searchBar.placeholder=@"Find friends by email or username";
    searchDisplayController.delegate = self;
    searchDisplayController.searchResultsDelegate = self;
    searchDisplayController.searchResultsDataSource = self;
    self.tv.tableHeaderView = searchBar;
    
    searchString = [NSString alloc];
    searchBarActive=NO;
    //[self refreshTimeline];
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
        
    }
    
    
    
    photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    photoButton.frame = CGRectMake(0, 0, 41, 41);
    [photoButton addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
    
    //photoButton.layer.borderWidth=1;
    //photoButton.layer.borderColor=[UIColor lightGrayColor].CGColor;
    
    UIBarButtonItem *aBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:photoButton];
    self.navigationController.topViewController.navigationItem.leftBarButtonItem = aBarButtonItem2;
    
    popTipSeen=0;
    
    if(!isLoggedIn){
        NSString *myExamplePath = [[NSBundle mainBundle] pathForResource:@"33369__herbertboland__mouthpop" ofType:@"wav"];
        
        playSound =[[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:myExamplePath] error:NULL];
        
        playSound.delegate = self;
        [playSound prepareToPlay];
    }

  
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"friends_view"];
    
   // [self refreshTimeline];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated{
    toolbar.hidden = NO;
    [self.hud hide:YES];
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
        //[myPicture setImage:img]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
    }
    
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    if (searchBarActive==NO){
        [self refreshTimeline];
    }
    

    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void) showInvite {
    toolbar.hidden=YES;
    InviteFriendsViewController* inviteVC = [[InviteFriendsViewController alloc]initWithNibName:@"InviteFriendsViewController" bundle:nil];
    inviteVC.title = NSLocalizedString(@"Invite Friends", @"");
    [self.navigationController pushViewController:inviteVC  animated:YES];
}

- (void) showUserPage{
    NSLog(@"I am in here");
    [PopTipView dismissAnimated:YES];
    if (!isLoggedIn){
        SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"SignUp", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
        toolbar.hidden=YES;
        
    }
    else{
        UserTableViewController* signupVC = [[UserTableViewController alloc]initWithNibName:@"UserTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"About me", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
        toolbar.hidden=YES;
    }
}


-(void) segmentSwitch{
    
    feedType=segControl.selectedSegmentIndex;
    [self refreshTimeline];
    
}

-(void)refreshTimeline
{
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Loading friends...";
    responseData = [NSMutableData data];
    
    const char *bytes;
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/showFriends.aspx"];
    
    NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
    if (userID==nil){
        userID=@"0";
    }
    if (feedType==0){ //popular
        bytes= [[NSString stringWithFormat:@"sort=0&userID=%@",userID] UTF8String];
    }
    else if (feedType==1) { //soon
        bytes= [[NSString stringWithFormat:@"sort=1&userID=%@",userID] UTF8String];
        
    }
    else if (feedType==2) { //friends
        bytes= [[NSString stringWithFormat:@"sort=2&userID=%@",userID] UTF8String];
        
    }
    //NSLog(@"sending data: %@",bytes);
    
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

-(void)refreshTimelineSearch
{
    //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //_hud.labelText = @"Searching...";
    responseData = [NSMutableData data];
    
    const char *bytes;
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/showFriends.aspx"];
    
    NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
    if (userID==nil){
        userID=@"0";
    }

    bytes= [[NSString stringWithFormat:@"sort=2&userID=%@&searchString=%@",userID,searchString] UTF8String];
        

    //NSLog(@"sending data: %@",bytes);
    
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    
    [self.hud hide:YES];
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	NSLog(@"%@",s);
    NSMutableDictionary *myData=[s JSONValue];
    
    friendsArray=[myData objectForKey: @"friends"];
    
    //plansArray=[NSArray arrayWithArray:(NSArray *)[values valueForKey:@"plans"]];;
    [self.tv reloadData];
    
    [[[self searchDisplayController] searchResultsTableView] reloadData];
    
    if ((!isLoggedIn) && popTipSeen==0){
        
        
        PopTipView = [[CMPopTipView alloc] initWithMessage:@"You haven't added any friends. Search for and invite some!"];
        PopTipView.delegate = self;
        PopTipView.backgroundColor = [UIColor whiteColor];
        PopTipView.textColor = [UIColor darkTextColor];
        PopTipView.animation = CMPopTipAnimationPop;
        [PopTipView presentPointingAtView:searchBar inView:self.view animated:YES];
        popTipSeen=1;
        [playSound play];
        
    }
    
    //[self performSelector:@selector(checkIt) withObject:nil afterDelay:1.5];
    //[connection release];
	
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    NSInteger sections = 1;
	
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSInteger rows = [friendsArray count];
	NSLog(@"The number of rows is %d",rows);
    
 
    return rows;
}







- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"Cell";
   if(tableView == self.searchDisplayController.searchResultsTableView){ 
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    
    [cell.imageView setImageWithURL:[NSURL URLWithString:[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"]]
                   placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
    cell.textLabel.text=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userName"];
    
    if ([[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"recentPlan"] isEqualToString:@""]){
       cell.detailTextLabel.text=@"No recent plans"; 
    }
    else {
    cell.detailTextLabel.text=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"recentPlan"];
    }
    cell.textLabel.textColor=[UIColor brownColor];
    
    cell.textLabel.adjustsFontSizeToFitWidth = YES; 
    cell.textLabel.numberOfLines = 1;
       [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    return cell;
   }
   else {
       UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
       if (cell == nil) {
           cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
       }
       
       
       [cell.imageView setImageWithURL:[NSURL URLWithString:[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"]]
                      placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
       cell.textLabel.text=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userName"];
       
       if ([[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"recentPlan"] isEqualToString:@""]){
           cell.detailTextLabel.text=@"No recent plans"; 
       }
       else {
           cell.detailTextLabel.text=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"recentPlan"];
       }
       cell.textLabel.textColor=[UIColor brownColor];
       
       cell.textLabel.adjustsFontSizeToFitWidth = YES; 
       cell.textLabel.numberOfLines = 1;
       [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
       return cell;
   }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:235.0/255 green:235.0/255 blue:235.0/255 alpha:1]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"You tapped %d",[indexPath row]);   
}

#pragma searchbar

-(void) processSearch{
 
    [self refreshTimelineSearch];
}

- (void)updateSearchString:(NSString*)aSearchString
{
    
    searchString = [[NSString alloc]initWithString:aSearchString];
    [self refreshTimelineSearch];
    
}

//UPDATE - to handle filtering
- (void)searchBarTextDidBeginEditing:(UISearchBar *)theSearchBar
{
    [theSearchBar setShowsCancelButton:YES animated:YES];
    //Changed to YES to allow selection when in the middle of a search/filter
    self.tv.allowsSelection   = YES;
    self.tv.scrollEnabled     = YES; 
    searchBarActive=YES;
    [PopTipView dismissAnimated:YES];
    
    //[placesOutputArray removeAllObjects];
    //[self.tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)theSearchBar
{
    [theSearchBar setShowsCancelButton:NO animated:YES];
    [theSearchBar resignFirstResponder];
    self.tv.allowsSelection   = YES;
    self.tv.scrollEnabled     = YES;
    theSearchBar.text           = @"";
    searchBarActive=NO;
    [self refreshTimeline];
    
    //[self updateSearchString:searchBar.text];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)theSearchBar
{
    self.tv.allowsSelection   = YES;
    self.tv.scrollEnabled     = YES;
    
    [self updateSearchString:theSearchBar.text];
    //[self ParseXML_of_Google_PlacesAPI];
    //[searchDisplayController setActive:NO];
}

//NEW - to handle filtering
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchText.length>=3 && searchText.length>searchString.length){
        [self updateSearchString:searchText];
    }
    else {
        searchString = [[NSString alloc]initWithString:searchText];
    }
    
    // cancel any scheduled lookup
    //[NSObject cancelPreviousPerformRequestsWithTarget:self];
    // start a new one in 0.3 seconds
    //[self performSelector:@selector(updateSearchString:) withObject:searchText afterDelay:0.5];
    
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *userID=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userID"];
    NSString *userName=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userName"];
    NSString *photoURL=[[friendsArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"];
    NSLog(@"sending ID:%@ and username:%@",userID,userName);
    UserViewController *userVC=[[UserViewController alloc] initWithID:userID andUsername:userName andPhoto:photoURL];
    userVC.managedObjectContext=self.managedObjectContext;
    [self.navigationController pushViewController:userVC animated:YES];
    toolbar.hidden = YES;

}    



-(IBAction)showJoinSheet:(int)index {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Do you want to join this plan?" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Yes", nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery setTag:1];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	
    
    
    int actionSheetTag;
    
    actionSheetTag=[actionSheet tag];
    
    if (actionSheetTag==1){
        if (buttonIndex==0){
            NSLog(@"Join Plan");
        }
        
    }
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
