//
//  FeedViewControllerViewController.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "LeaderBoardViewController.h"

@interface FeedViewController : UIViewController<UITableViewDelegate,UIActionSheetDelegate>
{ 
    NSMutableData *responseData;
    MBProgressHUD *_hud;
    NSMutableArray *plansArray;
    int feedType;
    int phoneVersion;
    NSManagedObjectContext *managedObjectContext;
}

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;
@property (nonatomic, retain) NSMutableArray *plansArray;
@property (retain) MBProgressHUD *hud;
@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;
@property (strong, nonatomic) IBOutlet UITableView *tv;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@property (strong, nonatomic) UIImage *photoButtonImage;
@property (strong, nonatomic) UIButton *photoButton;
@property (nonatomic) BOOL isLoggedIn;


@end
