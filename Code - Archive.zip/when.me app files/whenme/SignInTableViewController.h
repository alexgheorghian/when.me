//
//  SignupTableViewController.h
//  ExSignup
//
//  Created by Nada Jaksic on 7/13/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"


@interface SignInTableViewController : UITableViewController<UITextFieldDelegate, UIAlertViewDelegate>
{

    int phoneVersion;
    
    IBOutlet UITableViewCell *cellUsername;
    IBOutlet UITableViewCell *cellPassword;

	

	IBOutlet UITextField* txtUsername;
	IBOutlet UITextField* txtPassword;



	UIActivityIndicatorView* activityIndicator;
    
    NSMutableData *responseData;
    
    MBProgressHUD *_hud;
    


}

@property (nonatomic, retain) IBOutlet UITableViewCell *cellUsername;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellPassword;


@property (nonatomic, retain) IBOutlet UITextField* txtUsername;
@property (nonatomic, retain) IBOutlet UITextField* txtPassword;


@property (nonatomic, retain) IBOutlet NSMutableData* responseData;

@property (retain) MBProgressHUD *hud;

@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;



@end
