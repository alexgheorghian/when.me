//
//  PlacesTableViewController.m
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlacesTableViewController.h"
#import "GAI.h"

@implementation PlacesTableViewController

@synthesize locationManager;
@synthesize currentLocation;
@synthesize PlacesURL;
@synthesize resultsLoaded;
@synthesize locationsFilterResults;
@dynamic userLong;
@synthesize hud = _hud;
@synthesize searchString;




- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
        
        placesOutputArray = [[NSMutableArray alloc]init];
       
        
    }
    return self;
}

-(void)ParseXML_of_Google_PlacesAPI
{
   
    NSLog(@"Sending data to google");
    [placesOutputArray removeAllObjects];
    [self.tableView reloadData];
    NSURL *googlePlacesURL = [[NSURL alloc] initWithString:[PlacesURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
    //NSLog(@"googelPalcesURL=%@",googlePlacesURL);
    NSData *xmlData = [NSData dataWithContentsOfURL:googlePlacesURL];
    xmlDocument = [[GDataXMLDocument alloc]initWithData:xmlData options:0 error:nil];
    
    NSArray *arr = [xmlDocument.rootElement elementsForName:@"result"];
    //NSLog(@"%@",arr);
    for(GDataXMLElement *e in arr )
    {
        [placesOutputArray addObject:e];
    }
    
    [self.hud hide:YES];
    [self.tableView reloadData];
  
    
    
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 44, 320, 44)];
    searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    searchBar.delegate =self;
    searchBar.tintColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    searchDisplayController.delegate = self;
    searchDisplayController.searchResultsDelegate = self.tableView.delegate;
    searchDisplayController.searchResultsDataSource = self.tableView.dataSource;
    self.tableView.tableHeaderView = searchBar;
    // Uncomment the following line to preserve selection between presentations.
     //self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    searchString = [NSString alloc];
    _hud.labelText = @"Finding Places...";
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"places_view"];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
     [[self locationManager] startUpdatingLocation];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    self.navigationController.navigationBar.barTintColor=[UIColor blackColor];
    
    if ([placesOutputArray count]>0){
         [self.hud hide:YES];
    }
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[self locationManager] stopUpdatingLocation];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    NSLog (@"I am returning %d results",[placesOutputArray count]);
    //NSLog(@"%@",placesOutputArray);
    return [placesOutputArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    // Configure the cell...
    cell.textLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:0] stringValue];
    cell.textLabel.textColor =[UIColor brownColor];
    
    cell.detailTextLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:1] stringValue];
    
    NSString *placeType=[[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:2] stringValue];
    
    if ([placeType rangeOfString:@"restaurant"].location != NSNotFound) {
     [cell.imageView setImage:[UIImage imageNamed:@"placeIcon-food.png"]];
    }
    
    else if ([placeType rangeOfString:@"bar"].location != NSNotFound){
        [cell.imageView setImage:[UIImage imageNamed:@"placeIcon-bar.png"]];
    }
    
    else if ([placeType rangeOfString:@"store"].location != NSNotFound){
        [cell.imageView setImage:[UIImage imageNamed:@"placeIcon-shop.png"]];
    }
    else{
    
       [cell.imageView setImage:[UIImage imageNamed:@"placeIcon-general.png"]];
    }
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:0] stringValue];
    
    //parsing for latitude and longitude
    
    double lat = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:0]stringValue]doubleValue];
    
    double lng = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:1] stringValue] doubleValue];
    
    CLLocationCoordinate2D _cords = {lat,lng};
    
    mapViewC = [[MapViewController alloc]initWithNibName:nil bundle:nil placeName:str andCoordinates:_cords];
    
    [self.navigationController pushViewController:mapViewC animated:YES];
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:235.0/255 green:235.0/255 blue:235.0/255 alpha:1]];
}

#pragma mark -
#pragma mark Location manager

/**
 Return a location manager -- create one if necessary.
 */

- (CLLocationManager *)locationManager 
{
	
    if (locationManager != nil) 
    {
		return locationManager;
	}
	
	locationManager = [[CLLocationManager alloc] init];
	[locationManager setDesiredAccuracy:kCLLocationAccuracyNearestTenMeters];
	[locationManager setDelegate:self];
	
	return locationManager;
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation 
{
    
  
    if ([self isResultsLoaded]) 
    {
		 [self.hud hide:YES];
        return;
	}
    
  
    [self setResultsLoaded:YES];
    
    currentLocation = newLocation;
    CLLocationCoordinate2D coords=CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    userLat=coords.latitude;
    userLong=coords.longitude;
    //What places to search for
    NSString *searchLocations = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@", 
                                 kAirport,
                                 kAmusementPark,
                                 kAquarium,
                                 kArtGallery,
                                 kBar,
                                 kBeautySalon,
                                 kBowlingAlley,
                                 kCafe,
                                 kCampground,
                                 kCasino,
                                 kChurch,
                                 kCourthouse,
                                 kDentist,
                                 kDoctor,
                                 kFood,
                                 kGrocerySupermarket,
                                 kGym,
                                 kHairCare,
                                 kHealth,
                                 kHospital,
                                 kLaundry,
                                 kLiquorStore,
                                 kLodging,
                                 kMealDelivery,
                                 kMealTakeaway,
                                 kMosque,
                                 kMovieTheater,
                                 kMuseum,
                                 kNightClub,
                                 kPark,
                                 kPharmacy,
                                 kPlaceWorship,
                                 kRestaurant,
                                 kSchool,
                                 kShoppingMall,
                                 kSpa,
                                 kStadium,
                                 kStore,
                                 kSubwayStation,
                                 kSynagogue,
                                 kUniversity,
                                 kZoo
                                 ];
    
    PlacesURL=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/xml?location=%f,%f&rankby=distance&types=%@&sensor=false&key=AIzaSyDR-DlND0mAEbnwLTRNTxYX2u3h7_FAQgU",coords.latitude,coords.longitude,searchLocations];
    //NSLog(@"%@",PlacesURL);
    [self ParseXML_of_Google_PlacesAPI];
    
       
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error 
{
    NSLog(@"locationManager FAIL");
    NSLog(@"%@", [error description]);
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"You have disabled location sharing for when.me or no network connection is available. To re-enable location sharing please switch 'Location Services' to 'On' for when.me in your device settings." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
    
}

#pragma searchbar
- (void)updateSearchString:(NSString*)aSearchString
{
    
    NSLog(@" sending %@",aSearchString);
    searchString = [[NSString alloc]initWithString:aSearchString];
     //searchString = [searchString gtm_stringByEscapingForURLArgument];
    
   // CLLocationCoordinate2D coords=CLLocationCoordinate2DMake(currentLocation.coordinate.latitude, currentLocation.coordinate.longitude);
    //What places to search for
    NSString *searchLocations = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@", 
                                 kAirport,
                                 kAmusementPark,
                                 kAquarium,
                                 kArtGallery,
                                 kBar,
                                 kBeautySalon,
                                 kBowlingAlley,
                                 kCafe,
                                 kCampground,
                                 kCasino,
                                 kChurch,
                                 kCourthouse,
                                 kDentist,
                                 kDoctor,
                                 kFood,
                                 kGrocerySupermarket,
                                 kGym,
                                 kHairCare,
                                 kHealth,
                                 kHospital,
                                 kLaundry,
                                 kLiquorStore,
                                 kLodging,
                                 kMealDelivery,
                                 kMealTakeaway,
                                 kMosque,
                                 kMovieTheater,
                                 kMuseum,
                                 kNightClub,
                                 kPark,
                                 kPharmacy,
                                 kPlaceWorship,
                                 kRestaurant,
                                 kSchool,
                                 kShoppingMall,
                                 kSpa,
                                 kStadium,
                                 kStore,
                                 kSubwayStation,
                                 kSynagogue,
                                 kUniversity,
                                 kZoo
                                 ];    
    PlacesURL=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/xml?location=%f,%f&rankby=prominence&radius=50000&types=%@&sensor=false&keyword=%@&key=AIzaSyDR-DlND0mAEbnwLTRNTxYX2u3h7_FAQgU",userLat,userLong,searchLocations,searchString];
    //NSLog(@"%@",PlacesURL);
    [self ParseXML_of_Google_PlacesAPI];
 
}

//UPDATE - to handle filtering
- (void)searchBarTextDidBeginEditing:(UISearchBar *)theSearchBar
{
    [theSearchBar setShowsCancelButton:YES animated:YES];
    //Changed to YES to allow selection when in the middle of a search/filter
    self.tableView.allowsSelection   = YES;
    self.tableView.scrollEnabled     = YES;    
    
    //[placesOutputArray removeAllObjects];
    //[self.tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)theSearchBar
{
    [theSearchBar setShowsCancelButton:NO animated:YES];
    [theSearchBar resignFirstResponder];
    self.tableView.allowsSelection   = YES;
    self.tableView.scrollEnabled     = YES;
    theSearchBar.text           = @"";
    
    //[self updateSearchString:searchBar.text];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)theSearchBar
{
    self.tableView.allowsSelection   = YES;
    self.tableView.scrollEnabled     = YES;
    
    [self updateSearchString:theSearchBar.text];
    //[self ParseXML_of_Google_PlacesAPI];
    //[searchDisplayController setActive:NO];
}

//NEW - to handle filtering
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchText.length>3 && searchText.length>searchString.length){
     [self updateSearchString:searchText];
    }
    else {
         searchString = [[NSString alloc]initWithString:searchText];
    }
    
    // cancel any scheduled lookup
    //[NSObject cancelPreviousPerformRequestsWithTarget:self];
    // start a new one in 0.3 seconds
    //[self performSelector:@selector(updateSearchString:) withObject:searchText afterDelay:0.5];
    
}

//NEW - to handle filtering
//Create an array by applying the search string
/*- (void) buildSearchArrayFrom: (NSString *) matchString
{
	NSString *upString = [matchString uppercaseString];
	
	locationsFilterResults = [[NSMutableArray alloc] init];
    
	for (GooglePlacesObject *location in locations)
	{
		if ([matchString length] == 0)
		{
			[locationsFilterResults addObject:location];
			continue;
		}
		
		NSRange range = [[location.name uppercaseString] rangeOfString:upString];
		
        if (range.location != NSNotFound) 
        {
            NSLog(@"Hit");
            
            NSLog(@"Location Name %@", location.name);
            NSLog(@"Search String %@", upString);
            
            [locationsFilterResults addObject:location];
        }
	}
	
	[self.tableView reloadData];
}*/



@end
