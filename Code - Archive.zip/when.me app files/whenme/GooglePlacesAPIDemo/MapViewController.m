//
//  MapViewController.m
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MapViewController.h"
#import "GAI.h"



@implementation MapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil placeName:(NSString*)_name andCoordinates:(CLLocationCoordinate2D)placecords
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        placeName = _name;
        globalCords = placecords;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    mpView = [[[MKMapView alloc]initWithFrame:self.view.bounds] autorelease];
    mpView.delegate=self;
    self.navigationController.navigationBar.barTintColor=[UIColor blackColor];

    mapAnnotObject = [[[MyMapAnnot alloc]initWithTitle:placeName andCoordinate:globalCords] autorelease];
    
    CLLocationCoordinate2D cord = {globalCords.latitude,globalCords.longitude};
    MKCoordinateSpan spn = {0.01,0.01};
    MKCoordinateRegion reg = {cord,spn};
    
    [mpView setRegion:reg];
    

    [mpView addAnnotation:mapAnnotObject];
    
    UIBarButtonItem *anotherButton = [[[UIBarButtonItem alloc] initWithTitle:@"Use This" style:UIBarButtonItemStylePlain target:self action:@selector(usePin)] autorelease];
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
    
    [self.view addSubview:mpView];
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"map-view"];
    
    
    
    
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barTintColor=[UIColor blackColor];
}



- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
	
    MKPinAnnotationView *pin = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"pin"] autorelease];
    [pin setAnimatesDrop:YES];
    [pin setCanShowCallout:YES];
    [pin setSelected:YES];
    [pin setUserInteractionEnabled: YES];
    
    UIButton *discloseButton = [UIButton buttonWithType: UIButtonTypeContactAdd];
    //[discloseButton addTarget: self action: @selector(selectPlace) forControlEvents: UIControlEventTouchUpInside];
    pin.rightCalloutAccessoryView = discloseButton;
    
	
    return pin;
}

- (void)mapView:(MKMapView *)mapView didAddAnnotationViews:(NSArray *)views
{
   
    id<MKAnnotation> myAnnotation = [mpView.annotations objectAtIndex:0];
    [mapView selectAnnotation:myAnnotation animated:YES];
}

- (void)mapView:(MKMapView *)mv annotationView:(MKAnnotationView *)pin calloutAccessoryControlTapped:(UIControl *)control {
   
    NSNumber *myPlaceLat= [NSNumber numberWithFloat:pin.annotation.coordinate.latitude];
    NSNumber *myPlaceLong= [NSNumber numberWithFloat:pin.annotation.coordinate.longitude];
   // NSDictionary* dict = [NSDictionary dictionaryWithObject:
    //                     pin.annotation.title
     //                                              forKey:@"myTitle"];
    
    NSDictionary* dict = [[[NSDictionary alloc] initWithObjectsAndKeys:pin.annotation.title, @"myTitle", myPlaceLat, @"planLatitude", myPlaceLong, @"planLongitude",nil] autorelease];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"DidSelectPlace"
                                                        object:self
                                                      userInfo:dict]; 
   
    [self.navigationController popToRootViewControllerAnimated:YES];
   
}

- (void)usePin {
    
    NSNumber *myPlaceLat= [NSNumber numberWithFloat:  mapAnnotObject.coordinate.latitude];
    NSNumber *myPlaceLong= [NSNumber numberWithFloat: mapAnnotObject.coordinate.longitude];
    // NSDictionary* dict = [NSDictionary dictionaryWithObject:
    //                     pin.annotation.title
    //                                              forKey:@"myTitle"];
    
    NSDictionary* dict = [[[NSDictionary alloc] initWithObjectsAndKeys:  mapAnnotObject.title, @"myTitle", myPlaceLat, @"planLatitude", myPlaceLong, @"planLongitude",nil] autorelease];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"DidSelectPlace"
                                                        object:self
                                                      userInfo:dict]; 
    
    /*[UIView animateWithDuration:1.1
                     animations:^{self.navigationController.view.frame = CGRectMake(0, 420, 320, 420);}
                     completion:^(BOOL finished){ [self.navigationController.view removeFromSuperview]; }];
     */
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}

-(void)selectPlace
{
    
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
/*- (void)viewDidLoad
{
    [mpView selectAnnotation:mapAnnotObject animated:NO];
    [super viewDidLoad];
}*/


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
