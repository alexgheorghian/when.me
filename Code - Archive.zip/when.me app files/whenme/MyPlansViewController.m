//
//  SecondViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "MyPlansViewController.h"
#import "SharePlanViewController.h"
#import "GAI.h"
#import "SignupTableViewController.h"
#import "UserTableViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface MyPlansViewController ()

@end

@implementation MyPlansViewController

@synthesize managedObjectContext;
@synthesize plansArray;
@synthesize pastPlansArray;
@synthesize tablePlansArray;
@synthesize photoButton;
@synthesize photoButtonImage;
@synthesize isLoggedIn;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"My Plans";
        self.tabBarItem.image = [UIImage imageNamed:@"851-calendar"];
        plansArray = [[NSMutableArray alloc]init];
    }
    return self;
}


							
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
     isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    //self.navigationController.navigationBar.tintColor=[UIColor grayColor];
    //load plans from core data
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Plan" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"planDate" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptors];
    
    NSError *error = nil;
    NSMutableArray *mutableFetchResults = [[managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResults == nil) {
        NSLog(@"There was an error fetching the data");
    }
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
        
    }
    
    
    
    photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    photoButton.frame = CGRectMake(0, 0, 41, 41);
    [photoButton addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
    
    //photoButton.layer.borderWidth=1;
    //photoButton.layer.borderColor=[UIColor lightGrayColor].CGColor;
    
    UIBarButtonItem *aBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:photoButton];
    self.navigationController.topViewController.navigationItem.leftBarButtonItem = aBarButtonItem2;
    
   
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"my_plans"];
    
    [self setPlansArray:mutableFetchResults];
}

- (void)viewWillAppear:(BOOL)animated {
    NSLog(@"I am here");
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
        //[myPicture setImage:img]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
    }
    
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    //load plans from core data
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSFetchRequest *requestPast = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Plan" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    [requestPast setEntity:entity];
    NSDate *today = [NSDate date];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"planDate" ascending:YES];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(active=1) AND (planDate >= %@)", today];
    
    NSPredicate *pastPredicate = [NSPredicate predicateWithFormat:@"(active=1) AND (planDate < %@)", today];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptors];
    [request setPredicate:predicate];
    [requestPast setSortDescriptors:sortDescriptors];
    [requestPast setPredicate:pastPredicate];
    
    NSError *error = nil;
    NSMutableArray *mutableFetchResults = [[managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    NSMutableArray *mutableFetchResultsPast = [[managedObjectContext executeFetchRequest:requestPast error:&error] mutableCopy];
    
    if (mutableFetchResults == nil) {
        NSLog(@"There was an error fetching the data");
    }
    
    [self setPlansArray:mutableFetchResults];
    [self setPastPlansArray:mutableFetchResultsPast];
    NSMutableArray *array = [[NSMutableArray alloc] initWithObjects:plansArray, pastPlansArray, nil];
    [self setTablePlansArray:array];
    [self.tableView reloadData];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void) showUserPage{
    NSLog(@"I am in here");
    if (!isLoggedIn){
        SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"SignUp", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
    else{
        UserTableViewController* signupVC = [[UserTableViewController alloc]initWithNibName:@"UserTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"About me", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    NSInteger sections = [[self tablePlansArray] count];
	
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *sectionContents = [[self tablePlansArray] objectAtIndex:section];
    NSInteger rows = [sectionContents count];
	
    if (rows==0){
        rows=1;
    }
    
    return rows;
}




- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    

    if(section == 0)
        return @"Current Plans";
    else
        return @"Incomplete Plans";
   
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
   
    [headerView setBackgroundColor:[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1.00]];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 3, tableView.bounds.size.width - 10, 18)];
    if (section==0) {
    label.text = @"Current Plans";
    }
    else {
        label.text = @"Incomplete Plans";
    }
    label.textColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.75];
    label.backgroundColor = [UIColor clearColor];
    [headerView addSubview:label];
 
    return headerView;
   
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    NSArray *sectionContents = [[self tablePlansArray] objectAtIndex:[indexPath section]];
    NSInteger rows = [sectionContents count];
	
    if (rows==0){
        if ([indexPath section]==0){ 
        cell.textLabel.text=@"No plans saved.";
        }
        else {
            cell.textLabel.text=@"";
        }
         cell.textLabel.textColor=[UIColor grayColor];
        cell.detailTextLabel.text=@"";
        [cell setAccessoryType:UITableViewCellAccessoryNone];
        [cell.imageView setImage:[UIImage imageNamed:@"icon-plan.png"]];
        return cell;
        
    }
    
    Plan *plan = (Plan *)[sectionContents objectAtIndex:[indexPath row]];

    cell.textLabel.text=[plan planText];
    
    
    cell.textLabel.textColor=[UIColor brownColor];
    
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    NSDate *todayDate = [NSDate date];
    NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
    NSString *planDateString = [dateFormat stringFromDate:[plan planDate]];
    
    NSDate *today=[dateFormat dateFromString:todayDateString];
    NSDate *strDate=[dateFormat dateFromString:planDateString];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSWeekCalendarUnit|NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                               fromDate:today
                                                 toDate:strDate
                                                options:0];
    
    
    NSLog(@"%d years %d months %d weeks %d days %d hours %d minutes %d seconds",components.year,components.month,components.week,components.day,components.hour,components.minute,components.second);
    
    NSString *digitPicked;
    NSString *timeFramePicked;
    
    int years=components.year;
    int months=components.month;
    int weeks=components.week;
    int days=components.day;
    int hours=components.hour;
    int minutes=components.minute;
    
    if (components.year>0) {
        digitPicked=[NSString stringWithFormat:@"%d", years];
        if (years==1) {
            timeFramePicked=@"year from now";}
        else{
            timeFramePicked=@"years from now";
        }
    }
    else if (components.month>0) {
        digitPicked=[NSString stringWithFormat:@"%d", months];
        if (months==1) {
            timeFramePicked=@"month from now";}
        else{
            timeFramePicked=@"months from now";
        }
    }
    else if (components.week>0) {
        digitPicked=[NSString stringWithFormat:@"%d", weeks];
        if (weeks==1) {
            timeFramePicked=@"week from now";}
        else{
            timeFramePicked=@"weeks from now";
        }
    }
    else if (components.day>0) {
        digitPicked=[NSString stringWithFormat:@"%d", days];
        if (days==1) {
            timeFramePicked=@"day from now";}
        else{
            timeFramePicked=@"days from now";
        }
    }
    else if (components.hour>0){
        digitPicked=[NSString stringWithFormat:@"%d", hours];
        if (hours==1) {
            timeFramePicked=@"hour from now";}
        else{
            timeFramePicked=@"hours from now";
        }
    }
    
    else if (components.minute>0){
        digitPicked=[NSString stringWithFormat:@"%d", minutes];
        if (minutes==1) {
            timeFramePicked=@"minute from now";}
        else{
            timeFramePicked=@"minutes from now";
        }
    }
    
    else{
        digitPicked=@"";
        timeFramePicked=@"in the past";
        cell.textLabel.textColor=[UIColor grayColor];
    }
    
    [cell.imageView setImage:[UIImage imageNamed:@"icon-plan.png"]];
    
    if ([plan hasPlanPicture]==[NSNumber numberWithInt:1]){
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSManagedObjectID *localID = [plan objectID];
        NSURL *uri = [localID URIRepresentation];
        //NSData *uriData = [NSKeyedArchiver archivedDataWithRootObject:uri];
        
        //NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
        NSString *folderPath = [uri absoluteString];
        
        NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
        
        if(rangeOfSubstring.location == NSNotFound)
        {
            
        }
        
        folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
        
        NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
        NSLog(@"The image path is %@",imagePath);
        UIImage *img = [UIImage imageWithContentsOfFile:imagePath]; 
         
        [cell.imageView setImage:img];
        
        //cell.imageView.layer.borderColor = [UIColor brownColor].CGColor;
        
        //cell.imageView.layer.borderWidth = 2.0;
        //cell.imageView.layer.cornerRadius = 10.0;
        //cell.imageView.clipsToBounds = YES;
       
    }
    else {
    [cell.imageView setImage:[UIImage imageNamed:@"icon-plan.png"]];
    }
    
    
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ %@", digitPicked, timeFramePicked];
     
return cell;
}



/*- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}*/

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:235.0/255 green:235.0/255 blue:235.0/255 alpha:1]];
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSString *str = [[plansArray objectAtIndex:indexPath.row] stringValue];
    NSArray *sectionContents = [[self tablePlansArray] objectAtIndex:[indexPath section]];
    NSInteger rows = [sectionContents count];
	
    if (rows==0){
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    else{
    Plan *plan = (Plan *)[sectionContents objectAtIndex:[indexPath row]];
    NSString *planText=[plan planText];
    NSNumber *planLatitude=[plan latitude];
    NSNumber *planLongitude=[plan longitude];
    
    NSNumber *hasPlanPicture=[plan hasPlanPicture];    
    NSNumber *hasCompletePicture=[plan hasCompletePicture]; 
    NSString *uniqueIDString=[plan uniqueID];
    NSNumber *locationOverride=[plan locationOverride];
        
        NSLog (@"These values are %@, %@",hasPlanPicture,hasCompletePicture);
    
        NSTimeZone *timeZone = [NSTimeZone localTimeZone];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setTimeZone:timeZone];	
        [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
        NSDate *todayDate = [NSDate date];
        NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
        NSString *planDateString = [dateFormat stringFromDate:[plan planDate]];
        
        NSDate *today=[dateFormat dateFromString:todayDateString];
        NSDate *strDate=[dateFormat dateFromString:planDateString];
        
        
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [calendar components:NSYearCalendarUnit|NSMonthCalendarUnit|NSWeekCalendarUnit|NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                                   fromDate:today
                                                     toDate:strDate
                                                    options:0];
        
        
        NSLog(@"%d years %d months %d weeks %d days %d hours %d minutes %d seconds",components.year,components.month,components.week,components.day,components.hour,components.minute,components.second);
        
        NSString *digitPicked;
        NSString *timeFramePicked;
        
        int years=components.year;
        int months=components.month;
        int weeks=components.week;
        int days=components.day;
        int hours=components.hour;
        int minutes=components.minute;
        
        if (components.year>0) {
            digitPicked=[NSString stringWithFormat:@"%d", years];
            if (years==1) {
                timeFramePicked=@"year from now";}
            else{
                timeFramePicked=@"years from now";
            }
        }
        else if (components.month>0) {
            digitPicked=[NSString stringWithFormat:@"%d", months];
            if (months==1) {
                timeFramePicked=@"month from now";}
            else{
                timeFramePicked=@"months from now";
            }
        }
        else if (components.week>0) {
            digitPicked=[NSString stringWithFormat:@"%d", weeks];
            if (weeks==1) {
                timeFramePicked=@"week from now";}
            else{
                timeFramePicked=@"weeks from now";
            }
        }
        else if (components.day>0) {
            digitPicked=[NSString stringWithFormat:@"%d", days];
            if (days==1) {
                timeFramePicked=@"day from now";}
            else{
                timeFramePicked=@"days from now";
            }
        }
        else if (components.hour>0){
            digitPicked=[NSString stringWithFormat:@"%d", hours];
            if (hours==1) {
                timeFramePicked=@"hour from now";}
            else{
                timeFramePicked=@"hours from now";
            }
        }
        
        else if (components.minute>0){
            digitPicked=[NSString stringWithFormat:@"%d", minutes];
            if (minutes==1) {
                timeFramePicked=@"minute from now";}
            else{
                timeFramePicked=@"minutes from now";
            }
        }
        
        else{
            digitPicked=@"";
            timeFramePicked=@"in the past";
         
        }
    
        
    /*NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeZone:timeZone];	
    [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
    NSString *dateString = [dateFormat stringFromDate:[plan planDate]];
    
    NSDate *todayDate = [NSDate date];
    NSString *todayDateString = [dateFormat stringFromDate:todayDate];  
    NSString *planDateString = [dateFormat stringFromDate:[plan planDate]];
    
    NSDate *today=[dateFormat dateFromString:todayDateString];
    NSDate *strDate=[dateFormat dateFromString:planDateString];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
                                               fromDate:today
                                                 toDate:strDate
                                                options:0];
    
    
    NSLog(@"%d days %d hours %d minutes %d seconds",components.day,components.hour,components.minute,components.second);
    
    NSString *digitPicked;
    NSString *timeFramePicked;
    if (components.day>0) {
        digitPicked=[NSString stringWithFormat:@"%d", components.day+1];
        timeFramePicked=@"days from now";
    }
    else if (components.hour>0){
        digitPicked=[NSString stringWithFormat:@"%d", components.hour];
        timeFramePicked=@"hours from now";
    }
    
    else if (components.minute>0){
        digitPicked=[NSString stringWithFormat:@"%d", components.minute];
        timeFramePicked=@"minutes from now";
    }
    
    else{
        digitPicked=@"";
        timeFramePicked=@"in the past";
    }*/
          NSString *dateString = [dateFormat stringFromDate:[plan planDate]];

  
    NSManagedObjectID *localID = [plan objectID];
    NSURL *uri = [localID URIRepresentation];
    NSData *uriData = [NSKeyedArchiver archivedDataWithRootObject:uri];
    
    
        NSMutableDictionary *myPlan;
    
        if (uniqueIDString==nil){
            
            
            myPlan= [[NSMutableDictionary alloc] initWithObjectsAndKeys:dateString, @"planDate", planText, @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",uriData,@"localID",hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",locationOverride,@"locationOverride",[NSNull null], @"uniqueID", planLatitude,@"latitude",planLongitude,@"longitude", nil];
           
        } else {
        
      myPlan = [[NSMutableDictionary alloc] initWithObjectsAndKeys:dateString, @"planDate", planText, @"planText", digitPicked, @"planDigitPicked", timeFramePicked, @"planTimeFramePicked",uriData,@"localID",hasPlanPicture,@"hasPlanPicture",hasCompletePicture,@"hasCompletePicture",locationOverride,@"locationOverride",uniqueIDString, @"uniqueID", planLatitude,@"latitude",planLongitude,@"longitude", nil];
        }
    
    
    SharePlanViewController *sharePlanView=[[SharePlanViewController alloc] initWithData:myPlan nibName:@"SharePlanViewController" bundle:nil];
    
    sharePlanView.managedObjectContext = self.managedObjectContext;
    
    [self.navigationController pushViewController:sharePlanView animated:YES];
    }
    
    //parsing for latitude and longitude
    
    /*double lat = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:0]stringValue]doubleValue];
    
    double lng = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:1] stringValue] doubleValue];
    
    CLLocationCoordinate2D _cords = {lat,lng};
    
    mapViewC = [[MapViewController alloc]initWithNibName:nil bundle:nil placeName:str andCoordinates:_cords];
    
    [self.navigationController pushViewController:mapViewC animated:YES];*/
    
    
    
}


@end
