//
//  FirstViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "PlanViewController.h"

#import <QuartzCore/QuartzCore.h>

@interface PlanViewController ()


@end

@implementation PlanViewController


@synthesize backGround; 
@synthesize logo;
@synthesize iamgoingto;
@synthesize addButton;
@synthesize mapButton;
@synthesize calendarButton;
@synthesize myDigitPickerView;
@synthesize myTimeFramePickerView;
@synthesize myDateTimePickerView;
@synthesize digitsArray;
@synthesize timeFrameArray;
@synthesize planTextView;
@synthesize myPhoto;
@synthesize navController;
@synthesize navBar;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //self.title = NSLocalizedString(@"First", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"icon-compose"];
       
    }
    return self;
}
							
- (void)viewDidLoad
{
    //self.title=@"when.me";
    navController = [[UINavigationController alloc] init];
    navBar = [[UINavigationBar alloc] init];
    [self.view addSubview:navBar];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
     [backGround setImage:[UIImage imageNamed:@"background-jeans.png"]] ;
     [logo setImage:[UIImage imageNamed:@"whenme.png"]];
     [iamgoingto setImage:[UIImage imageNamed:@"iamgoingto.png"]];
    //[myPhoto setImage:[UIImage imageNamed:@"addPhoto.png"]];
    
    planTextView.layer.cornerRadius = 10;
    planTextView.contentInset = UIEdgeInsetsMake(10, 10, 10, 10);
    planTextView.returnKeyType=UIReturnKeyDone;

    mapButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    mapButton.frame = CGRectMake(270,147, 45,45);
    mapButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [mapButton addTarget:self action:@selector(showMap) forControlEvents:UIControlEventTouchUpInside];
    [mapButton setBackgroundImage:[UIImage imageNamed:@"button-compass.png"] forState:UIControlStateNormal]; //sets the Background image 
    
    [mapButton setImage:[UIImage imageNamed:@"button-compass.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:mapButton ];
    
    UIImageView *imgPickerView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 205, 320, 162)];
    imgPickerView.image = [UIImage imageNamed:@"pickerBackground.png"];
    [self.view addSubview:imgPickerView];
    
    pickerSelected=0;
    myDateTimePickerView = [[UIDatePicker alloc] init];
   
    myDateTimePickerView.frame = CGRectMake(320,205, 320, 162);
    myDateTimePickerView.datePickerMode = UIDatePickerModeDateAndTime;
    myDateTimePickerView.hidden = NO;
    myDateTimePickerView.date = [NSDate date];
    
    [myDateTimePickerView addTarget:self
                   action:@selector(dateTimePickerChange)
         forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:myDateTimePickerView];
    
    
    
    digitsArray=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"30",@"60",nil];
    
    myDigitPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(15, 205, 70, 162)];
    myDigitPickerView.delegate = self;
    myDigitPickerView.showsSelectionIndicator = YES;
    [myDigitPickerView selectRow:1 inComponent:0 animated:NO];
    [self.view addSubview:myDigitPickerView];
    
    
    timeFrameArray=[NSArray arrayWithObjects:@"minutes from now",@"hours from now",@"days from now",@"weeks from now",@"months from now", @"years from now",nil];
    
    myTimeFramePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(80, 205, 225, 162)];
    myTimeFramePickerView.delegate = self;
    myTimeFramePickerView.showsSelectionIndicator = YES;
    [myTimeFramePickerView selectRow:1 inComponent:0 animated:NO];
    [self.view addSubview:myTimeFramePickerView];
    
  
    
    addButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    addButton.frame = CGRectMake(0,368, 320,43);
    addButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [addButton addTarget:self action:@selector(addPlan) forControlEvents:UIControlEventTouchUpInside];
    [addButton setBackgroundImage:[UIImage imageNamed:@"button-add.png"] forState:UIControlStateNormal]; //sets the Background image 
    
    [addButton setImage:[UIImage imageNamed:@"button-add.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:addButton ];
    
    
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(23, 175, 95, 40)];
    imgView.image = [UIImage imageNamed:@"when.png"];
    [self.view addSubview:imgView];
    
    UISwipeGestureRecognizer *swipeGestureLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swapPickerLeft)];
    swipeGestureLeft.numberOfTouchesRequired = 1;
    swipeGestureLeft.direction = (UISwipeGestureRecognizerDirectionLeft);
    
    [self.view addGestureRecognizer:swipeGestureLeft];
    
    UISwipeGestureRecognizer *swipeGestureRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swapPickerRight)];
    swipeGestureRight.numberOfTouchesRequired = 1;
    swipeGestureRight.direction = (UISwipeGestureRecognizerDirectionRight);
    
    [self.view addGestureRecognizer:swipeGestureRight];
    navController = [[UINavigationController alloc] init];
    navBar = [[UINavigationBar alloc] init];
    [self.view addSubview:navBar];
    
   
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void) addPlan
{
    NSLog(@"Adding plan");
}

- (void) showMap
{
    //[UIView beginAnimations:nil context:nil];
	//[UIView setAnimationDuration:1.0];
	//[UIView setAnimationTransition:UIViewAnimationTransitionNone
						   //forView:[self view]
							 //cache:YES];
    
    PlacesTableViewController *obj = [[PlacesTableViewController alloc]init];
    obj.view.frame = CGRectMake(0, 0, 320, 200);
    obj.title = @"Banks of LA";
    //[self.window addSubview:obj.view];
    
    
    //UINavigationController *navC = [[UINavigationController alloc] init];
    [navController pushViewController:obj animated:YES];
    
    //[self presentViewController:navC animated:YES completion:NULL];


    
    //[UIView commitAnimations];
}

- (void) dateTimePickerChange
{
    NSLog(@"dateTimePickerChange");
}

- (void) swapPickerLeft
{
    NSLog(@"swapping picker");
    
    if (pickerSelected==0){
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform = CGAffineTransformMakeTranslation(-300, 0);
	myTimeFramePickerView.transform = transform;

	[UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform2 = CGAffineTransformMakeTranslation(-380, 0);
	myDigitPickerView.transform = transform2;
	[UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	CGAffineTransform transform3 = CGAffineTransformMakeTranslation(-320, 0);
	myDateTimePickerView.transform = transform3;
	[UIView commitAnimations];
    pickerSelected=1;
    }
        
}

-(void) swapPickerRight
{
    if(pickerSelected==1){
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
    myTimeFramePickerView.transform = transform;
    
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform2 = CGAffineTransformMakeTranslation(0, 0);
    myDigitPickerView.transform = transform2;
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    CGAffineTransform transform3 = CGAffineTransformMakeTranslation(0, 0);
    myDateTimePickerView.transform = transform3;
    [UIView commitAnimations];
    pickerSelected=0;
    }
}

#pragma Uipicker delegate methods
- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component {
    if (pickerView==myDigitPickerView){
        NSLog(@"%@",[digitsArray objectAtIndex:row]);
        
        int pickednumber = [[digitsArray objectAtIndex:row] intValue];
        
        if (pickednumber>1){
            timeFrameArray=[NSArray arrayWithObjects:@"minutes from now",@"hours from now",@"days from now",@"weeks from now",@"months from now", @"years from now",nil];
            [myTimeFramePickerView reloadAllComponents];

        }
        else{
            timeFrameArray=[NSArray arrayWithObjects:@"minute from now",@"hour from now",@"day from now",@"week from now",@"month from now", @"year from now",nil];
            [myTimeFramePickerView reloadAllComponents];
        }
       
        
    }
}

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return ( pickerView == myDigitPickerView ? 26 : 6 );
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return ( pickerView == myDigitPickerView ? 1 : 1 );
}

// tell the picker the title for a given component
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    NSArray *values = ( pickerView == myDigitPickerView ? digitsArray : timeFrameArray );
    return [values objectAtIndex: row];
   
}

// tell the picker the width of each row for a given component
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return ( pickerView == myDigitPickerView ? 50 : 200 );
    
  
}

#pragma textview delegate methods

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range  replacementText:(NSString *)text
{
	if (range.length==0) {
		if ([text isEqualToString:@"\n"]) {
			[textView resignFirstResponder];
			return NO;
		}
	}
	
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    if(![textView.text isEqualToString:@""]){
        textView.text = @"";
        textView.textColor=[UIColor blackColor];
    }
}


@end
