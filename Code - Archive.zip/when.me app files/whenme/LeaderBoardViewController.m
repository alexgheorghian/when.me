//
//  FeedViewControllerViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "JoinPlanViewController.h"
#import "LeaderBoardViewController.h"
#import "JSON.h"
#import "GAI.h"
#import "SDWebImage/UIImageView+WebCache.h"

@interface LeaderBoardViewController ()

@end

@implementation LeaderBoardViewController

@synthesize responseData;
@synthesize hud = _hud;
@synthesize leadersArray;
@synthesize toolbar;
@synthesize segControl;
@synthesize tv;
@synthesize managedObjectContext;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Leaderboard";
        self.tabBarItem.image = [UIImage imageNamed:@"icon-group"];
        leadersArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    feedType=0;
    [super viewDidLoad];
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }
    
    toolbar = [[UIToolbar alloc] init];
    //toolbar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    //toolbar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    toolbar.tintColor = [UIColor colorWithRed:200.0f/255.0f green:176.0f/255.0f blue:156.0f/255.0f alpha:1.0f];;
    if(phoneVersion<5){
    toolbar.frame=CGRectMake(0,387, 320, 44);
    }
    else {
       toolbar.frame=CGRectMake(0,475, 320, 44);
    }
    segControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Everyone", @"My Friends", nil]];
    segControl.selectedSegmentIndex=0;
    //segControl.tintColor=[UIColor brownColor];
    segControl.segmentedControlStyle=UISegmentedControlStyleBar;
    [segControl addTarget:self
                   action:@selector(segmentSwitch)
         forControlEvents:UIControlEventValueChanged];
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:segControl];
    toolbar.items = [NSArray arrayWithObjects:flexibleSpace,btnItem,flexibleSpace, nil];
    [self.navigationController.view addSubview:toolbar];
    
    
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:@"Refresh" style:UIBarButtonItemStylePlain target:self action:@selector(refreshTimeline)];          
    anotherButton.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
    self.navigationController.topViewController.navigationItem.rightBarButtonItem = anotherButton;
    //NSManagedObjectContext *context = [self managedObjectContext];
    //if (!context) {
    //    NSLog(@"No context on feed page");
    //}
    // Pass the managed object context to the view controller.
    //self.managedObjectContext = context;
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"learer_board"];
    [self refreshTimeline];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated{
    toolbar.hidden=NO;
}

- (void)viewWillDisappear:(BOOL)animated{
    toolbar.hidden=YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


-(void) segmentSwitch{
    
    feedType=segControl.selectedSegmentIndex;
    [self refreshTimeline];
    
}

-(void)refreshTimeline
{
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Loading leaderboard...";
    responseData = [NSMutableData data];
    
    const char *bytes;
    NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/leaderboard.aspx"];
    
    NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
    if (userID==nil){
        userID=@"0";
    }
    if (feedType==0){ //everyone
        bytes= [[NSString stringWithFormat:@"sort=0&userID=%@",userID] UTF8String];
    }
    else if (feedType==1) { //myfriends
        bytes= [[NSString stringWithFormat:@"sort=1&userID=%@",userID] UTF8String];
        
    }
  
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    
    [self.hud hide:YES];
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	NSLog(@"%@",s);
    NSMutableDictionary *myData=[s JSONValue];
    
    leadersArray=[myData objectForKey: @"leaders"];
    
    //plansArray=[NSArray arrayWithArray:(NSArray *)[values valueForKey:@"plans"]];;
    [self.tv reloadData];
    
    //[self performSelector:@selector(checkIt) withObject:nil afterDelay:1.5];
    //[connection release];
	
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    NSInteger sections = 1;
	
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSInteger rows = [leadersArray count];
	NSLog(@"The number of rows is %d",rows);
    return rows;
}







- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    
    [cell.imageView setImageWithURL:[NSURL URLWithString:[[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"]]
                   placeholderImage:[UIImage imageNamed:@"addPhoto.png"]];
    cell.textLabel.text=[[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"tokens"];
    cell.textLabel.textColor=[UIColor brownColor];
    
 
    
    cell.detailTextLabel.text = [[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"username"];
    cell.textLabel.adjustsFontSizeToFitWidth = YES; 
    cell.textLabel.numberOfLines = 1;
    return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:235.0/255 green:235.0/255 blue:235.0/255 alpha:1]];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"You tapped %d",[indexPath row]);   
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //[self showJoinSheet:[indexPath row]];
    //NSString *str = [[plansArray objectAtIndex:indexPath.row] stringValue];
    
  
    NSString *username=[[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"username"];
    NSString *userImage=[[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"userImage"];
    NSString *userTokens=[[leadersArray objectAtIndex:[indexPath row]] valueForKey:@"userTokens"];
    NSNumber *locationOverride=[NSNumber numberWithInt:0];
    
    

}    






- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
