//
//  SettingsViewController.m
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "SettingsViewController.h"
#import "SHK.h"
#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "whenMeConstants.h"
#import "UserTableViewController.h"
#import "privacyPolicyViewController.h"
#import "TermsOfUseViewController.h"
#import "SignupTableViewController.h"
#import "InviteFriendsViewController.h"
#import "GAI.h"
#import <QuartzCore/QuartzCore.h>

@interface SettingsViewController ()

@end

@implementation SettingsViewController

@synthesize photoButton;
@synthesize photoButtonImage;
@synthesize isLoggedIn;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title=@"Settings";
        self.tabBarItem.image = [UIImage imageNamed:@"740-gear"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    
     //NSLog(@"The value for sharing override in vie did load is is %d",[[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]);
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
        
    }
    
    
    
    photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];
    photoButton.frame = CGRectMake(252, 105, 40, 40);
    [photoButton addTarget:self action:@selector(showUserPage) forControlEvents:UIControlEventTouchUpInside];
    
    //photoButton.layer.borderWidth=1;
   // photoButton.layer.borderColor=[UIColor lightGrayColor].CGColor;
    
    UIBarButtonItem *aBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:photoButton];
    self.navigationController.topViewController.navigationItem.leftBarButtonItem = aBarButtonItem2;
     
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"settings"];

    // Do any additional setup after loading the view from its nib.
}

- (void) viewWillAppear:(BOOL)animated{
    facebookConnected=[SHKFacebook isServiceAuthorized];
    twitterConnected=[SHKTwitter isServiceAuthorized];
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        photoButtonImage = [UIImage imageWithContentsOfFile:getImagePath]; 
        //[myPicture setImage:img]; 
    }
    else {
        photoButtonImage= [UIImage imageNamed:@"addPhoto.png"];
    }
    
    [photoButton setImage:photoButtonImage forState:UIControlStateNormal];

    
NSString *facebookStr;
NSString *twitterStr;

NSString *privacyToggle;
NSString *tutorialToggle;

NSString *aboutMe;
NSString *inviteFriends;
NSString *termsOfUse; 

if([[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED]){
    aboutMe = @"About Me";
}
else {
    aboutMe = @"Sign Up"; 
}
inviteFriends= @"Invite Friends";
termsOfUse = @"Terms Of Use";


privacyToggle=@"Disable All Sharing";
tutorialToggle=@"Show tutorial again";
if (facebookConnected==NO){
    facebookStr = @"Connect Facebook";
}
else{
    facebookStr = @"Disconnect Facebook";
}
if (twitterConnected==NO){
    twitterStr = @"Connect Twitter";
}
else{
    twitterStr = @"Disconnect Twitter";
}

//tblSimpleTable.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background-tan.png"]];

arrAccount  = [[NSArray alloc] initWithObjects:aboutMe,inviteFriends,termsOfUse,nil];
arrShareKit = [[NSArray alloc] initWithObjects:facebookStr,twitterStr,nil];
arrPrivacy =  [[NSArray alloc] initWithObjects:@"Privacy Policy",privacyToggle,nil];
arrGeneral =  [[NSArray alloc] initWithObjects:@"Show tutorial again",nil];


    [tblSimpleTable reloadData];

    
}

- (void) showUserPage{
    NSLog(@"I am in here");
    if (!isLoggedIn){
        SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"SignUp", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
    else{
        UserTableViewController* signupVC = [[UserTableViewController alloc]initWithNibName:@"UserTableViewController" bundle:nil];
        signupVC.title = NSLocalizedString(@"About me", @"");
        [self.navigationController pushViewController:signupVC  animated:YES];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) authorizeFacebook{
    //[self toggleFacebook];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS." ]; 
    NSURL *url = [NSURL URLWithString:@"http://www.when.me"];
    NSString *urlImage = @"http://www.when.me//images/icon.png";
    
  
    SHKItem *item = [SHKItem URL:url title:shareTitle];
      [item setCustomValue:urlImage forKey:@"image"];
    // Share the item
    [SHKFacebook shareItem:item];

    
    //hack
    NSString *facebookStr;
    NSString *twitterStr;
    facebookConnected=YES;
    if (facebookConnected==NO){
        facebookStr = @"Connect Facebook";
    }
    else{
        facebookStr = @"Disconnect Facebook";
    }
    if (twitterConnected==NO){
        twitterStr = @"Connect Twitter";
    }
    else{
        twitterStr = @"Disconnect Twitter";
    }
    
    arrShareKit = [[NSArray alloc] initWithObjects:facebookStr,twitterStr,nil];
    [tblSimpleTable reloadData];
    
    
}

- (void) authorizeTwitter{
    NSString *facebookStr;
    NSString *twitterStr;
    twitterConnected=YES;
    if (facebookConnected==NO){
        facebookStr = @"Connect Facebook";
    }
    else{
        facebookStr = @"Disconnect Facebook";
    }
    if (twitterConnected==NO){
        twitterStr = @"Connect Twitter";
    }
    else{
        twitterStr = @"Disconnect Twitter";
    }
    
    arrShareKit = [[NSArray alloc] initWithObjects:facebookStr,twitterStr,nil];
    [tblSimpleTable reloadData];
    //[self toggleTwitter];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://www.when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    
    // Share the item
    [SHKTwitter shareItem:item];
   
    
    
}

-(void) disconnectFacebook{
    NSString *myMessage=[NSString stringWithFormat:@"Are you sure you want to disconnect Facebook?"];
    
    
    UIAlertView *alertDialog;
    //UILocalNotification *scheduledAlert;
    alertDialog = [[UIAlertView alloc]
                   initWithTitle: @"Disconnect Facebook "
                   message:myMessage
                   
                   delegate: self
                   cancelButtonTitle: @"Not Now"
                   otherButtonTitles: nil];
    [alertDialog addButtonWithTitle:@"Yes"];
    [alertDialog setTag:1];
    [alertDialog show];
  
}

-(void) disconnectTwitter{
    NSString *myMessage=[NSString stringWithFormat:@"Are you sure you want to disconnect Twitter?"];
    
    
    UIAlertView *alertDialog;
    //UILocalNotification *scheduledAlert;
    alertDialog = [[UIAlertView alloc]
                   initWithTitle: @"Disconnect Twitter "
                   message:myMessage
                   
                   delegate: self
                   cancelButtonTitle: @"Not Now"
                   otherButtonTitles: nil];
    [alertDialog addButtonWithTitle:@"Yes"];
    [alertDialog setTag:2];
    [alertDialog show];
}

- (void) toggleFacebook {
    //facebookShare=!facebookShare;
    
    if (facebookConnected==NO){
        facebookConnected=YES;
        
        
    }
    else{
        facebookConnected=NO;
    }
}

- (void) toggleTwitter {
    
    if (twitterConnected==NO){
        twitterConnected=YES;
        
        
    }
    else{
        twitterConnected=NO;
        
    }
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
 
    return 4;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == 0)
		return [arrAccount count];
    else if(section == 1)
		return [arrShareKit count];
	else if (section==2)
		return [arrPrivacy count];
    else if (section==3)
		return [arrGeneral count];
    else return 0;

    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	NSString *title;
    title=@"";
    if(section == 0){
		title= @"My when.me Account:";
	}
    if(section == 1){
		title= @"My Share Services:";
	}
    if (section==2){
		title= @"Privacy Settings";
	}
    if (section==3){
		title= @"General Settings";
	}
    return title;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
	if (section ==0){
        return @"";
    }
    else if(section == 1){
		return @"";
	}
    else if(section == 2){
		return @"Toggle to disable sharing on all public services including when.me";
	}
    else if(section == 3){
		return @"";
	}
    
    else {
        return 0;
    }
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell;
    if (cell == nil) {
         cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];    }
    

    
    // Set up the cell...
	if(indexPath.section == 0){
        cell.textLabel.text = [arrAccount objectAtIndex:indexPath.row];
         [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    
   if(indexPath.section == 1){
		cell.textLabel.text = [arrShareKit objectAtIndex:indexPath.row];
        if([arrShareKit objectAtIndex:indexPath.row]==@"Connect Facebook" || [arrShareKit objectAtIndex:indexPath.row]==@"Connect Twitter" ){
        
        }
        if([arrShareKit objectAtIndex:indexPath.row]==@"Disconnect Facebook" || [arrShareKit objectAtIndex:indexPath.row]==@"Disconnect Twitter" ){
        [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        }
   }
    
    if(indexPath.section == 2){
		cell.textLabel.text = [arrPrivacy objectAtIndex:indexPath.row];
        if([arrPrivacy objectAtIndex:indexPath.row]==@"Privacy Policy"){
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        }
         if([arrPrivacy objectAtIndex:indexPath.row]==@"Disable All Sharing"){
       cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
             UISwitch *switchView = [[UISwitch alloc] initWithFrame:CGRectZero];
                  [switchView addTarget:self action:@selector(privacySwitchChanged:) forControlEvents:UIControlEventValueChanged];
             
             NSLog(@"The value for sharing override is %d",[[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]);
             if([[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]){
                 
                 [switchView setOn:YES animated:NO];
             }
             else{
                 [switchView setOn:NO animated:NO];
             }

        cell.accessoryView = switchView;
               
         }
    
	}
    
    if(indexPath.section == 3){
		NSLog(@"I am in section 3");
        cell.textLabel.text = [arrGeneral objectAtIndex:indexPath.row];
        
        if([[arrGeneral objectAtIndex:indexPath.row] isEqualToString:@"Show tutorial again"]){
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            UISwitch *aswitchView = [[UISwitch alloc] initWithFrame:CGRectZero];
            [aswitchView addTarget:self action:@selector(tutorialSwitchChanged:) forControlEvents:UIControlEventValueChanged];
            
            [aswitchView setOn:NO animated:NO];
            
            cell.accessoryView = aswitchView;
            
            
        }
    }
    

    
  


    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
    if(indexPath.section == 0){
        if([arrAccount objectAtIndex:indexPath.row]==@"About Me"){
            UserTableViewController* signupVC = [[UserTableViewController alloc]initWithNibName:@"UserTableViewController" bundle:nil];
            signupVC.title = NSLocalizedString(@"About me", @"");
            [self.navigationController pushViewController:signupVC  animated:YES];
         
        }
        
        if([arrAccount objectAtIndex:indexPath.row]==@"Sign Up"){
            SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
            signupVC.title = NSLocalizedString(@"SignUp", @"");
            [self.navigationController pushViewController:signupVC  animated:YES];
            
        }
        
         if([arrAccount objectAtIndex:indexPath.row]==@"Invite Friends"){
             InviteFriendsViewController* inviteVC = [[InviteFriendsViewController alloc]initWithNibName:@"InviteFriendsViewController" bundle:nil];
             inviteVC.title = NSLocalizedString(@"Invite Friends", @"");
             [self.navigationController pushViewController:inviteVC  animated:YES];
         }
        
        if([arrAccount objectAtIndex:indexPath.row]==@"Terms Of Use"){
            TermsOfUseViewController* privacyView = [[TermsOfUseViewController alloc]initWithNibName:@"TermsOfUseViewController" bundle:nil];
            privacyView.title = NSLocalizedString(@"Terms Of Use", @"");
            [self.navigationController pushViewController:privacyView  animated:YES];
        }
    }
    
    
    if(indexPath.section == 1){
    if([arrShareKit objectAtIndex:indexPath.row]==@"Connect Facebook"){
        //hack to change table. better way?
        
        
        [tblSimpleTable deselectRowAtIndexPath:[tblSimpleTable indexPathForSelectedRow] animated:NO];
        [self authorizeFacebook];
    }
    
    else if([arrShareKit objectAtIndex:indexPath.row]==@"Disconnect Facebook"){
        [self disconnectFacebook];
    }
    
    else if([arrShareKit objectAtIndex:indexPath.row]==@"Connect Twitter"){
        [self authorizeTwitter];
    }
    
    else if([arrShareKit objectAtIndex:indexPath.row]==@"Disconnect Twitter"){
        [self disconnectTwitter];
    }
        
    }
    
     if(indexPath.section == 2){
      if([arrPrivacy objectAtIndex:indexPath.row]==@"Privacy Policy"){
          privacyPolicyViewController* privacyView = [[privacyPolicyViewController alloc]initWithNibName:@"privacyPolicyViewController" bundle:nil];
          privacyView.title = NSLocalizedString(@"Privacy Policy", @"");
          [self.navigationController pushViewController:privacyView  animated:YES];

      }
     }
    if (indexPath.section == 3){
        
    }

}

- (void) privacySwitchChanged:(id)sender {
   
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]){
        NSLog(@"setting sharing override to NO");
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"sharingOverride"];
    }
    else{
        NSLog(@"setting sharing override to YES");
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"sharingOverride"];
    }
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSLog(@"The value for sharing override is %d",[[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]);


}

- (void) tutorialSwitchChanged:(id)sender {
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"tutorialSeen"]){
        //NSLog(@"setting sharing override to NO");
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"tutorialSeen"];
    }
    else{
        //NSLog(@"setting sharing override to YES");
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"tutorialSeen"];
    }
    
    [[NSUserDefaults standardUserDefaults] synchronize];
  
    
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    NSLog(@"Here");
    if ([alertView tag] == 1) {    // it's the facebook logout alert
        if (buttonIndex == 1) {     // and they clicked Yes
            [SHKFacebook logout];
            facebookConnected=NO;
            NSString *facebookStr;
            NSString *twitterStr;
            if (facebookConnected==NO){
                facebookStr = @"Connect Facebook";
            }
            else{
                facebookStr = @"Disconnect Facebook";
            }
            if (twitterConnected==NO){
                twitterStr = @"Connect Twitter";
            }
            else{
                twitterStr = @"Disconnect Twitter";
            }
            
            arrShareKit = [[NSArray alloc] initWithObjects:facebookStr,twitterStr,nil];
            [tblSimpleTable reloadData];
        }
    }
    
    if ([alertView tag] == 2) {    // it's the twitter logout alert
        if (buttonIndex == 1) {     // and they clicked Yes
            
            [SHKTwitter logout];
            twitterConnected=NO; 
            NSString *facebookStr;
            NSString *twitterStr;
            if (facebookConnected==NO){
                facebookStr = @"Connect Facebook";
            }
            else{
                facebookStr = @"Disconnect Facebook";
            }
            if (twitterConnected==NO){
                twitterStr = @"Connect Twitter";
            }
            else{
                twitterStr = @"Disconnect Twitter";
            }
            
            arrShareKit = [[NSArray alloc] initWithObjects:facebookStr,twitterStr,nil];
            [tblSimpleTable reloadData];
            
        }
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
