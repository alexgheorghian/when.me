//
//  InviteFriendsViewController.h
//  whenme
//
//  Created by Eric English on 6/27/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import <AddressBookUI/AddressBookUI.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface InviteFriendsViewController : UIViewController<ABPeoplePickerNavigationControllerDelegate,UIActionSheetDelegate,MFMailComposeViewControllerDelegate>

@property (nonatomic, retain) NSMutableArray *userEmails;
@end
