//
//  SecondViewController.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Plan.h"
@interface MyPlansViewController : UITableViewController{

NSManagedObjectContext *managedObjectContext;
NSMutableArray *plansArray;
NSMutableArray *pastPlansArray;
NSMutableArray *tablePlansArray;

}

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) NSMutableArray *plansArray;
@property (nonatomic, retain) NSMutableArray *pastPlansArray;
@property (nonatomic, retain) NSMutableArray *tablePlansArray;

@property (strong, nonatomic) UIImage *photoButtonImage;
@property (strong, nonatomic) UIButton *photoButton;
@property (nonatomic) BOOL isLoggedIn;


@end
