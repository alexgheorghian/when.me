//
//  SignupTableViewController.m
//  ExSignup
//
//  Created by Nada Jaksic on 7/13/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UserTableViewController.h"
#import "SignupTableViewController.h"
#import "SignInTableViewController.h"
#import "KeychainWrapper.h"
#import "whenMeConstants.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <Twitter/Twitter.h>

#import <Accounts/Accounts.h>

#import "SHK.h"
#import "SHKFacebook.h"
#import "GAI.h"

@interface UserTableViewController ()
- (void)fetchData;
@property (strong, nonatomic) NSCache *usernameCache;
@property (strong, nonatomic) NSCache *imageCache;
@end

@implementation UserTableViewController
@synthesize cellUsername, cellEmail;
@synthesize txtUsername, txtEmail;
@synthesize responseData;
@synthesize hud = _hud;
@synthesize cellPicture;
@synthesize myPicture;

@synthesize accounts = _accounts;
@synthesize accountStore = _accountStore;

@synthesize imageCache = _imageCache;
@synthesize usernameCache = _usernameCache;
@synthesize timer;



#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad 
{
    [super viewDidLoad];
    NSLog(@"I am loading the view");
  
    self.title= @"About me";
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
	UIBarButtonItem* btnLogout = [[UIBarButtonItem alloc]initWithTitle:NSLocalizedString(@"Logout",@"") style:UIBarButtonItemStylePlain target:self action:@selector(logout)];
    btnLogout.tintColor=[UIColor colorWithRed:152.0/255 green:207.0/255 blue:149.0/255 alpha:1];
	[[self navigationItem] setRightBarButtonItem:btnLogout];
    
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(10, 165, 300, 200)] autorelease];
    //label.text = @"To share plans and places on when.me requires a free account. Once signed up you'll be able to join your friends and others around the world in sharing their upcoming plans and destinations.";
    // Colors and font
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:13];
    label.shadowColor = [UIColor colorWithWhite:0.8 alpha:0.8];
    label.textColor = [UIColor grayColor];
    // Automatic word wrap
    label.lineBreakMode = UILineBreakModeWordWrap;
    label.textAlignment = UITextAlignmentCenter;
    label.numberOfLines = 0;
    // Autosize
    [label sizeToFit];
    // Add the UILabel to the tableview
    [self.view addSubview:label];
    self.tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background-tan.png"]];
    txtEmail.autocorrectionType=UITextAutocorrectionTypeNo;
    txtEmail.autocapitalizationType = UITextAutocapitalizationTypeNone;
    txtEmail.userInteractionEnabled=NO;
    txtEmail.text=[[NSUserDefaults standardUserDefaults] valueForKey:@"emailaddress"];
    
    txtUsername.autocorrectionType=UITextAutocorrectionTypeNo;
    txtUsername.autocapitalizationType = UITextAutocapitalizationTypeNone;
    txtUsername.userInteractionEnabled=NO;
    txtUsername.text=[[NSUserDefaults standardUserDefaults] valueForKey:USERNAME];
    
    
    
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"userImageSaved"]){
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        NSLog(@"%@",getImagePath);
        UIImage *img = [UIImage imageWithContentsOfFile:getImagePath]; 
        [myPicture setImage:img]; 
    }
    else {
       [myPicture setImage:[UIImage imageNamed: @"addPhoto.png"]]; 
    }
    myPicture.contentMode = UIViewContentModeScaleAspectFit;
    
    //tryFaceBookPic=NO;
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"user_view"];
}




/*- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    NSLog(@"I am in the view will appear method");
    if (tryFaceBookPic==YES){
        NSLog(@"Getting facebook pic");
        UIImage *gotImage=[SHKFacebook getUserImage];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        NSData *webData = UIImagePNGRepresentation(gotImage);
        [webData writeToFile:imagePath atomically:YES];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
        [self uploadPhoto];
        
    }

}*/


/*- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"I am in the view will appear method");
    if (tryFaceBookPic==YES){
        
        UIImage *gotImage=[SHKFacebook getUserImage];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        NSData *webData = UIImagePNGRepresentation(gotImage);
        [webData writeToFile:imagePath atomically:YES];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
        [self uploadPhoto];
        
    }
}*/

/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 3;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{		
		if (indexPath.row == 0) {
			return cellUsername;
		}
		
		if (indexPath.row == 1) {
			return cellEmail;
		}
    if (indexPath.row == 2) {
        return cellPicture;
    }

	
	
		return nil;
}

- (CGFloat)tableView:(UITableView *)tblView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    int tableSize;
    if (indexPath.row==2) {
        tableSize= 60;
    }
    else{
        tableSize=44;
    }
    return tableSize;
    
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
	/*
	 <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
	 [self.navigationController pushViewController:detailViewController animated:YES];
	 [detailViewController release];
	 */
    
    if (indexPath.row==2){
        [self showPhotoSheet];
    }
}

-(IBAction)showPhotoSheet {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Add Profile Picture" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"From Photo Library",@"Take New Photo", @"Import From Twitter",@"Import From Facebook", nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleDefault;
    [popupQuery setTag:1];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
	[popupQuery release];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{ 
	[textField resignFirstResponder];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
	
}




#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}



- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result

	[self performSelector:@selector(checkIt) withObject:nil afterDelay:1.5];
    [connection release];
    

	
	
}

-(void) logout {
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Are you sure?" 
                                                        message:@"If you logout you will not be able to share plans on when.me until you log back in." 
                                                       delegate:self 
                                              cancelButtonTitle:@"Cancel" 
                                              otherButtonTitles:@"Logout",nil];
      [alertView setTag:1];
    [alertView show];
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    NSLog(@"Here");
    if ([alertView tag] == 1) {    // it's the alert
        if (buttonIndex == 1) {     // and they clickedlogout
            //do log out.
            
            self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            _hud.labelText = @"Logging out...";
            
            //[KeychainWrapper deleteItemFromKeychainWithIdentifier:PIN_SAVED];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:PIN_SAVED];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:USERNAME];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"password"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"emailaddress"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userID"];
            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"userImageSaved"];

            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [self performSelector:@selector(finishUp) withObject:nil afterDelay:1.5];
            
        }
    }
    
    
}


-(void) hideHud {
     [self.hud hide:YES];
}

-(void) finishUp {
  [self.hud hide:YES];
  [self.navigationController popViewControllerAnimated:YES];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	
    int actionSheetTag;
    
    actionSheetTag=[actionSheet tag];
    
    if (actionSheetTag==1){
        NSLog(@"Getting a photo and button pressed is %d",buttonIndex);
        
        if (buttonIndex == 0) {
            
            [self loadImageFromPicker];
            
        }
        else if (buttonIndex == 1) {
            [self getImageFromCamera];
            
            
        } else if (buttonIndex == 2) {
            [self getImageFromTwitter]; 
            
            
        } else if (buttonIndex == 3) {
            [self getImageFromFacebook];
            
            
        } else if (buttonIndex == 4) {
            
        }
    }
    
    if (actionSheetTag==2){
        NSLog(@"Selecting twitter account");
        if (buttonIndex==[self.accounts count]){
            NSLog(@"Dismiss action sheet");
        }
        else {
            
            self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            _hud.labelText = @"Connecting...";
            ACAccount *account = [self.accounts objectAtIndex:buttonIndex];
            TWRequest *fetchUserImageRequest = [[TWRequest alloc] 
                                                initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://api.twitter.com/1/users/profile_image/%@?size=bigger", account.username]] 
                                                parameters:nil
                                                requestMethod:TWRequestMethodGET];
            [fetchUserImageRequest performRequestWithHandler:^(NSData *imageData, NSHTTPURLResponse *urlResponse, NSError *error) {
                if ([urlResponse statusCode] == 200) {
                    _hud.labelText = @"Getting Image...";
                    UIImage *gotImage = [UIImage imageWithData:imageData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        
                        
                        
                        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                        NSString *documentsDirectory = [paths objectAtIndex:0];
                        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
                        NSData *webData = UIImagePNGRepresentation(gotImage);
                        [webData writeToFile:imagePath atomically:YES];
                        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
                        [self.hud hide:YES];
                        [self uploadPhoto];
                        
                        
                        
                    });
                }
            }]; 
            
        }
    }
    
    
}

-(void) getImageFromFacebook{
    
    BOOL faceBookAuth;
    faceBookAuth=[SHKFacebook isServiceAuthorized];
    if (faceBookAuth==YES){
        //get the photo
        //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        _hud.labelText = @"Getting Facebook Photo...";
        UIImage *gotImage=[SHKFacebook getUserImage];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        NSData *webData = UIImagePNGRepresentation(gotImage);
        [webData writeToFile:imagePath atomically:YES];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
        [self uploadPhoto];
    }
    else {
        [self authorizeFacebook];
    }

}

- (void) authorizeFacebook{

    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    
    // Share the item
    [SHKFacebook shareItem:item];
    timer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                             target: self
                                           selector:@selector(onTick:)
                                           userInfo: nil repeats:YES];
    
}

-(void) onTick:(NSTimer*)timer{
    NSLog(@"I'm checking facebook.");
    BOOL faceBookAuth;
    faceBookAuth=[SHKFacebook isServiceAuthorized];
    if (faceBookAuth==YES){
        NSLog(@"facebook authorized!");
        [self.timer invalidate];
        //get the photo
        //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        _hud.labelText = @"Getting Facebook Photo...";
        UIImage *gotImage=[SHKFacebook getUserImage];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
        NSData *webData = UIImagePNGRepresentation(gotImage);
        [webData writeToFile:imagePath atomically:YES];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
        [self uploadPhoto];
    }

    
}


-(void) getImageFromTwitter{
    
    _imageCache = [[NSCache alloc] init];
    [_imageCache setName:@"TWImageCache"];
    _usernameCache = [[NSCache alloc] init];
    [_usernameCache setName:@"TWUsernameCache"];
    _accountStore = nil;
    _accounts = nil;
    
    [self fetchData];
    
}

- (void)fetchData
{
    if (_accountStore == nil) {    
        self.accountStore = [[ACAccountStore alloc] init];
        if (_accounts == nil) {
            ACAccountType *accountTypeTwitter = [self.accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
            [self.accountStore requestAccessToAccountsWithType:accountTypeTwitter withCompletionHandler:^(BOOL granted, NSError *error) {
                if(granted) {
                    self.accounts = [self.accountStore accountsWithAccountType:accountTypeTwitter];                    
                    if([self.accounts count]==0){
                        
                        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"No Twitter Accounts" 
                                                                            message:@"There are no twitter accounts configured. You can add or create a twitter account in your device Settings." 
                                                                           delegate:self 
                                                                  cancelButtonTitle:@"OK" 
                                                                  otherButtonTitles:nil];
                        [alertView show];
                        
                        
                    }
                    else{
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            UIActionSheet *twitterSheet = [[UIActionSheet alloc] initWithTitle:@"Select Twitter Account"
                                                                                      delegate:self
                                                                             cancelButtonTitle:nil
                                                                        destructiveButtonTitle:nil
                                                                             otherButtonTitles:nil];
                            
                            NSLog(@"The count is %d",[self.accounts count]);
                            for (int i = 0; i < [self.accounts count]; i++) {
                                ACAccount *account = [self.accounts objectAtIndex:i];
                                [twitterSheet addButtonWithTitle:account.username];
                                
                            }
                            
                            [twitterSheet addButtonWithTitle:@"Cancel"];
                            twitterSheet.cancelButtonIndex = [self.accounts count];
                            [twitterSheet setTag:2];
                            [twitterSheet showFromTabBar:self.tabBarController.tabBar]; 
                        });
                    }
                }
            }];
        }
    }
}

-(void) getImageFromCamera {
    UIImagePickerController *imagePicker =
    [[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    
    imagePicker.sourceType = 
    UIImagePickerControllerSourceTypeCamera;
    imagePicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    
    imagePicker.mediaTypes = [NSArray arrayWithObjects:
                              (NSString *) kUTTypeImage,
                              (NSString *) kUTTypeMovie, nil];
    
    imagePicker.allowsEditing = YES;
    [self presentModalViewController:imagePicker 
                            animated:YES];
}

-(void) loadImageFromPicker{
    
    UIImagePickerController *pickerC = 
    [[UIImagePickerController alloc] init];
    pickerC.delegate = self;
    [self presentModalViewController:pickerC animated:YES];
    
}

#pragma imagepicker deletgate

- (void)imagePickerController:(UIImagePickerController *)picker 
didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *gotImage = 
    [info objectForKey:UIImagePickerControllerOriginalImage];
    CGSize sizeOfPhoto = CGSizeMake(100, 100);
    gotImage=[self imageWithImage:gotImage scaledToSizeKeepingAspect:(sizeOfPhoto)];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
    NSData *webData = UIImagePNGRepresentation(gotImage);
    [webData writeToFile:imagePath atomically:YES];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"userImageSaved"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [myPicture setImage:[UIImage imageWithCGImage:gotImage.CGImage]];
    [self uploadPhoto];
    
    
    [self dismissModalViewControllerAnimated:YES];
    
}



- (void)imagePickerControllerDidCancel:
(UIImagePickerController *)picker {
    [self dismissModalViewControllerAnimated:YES];
}

- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSizeKeepingAspect:(CGSize)targetSize
{  
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
        {
            scaleFactor = widthFactor; // scale to fit height
        }
        else
        {
            scaleFactor = heightFactor; // scale to fit width
        }
        
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5; 
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }     
    
    CGContextRef bitmap;
    CGImageRef imageRef = [sourceImage CGImage];
    CGColorSpaceRef genericColorSpace = CGColorSpaceCreateDeviceRGB();
    if (sourceImage.imageOrientation == UIImageOrientationUp || sourceImage.imageOrientation == UIImageOrientationDown)
    {
        bitmap = CGBitmapContextCreate(NULL, targetWidth, targetHeight, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }
    else
    {
        bitmap = CGBitmapContextCreate(NULL, targetHeight, targetWidth, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }   
    
    CGColorSpaceRelease(genericColorSpace);
    CGContextSetInterpolationQuality(bitmap, kCGInterpolationDefault);
    
    // In the right or left cases, we need to switch scaledWidth and scaledHeight,
    // and also the thumbnail point
    if (sourceImage.imageOrientation == UIImageOrientationLeft)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(90));
        CGContextTranslateCTM (bitmap, 0, -targetHeight);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationRight)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(-90));
        CGContextTranslateCTM (bitmap, -targetWidth, 0);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationUp)
    {
        // NOTHING
    }
    else if (sourceImage.imageOrientation == UIImageOrientationDown)
    {
        CGContextTranslateCTM (bitmap, targetWidth, targetHeight);
        CGContextRotateCTM (bitmap, radians(-180.));
    }
    
    CGContextDrawImage(bitmap, CGRectMake(thumbnailPoint.x, thumbnailPoint.y, scaledWidth, scaledHeight), imageRef);
    CGImageRef ref = CGBitmapContextCreateImage(bitmap);
    UIImage* newImage = [UIImage imageWithCGImage:ref];
    
    CGContextRelease(bitmap);
    CGImageRelease(ref);
    
    return newImage; 
}

-(void)uploadPhoto{
    NSLog(@"I am in the uploadPhoto method");
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Uploading Picture...";
    
    NSString *URLString = [NSString stringWithFormat:@"http://www.when.me/iOSCode/upload.aspx?secretkey=387213549&userID=%@&password=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"],[[NSUserDefaults standardUserDefaults] valueForKey:@"password"]];
    //NSLog(@"%@",URLString);
    NSURL *url = [NSURL URLWithString:URLString];
    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    [request setUseKeychainPersistence:YES];
    
    
    NSString *fileName = [NSString stringWithFormat:@"userPhoto_%@.png",[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"]];
    [request addPostValue:fileName forKey:@"name"];
    
    // Upload an image
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:@"user_photo.png"];
    UIImage *img = [UIImage imageWithContentsOfFile:getImagePath];
    NSData *imageData = UIImagePNGRepresentation(img);
    [request setData:imageData withFileName:fileName andContentType:@"image/png" forKey:@"userfile"];
    
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(uploadRequestFinished:)];
    [request setDidFailSelector:@selector(uploadRequestFailed:)];
    
    [request startAsynchronous];
}

- (void)uploadRequestFinished:(ASIHTTPRequest *)request{    
    NSString *responseString = [request responseString];
    NSLog(@"Upload response %@", responseString);
    _hud.labelText = @"Success!";
    [self performSelector:@selector(hideHud) withObject:nil afterDelay:1.0];
}

- (void)uploadRequestFailed:(ASIHTTPRequest *)request{
    
    NSLog(@" Error - Statistics file upload failed: \"%@\"",[[request error] localizedDescription]); 
    
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"Photo not uploaded - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
}





- (void)dealloc {
	[cellUsername release];
	[cellEmail release];


	[txtUsername release];
	[txtEmail release];


	[activityIndicator release];
    [super dealloc];
}


@end

