//
//  FriendViewControllerViewController.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "CMPopTipView.h"
#import <AVFoundation/AVFoundation.h>

@interface FriendsViewController : UIViewController<UITableViewDelegate,UIActionSheetDelegate,UISearchBarDelegate,UISearchDisplayDelegate,CMPopTipViewDelegate,AVAudioPlayerDelegate>
{ 
    NSMutableData *responseData;
    MBProgressHUD *_hud;
    NSMutableArray *friendsArray;
    int feedType;
    NSManagedObjectContext *managedObjectContext;
    NSString                *searchString;
    UISearchBar *searchBar;
    UISearchDisplayController *searchDisplayController;
    
    NSArray *originalData;
    NSMutableArray *searchData;
    int popTipSeen;
    bool searchBarActive;
    int phoneVersion;
}

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;
@property (nonatomic, retain) NSMutableArray *friendsArray;
@property (retain) MBProgressHUD *hud;
@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;
@property (strong, nonatomic) IBOutlet UITableView *tv;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@property (strong, nonatomic) NSString        *searchString;

@property (strong, nonatomic) UIImage *photoButtonImage;
@property (strong, nonatomic) UIButton *photoButton;
@property (nonatomic) BOOL isLoggedIn;
@property (strong, nonatomic) CMPopTipView *PopTipView;
@property (strong, nonatomic) UISearchBar *searchBar;

@property (strong,retain) AVAudioPlayer *playSound;





@end
