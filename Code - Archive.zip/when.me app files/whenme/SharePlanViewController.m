//
//  SharePlanViewController.m
//  whenme
//
//  Created by Eric English on 4/24/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "SharePlanViewController.h"
#import "SignupTableViewController.h"
#import "TokenCountViewController.h"
#import "KeychainWrapper.h"
#import "whenMeConstants.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <QuartzCore/QuartzCore.h>


#import "SHK.h"
#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "GAI.h"

@interface SharePlanViewController ()


@end



@implementation SharePlanViewController

@synthesize myPlanData;
@synthesize backGround; 
@synthesize graybar;
@synthesize shareButton;
@synthesize completeButton;
@synthesize deleteButton;
@synthesize trashButton;
@synthesize remindSwitch;
@synthesize locationSwitch;
@synthesize shareMyPlan;
@synthesize planTextView;
@synthesize shareView;
@synthesize managedObjectContext;
@synthesize facebookShareButton;
@synthesize twitterShareButton;
@synthesize whenmeShareButton;
@synthesize isLoggedIn;
@synthesize hud = _hud;
@synthesize responseData;
@synthesize uniqueIDString;
@synthesize locationManager;
@synthesize currentLocation;
@synthesize timerDisplay;
@synthesize timer;
@synthesize myPlanImage;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithData:(NSMutableDictionary*)data nibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    // call the base class ini
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.myPlanData = data;

    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"My Plan";
    isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    self.view.backgroundColor=[UIColor colorWithRed:249.0f/255.0f green:247.0f/255.0f blue:243.0f/255.0f alpha:1.0f];
    //[backGround setImage:[UIImage imageNamed:@"background-tan.png"]] ;
    [graybar setImage:[UIImage imageNamed:@"offwhite-bar.png"]] ;
    //[ringMyPlan setImage:[UIImage imageNamed:@"sharemyplan.png"]];
    
    //iphone 5 screen compatibility
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            CGSize result = [[UIScreen mainScreen] bounds].size;
            CGFloat scale = [UIScreen mainScreen].scale;
            result = CGSizeMake(result.width * scale, result.height * scale);
            
            if(result.height == 960){
                NSLog(@"iphone 4, 4s retina resolution");
                phoneVersion=4;
            }
            if(result.height == 1136){
                NSLog(@"iphone 5 resolution");
                phoneVersion=5;
            }
        }
        else{
            NSLog(@"iphone standard resolution");
            phoneVersion=3;
        }
    }
    else{
        if ([[UIScreen mainScreen] respondsToSelector: @selector(scale)]) {
            NSLog(@"ipad Retina resolution");
            phoneVersion=4;
        }
        else{
            NSLog(@"ipad Standard resolution");
            phoneVersion=4;
        }
    }
    
    if (phoneVersion<5){
        
    }
    else {
        shareView.frame=CGRectMake(17,424,287,40);
    }
    shareView.layer.cornerRadius = 10;
    
    planTextView.layer.cornerRadius = 10;
    planTextView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    planTextView.textColor=[[UIColor alloc] initWithRed:152.0 / 255 green:123.0 / 255 blue:94.0 / 255 alpha:1.0];
    //planTextView.layer.borderWidth=1;
    //planTextView.layer.borderColor=[UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1].CGColor;
    
    if (phoneVersion<5){
        
    }
    else {
        planTextView.frame=CGRectMake(17,145,287,267);
      
    }
    
    
    UIImage *buttonImage = [UIImage imageNamed:@"cameraButton.png"];
    UIButton *aButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [aButton setImage:buttonImage forState:UIControlStateNormal];
    aButton.frame = CGRectMake(0.0, 0.0, buttonImage.size.width, buttonImage.size.height);
    [aButton addTarget:self action:@selector(showPhotoSheet) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *aBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:aButton];
    
    self.navigationItem.rightBarButtonItem=aBarButtonItem;
    
  
    
    //construct the plan view text
    NSString *finalPlanText;
    NSString *planText=[myPlanData objectForKey:@"planText"];
    NSString *planDigitPicked=[myPlanData objectForKey:@"planDigitPicked"];
    NSString *planTimeFramePicked=[myPlanData objectForKey:@"planTimeFramePicked"];
    NSString *planDate=[myPlanData objectForKey:@"planDate"];
    NSString *planPrefix=[myPlanData objectForKey:@"planPrefix"];
    if (planPrefix==nil || [planPrefix isEqualToString:@""]){
        planPrefix=@"I am going to";
    }
    uniqueIDString=[myPlanData objectForKey:@"uniqueID"];
    
    NSLog (@"In the view did load the string is %@",uniqueIDString);
    NSLog(@"%@",planPrefix);
    if ([planTimeFramePicked isEqualToString:@"today"] || [planTimeFramePicked isEqualToString:@"tonight"] || [planTimeFramePicked isEqualToString:@"tomorrow"]){
        finalPlanText=[NSString stringWithFormat:@"%@ \n%@ %@.",planPrefix,planText,planTimeFramePicked];
        planTextView.text=finalPlanText;
    }
    else if ([planTimeFramePicked isEqualToString:@"in the past"] || [planTimeFramePicked isEqualToString:@"right now"]){
        finalPlanText=[NSString stringWithFormat:@"%@ \n%@.",planPrefix,planText];
        planTextView.text=finalPlanText;
    }
    else if(planTimeFramePicked==nil){
        NSLog(@"In plantimeframepicked=nil");
        finalPlanText=[NSString stringWithFormat:@"%@ \n%@ %@.",planPrefix,planText,planDate];
        
    }
    else{
        NSLog(@"In else");
     finalPlanText=[NSString stringWithFormat:@"%@ \n%@ %@ %@.",planPrefix,planText,planDigitPicked,planTimeFramePicked];
    }
    
    NSLog(@"after the if else");
    
   //finalPlanText=[NSString stringWithFormat:@"\"I am going to %@ %@ %@.\"",planText,planDigitPicked,planTimeFramePicked];
    //adjust font to fit uitext view
    planTextView.text=finalPlanText;
    float fudgeFactor = 16.0;
    float fontSize = 35;
    
    planTextView.font = [planTextView.font fontWithSize:fontSize];
    
    CGSize tallerSize = CGSizeMake(planTextView.frame.size.width-fudgeFactor,1000);
    CGSize stringSize = [finalPlanText sizeWithFont:planTextView.font constrainedToSize:tallerSize lineBreakMode:UILineBreakModeWordWrap];
    
    while (stringSize.height >= planTextView.frame.size.height)
    {
        if (fontSize <= 12) // it just won't fit
            NSLog(@"it just wont fit");
        
        fontSize -= 1.0;
        planTextView.font = [planTextView.font fontWithSize:fontSize];
        tallerSize = CGSizeMake(planTextView.frame.size.width-fudgeFactor,1000);
        stringSize = [finalPlanText sizeWithFont:planTextView.font constrainedToSize:tallerSize lineBreakMode:UILineBreakModeWordWrap];
    }
    
    
    UIImageView *triangle;
    if (phoneVersion<5){
    triangle = [[UIImageView alloc] initWithFrame:CGRectMake(145, 370, 31, 16)];
    }
    else {
         triangle = [[UIImageView alloc] initWithFrame:CGRectMake(145, 458, 31, 16)];
        
    }
    triangle.image = [UIImage imageNamed:@"triangle.png"];
    [self.view addSubview:triangle];
    

    
    
    deleteButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    if (phoneVersion<5){
    deleteButton.frame = CGRectMake(0,387, 80,44);
    }
    else{
        deleteButton.frame = CGRectMake(0,475, 80,44);
        
    }
    deleteButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [deleteButton addTarget:self action:@selector(showTrashConfirm) forControlEvents:UIControlEventTouchUpInside];
    [deleteButton setBackgroundImage:[UIImage imageNamed:@"button-delete-brown.png"] forState:UIControlStateNormal]; //sets the Background image 
    
    [deleteButton setImage:[UIImage imageNamed:@"button-delete-brown.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:deleteButton ];
    
    shareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    if (phoneVersion<5){
    shareButton.frame = CGRectMake(80,387, 160,44);
    }
    else{
      shareButton.frame = CGRectMake(80,475, 160,44);
    }
    shareButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [shareButton addTarget:self action:@selector(shareIt) forControlEvents:UIControlEventTouchUpInside];
    [shareButton setBackgroundImage:[UIImage imageNamed:@"button-share-brown.png"] forState:UIControlStateNormal]; //sets the Background image
    
    [shareButton setImage:[UIImage imageNamed:@"button-share-brown.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:shareButton ];
    
    completeButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
    if (phoneVersion<5){
    completeButton.frame = CGRectMake(240,387, 80,44);
    }
    else {
      completeButton.frame = CGRectMake(240,475, 80,44);
    }
    completeButton.backgroundColor = [UIColor clearColor]; //sets the background color
    [completeButton addTarget:self action:@selector(showCompleteConfirm) forControlEvents:UIControlEventTouchUpInside];
    [completeButton setBackgroundImage:[UIImage imageNamed:@"button-complete-brown.png"] forState:UIControlStateNormal]; //sets the Background image
    
    [completeButton setImage:[UIImage imageNamed:@"button-complete-brown.png"] forState:UIControlStateNormal]; //sets the image
    [[self view] addSubview:completeButton];
    
    UILabel *imgView = [[UILabel alloc] initWithFrame:CGRectMake(6, 122, 75, 17)];
    [imgView setText:@"reminder:"];
    imgView.textColor=[UIColor lightGrayColor];
    [[self view] addSubview:imgView];
    
    UILabel *imgView2 = [[UILabel alloc] initWithFrame:CGRectMake(160, 122, 71, 17)];
    [imgView2 setText:@"location:"];
     imgView2.textColor=[UIColor lightGrayColor];
    [[self view] addSubview:imgView2];
    
   
    remindSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(80, 112, 0, 0)];
    [remindSwitch addTarget: self action: @selector(flipRemind) forControlEvents: UIControlEventValueChanged];
     [remindSwitch setOn:NO];
    NSData *uriData;
    uriData=[myPlanData objectForKey:@"localID"];
    NSArray *notificationArray = [[UIApplication sharedApplication] scheduledLocalNotifications];
    UILocalNotification *row = nil;
    for (row in notificationArray) {
        NSDictionary *userInfo = row.userInfo;
		NSData *identifier = [userInfo valueForKey:@"localID"];
        
        if(identifier != nil){
            
            if([uriData isEqualToData:identifier]) {
                [remindSwitch setOn:YES];
               
            }
        }
    }


    [self.view addSubview: remindSwitch];
    
    locationSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(232, 112, 0, 0)];
    [locationSwitch addTarget: self action: @selector(flipLocation) forControlEvents: UIControlEventValueChanged];
    
    if ([myPlanData objectForKey:@"locationOverride"]==[NSNumber numberWithInt:1]){
        [locationSwitch setOn:NO];
    } else {
    
    if([myPlanData objectForKey:@"longitude"]==0 && [myPlanData objectForKey:@"latitude"]==0){
        NSLog(@" I have %@,%@",[myPlanData objectForKey:@"longitude"],[myPlanData objectForKey:@"latitude"]);
        if ([CLLocationManager authorizationStatus] != kCLAuthorizationStatusDenied){ //get current location
        [locationSwitch setOn:YES]; 
        [self flipLocation];
        }
        else { //location services denied
             [locationSwitch setOn:NO]; 
        }
        //[locationSwitch setOn:YES]; 
    }
    else {
        [locationSwitch setOn:YES]; 
    }
        
    }
    [self.view addSubview: locationSwitch];
    
    NSManagedObjectContext *context = [self managedObjectContext];
    if (!context) {
        
    }
    
    
    // Pass the managed object context to the view controller.
    self.managedObjectContext = context;
    
    //set up share buttons
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]){
        UIImageView *disabledSharers= [[UIImageView alloc] init];
        disabledSharers.image = [UIImage imageNamed:@"sharingDisabled.png"];
        disabledSharers.frame = CGRectMake(182, 339,115,35);
        [[self view] insertSubview:disabledSharers atIndex:100];
    }
    else {
    facebookShare=[SHKFacebook isServiceAuthorized];
    twitterShare=[SHKTwitter isServiceAuthorized];
    whenmeShare=YES;
    
    if (whenmeShare==NO){
        whenmeShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
        whenmeShareButton.frame = CGRectMake(182, 339, 34, 35);
        }
        else {
          whenmeShareButton.frame = CGRectMake(182, 437, 34, 35);
        }
        whenmeShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [whenmeShareButton addTarget:self action:@selector(toggleWhenme) forControlEvents:UIControlEventTouchUpInside];
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:whenmeShareButton];
    }
    else{
        whenmeShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
        whenmeShareButton.frame = CGRectMake(182, 339, 34, 35);
        }
        else{
            whenmeShareButton.frame = CGRectMake(182, 427, 34, 35);
        }
        whenmeShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [whenmeShareButton addTarget:self action:@selector(toggleWhenme) forControlEvents:UIControlEventTouchUpInside];
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:whenmeShareButton];
        
    }
    
    if (twitterShare==NO){
        twitterShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
        twitterShareButton.frame = CGRectMake(222, 339, 34, 35);
        }
        else{
          twitterShareButton.frame = CGRectMake(222, 427, 34, 35);
        }
        twitterShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [twitterShareButton addTarget:self action:@selector(authorizeTwitter) forControlEvents:UIControlEventTouchUpInside];
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:twitterShareButton];
    }
    else{
        twitterShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
            twitterShareButton.frame = CGRectMake(222, 339, 34, 35);
        }
        else{
            twitterShareButton.frame = CGRectMake(222, 427, 34, 35);
        }
        twitterShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [twitterShareButton addTarget:self action:@selector(toggleTwitter) forControlEvents:UIControlEventTouchUpInside];
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:twitterShareButton];
        
    }
    
    if (facebookShare==NO){
        facebookShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
        facebookShareButton.frame = CGRectMake(262, 339, 34, 35);
        }
        else{
           facebookShareButton.frame = CGRectMake(262, 427, 34, 35);
        }
        facebookShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [facebookShareButton addTarget:self action:@selector(authorizeFacebook) forControlEvents:UIControlEventTouchUpInside];
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:facebookShareButton];
    }
    else
    {
        facebookShareButton = [UIButton buttonWithType:UIButtonTypeCustom]; //sets the type of UIButton
        if (phoneVersion<5){
            facebookShareButton.frame = CGRectMake(262, 339, 34, 35);
        }
        else{
            facebookShareButton.frame = CGRectMake(262, 427, 34, 35);
        }
        facebookShareButton.backgroundColor = [UIColor clearColor]; //sets the background color
        [facebookShareButton addTarget:self action:@selector(toggleFacebook) forControlEvents:UIControlEventTouchUpInside];
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the image
        [[self view] addSubview:facebookShareButton];
        
    }
}
    NSLog(@"first clock tick is %@",[myPlanData objectForKey:@"planDate"]);
    [self clockTick:[myPlanData objectForKey:@"planDate"]];
    
    tokensEarned=0;
    tokenForFaceBook=FALSE;
    tokenForTwitter=FALSE;
    tokenForWhenMe=FALSE;
    
  
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"view_plan"];
}

- (void) authorizeFacebook{
    [self toggleFacebook];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    NSString *urlImage = @"http://www.when.me/images/icon.png";

    [item setCustomValue:urlImage forKey:@"image"];
    [SHKFacebook shareItem:item];
    
}

- (void) authorizeTwitter{
    [self toggleTwitter];
    NSString *shareTitle = [[NSString alloc] initWithFormat:@"I started using when.me for iOS" ]; 
    NSURL *url = [NSURL URLWithString:@"http://when.me"];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    
    // Share the item
    [SHKTwitter shareItem:item];
  
}

- (void) toggleFacebook {
    //facebookShare=!facebookShare;
    
    if (facebookShare==NO){
        facebookShare=YES;
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        facebookShare=NO;
        [facebookShareButton setBackgroundImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [facebookShareButton setImage:[UIImage imageNamed:@"facebookShareOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}



- (void) toggleTwitter {
    
    if (twitterShare==NO){
        twitterShare=YES;
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        twitterShare=NO;
        [twitterShareButton setBackgroundImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [twitterShareButton setImage:[UIImage imageNamed:@"twitterShareOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}

- (void) toggleWhenme {
    
    if (whenmeShare==NO){
        whenmeShare=YES;
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOn.png"] forState:UIControlStateNormal]; //sets the image
        
    }
    else{
        whenmeShare=NO;
        [whenmeShareButton setBackgroundImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the Background image 
        
        [whenmeShareButton setImage:[UIImage imageNamed:@"meButtonOff.png"] forState:UIControlStateNormal]; //sets the image
    }
}



-(void) showTrashConfirm{
    [self showDeleteSheet:nil];
}

-(void) showCompleteConfirm{
    [self showCompleteSheet:nil];
}

-(IBAction)showDeleteSheet:(id)sender {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Permanently Delete Plan?" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Delete Plan" otherButtonTitles:nil, nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery setTag:1];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];

}

-(IBAction)showCompleteSheet:(id)sender {
	UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:@"Complete This Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:nil, nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery setTag:2];
    [popupQuery addButtonWithTitle:@"I Did It!"]; 
    [popupQuery addButtonWithTitle:@"I'm There!"];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
    
}

-(IBAction)showPhotoSheet {
	UIActionSheet *popupQuery;
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
     popupQuery = [[UIActionSheet alloc] initWithTitle:@"Attach Photo To Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Remove Photo" otherButtonTitles:@"Take New Photo",@"From Photo Library", nil];
    }
    
    else {
        
         popupQuery = [[UIActionSheet alloc] initWithTitle:@"Attach Photo To Plan" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take New Photo",@"From Photo Library", nil];
        
    }
    
	popupQuery.actionSheetStyle = UIActionSheetStyleDefault;
    [popupQuery setTag:3];
	[popupQuery showFromTabBar:self.tabBarController.tabBar];
	
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	
    
    NSLog(@"I am here");
    int actionSheetTag;
    
    actionSheetTag=[actionSheet tag];
    
    if (actionSheetTag==1){
        NSLog(@"Trash it");
        
        if (buttonIndex == 0) { //delete sheet
          
            [self trashMe];
                       
        }
    }
    
    else if (actionSheetTag==2){ //complete sheet
        if (buttonIndex == 1) {
            [self completeMe:1];
            
        }
        
        if (buttonIndex == 2) {
            [self completeMe:2];
            
        }
    }
    
     else if (actionSheetTag==3){ //photo sheet
         
         if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
         
             if (buttonIndex == 0) {
                 
                 [self deletePlanPhoto];
                 
             }
         
         if (buttonIndex == 1) {
             
             [self getImageFromCamera];
             
         }
         if (buttonIndex == 2) {
             [self loadImageFromPicker];
             
             
         }
         
         
         if (buttonIndex == 3) {
             NSLog(@"cancel");
             
         }
         
         }
         else {
             if (buttonIndex == 0) {
                 
                 [self getImageFromCamera];
                 
             }
             if (buttonIndex == 1) {
                 [self loadImageFromPicker];
                 
                 
             }
             
             
             if (buttonIndex == 2) {
                 NSLog(@"cancel");
                 
             }
         }
         
         
     }

    
       
}

-(void) deletePlanPhoto {
    NSLog(@"Delete Plan Photo");
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
        
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:folderPath];
    
 
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",dataPath];
    NSLog(@"I am here photo path:%@",photoPath);
    
    [[NSFileManager defaultManager] removeItemAtPath:photoPath error:NULL];
    //update view
    [myPlanData setObject:[NSNumber numberWithInteger: 0] forKey:@"hasPlanPicture"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myNumber = [f numberFromString:@"0"];
    [myMO setValue:myNumber forKey:@"hasPlanPicture"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }
    
    [myPlanImage removeFromSuperview];

    
    
}

- (void)viewWillDisappear:(BOOL)animated { 
    [super viewWillDisappear:animated]; 
   
}

- (void)viewWillAppear:(BOOL)animated{
 
 isLoggedIn=[[NSUserDefaults standardUserDefaults] boolForKey:PIN_SAVED];
    timer = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                             target: self
                                           selector:@selector(onTick:)
                                           userInfo: nil repeats:YES];
    
   

    
    UIButton *aButton = [UIButton buttonWithType:UIButtonTypeCustom];
    aButton.frame = CGRectMake(289, 67, 50, 100);
    [aButton addTarget:self action:@selector(showPhotoSheet) forControlEvents:UIControlEventTouchUpInside];
    [[self view] insertSubview:aButton atIndex:102];
    tokensEarned=0;
    tokenForFaceBook=FALSE;
    tokenForTwitter=FALSE;
    tokenForWhenMe=FALSE;
}

- (void)viewDidAppear:(BOOL)animated{
   
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
        //show plan image
        NSLog(@"I am in show plan picture");
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
        NSString *folderPath = [uri absoluteString];
        
        NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
        
        if(rangeOfSubstring.location == NSNotFound)
        {
            
        }
        
        folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
        
        NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
        NSLog(@"The image path is %@",imagePath);
        UIImage *img = [UIImage imageWithContentsOfFile:imagePath]; 
        
        //UIImage *img = [UIImage imageNamed:@"addPlanPhoto.png"];
        
        
        //add 1px transparent border to image for anti aliased rotation
        CGRect imageRrect = CGRectMake(0, 0, img.size.width, img.size.height);
        UIGraphicsBeginImageContext( imageRrect.size ); 
        [img drawInRect:CGRectMake(1,1,img.size.width-2,img.size.height-2)];
        img = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        myPlanImage= [[UIImageView alloc] init];
        myPlanImage.image = img;
        
        myPlanImage.frame = CGRectMake(269, 147,50,50);
        myPlanImage.transform = CGAffineTransformMakeRotation(.34906585);
        
        [[self view] insertSubview:myPlanImage atIndex:100];
    }
    else {
        UIImage *img = [UIImage imageNamed:@"addPlanPhoto.png"];
        
        NSLog(@"I am in here");
        
        //add 1px transparent border to image for anti aliased rotation
        CGRect imageRrect = CGRectMake(0, 0, img.size.width, img.size.height);
        UIGraphicsBeginImageContext( imageRrect.size ); 
        [img drawInRect:CGRectMake(1,1,img.size.width-2,img.size.height-2)];
        img = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        myPlanImage= [[UIImageView alloc] init];
        myPlanImage.image = img;
        
        myPlanImage.frame = CGRectMake(269, 147,50,50);
        myPlanImage.transform = CGAffineTransformMakeRotation(.34906585);
        
        [[self view] insertSubview:myPlanImage atIndex:100];
    }
    
    UIImageView *paperClip=  [[UIImageView alloc] init];
    paperClip.image=[UIImage imageNamed:@"paperClip.png"];
    paperClip.frame = CGRectMake(289, 131,21,28);
    [[self view] insertSubview:paperClip atIndex:101];
    
    
   
}

-(void)onTick:(NSTimer *)timer {
	//NSLog(@"Timer Ticked");
	[self clockTick:[myPlanData objectForKey:@"planDate"]];
	
}

- (void) clockTick:(NSString *)myDate
{
    
	
	//myDate=[myDate stringByAppendingString:@" 00:00:00"];
	
	NSDate *todayDate = [NSDate date];
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
	NSString *dateString = [dateFormat stringFromDate:todayDate];  
	
	NSDate *today=[dateFormat dateFromString:dateString];
	NSDate *movieReleaseDate=[dateFormat dateFromString:myDate];
	
	
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
	NSDateComponents *components = [calendar components:NSDayCalendarUnit|NSHourCalendarUnit|NSMinuteCalendarUnit|NSSecondCalendarUnit
											   fromDate:today
												 toDate:movieReleaseDate
												options:0];
    
	self.timerDisplay.text=[NSString stringWithFormat:@"%.2i:%.2i:%.2i:%.2i", components.day, components.hour,components.minute,components.second];
    
    if(self.timerDisplay.text==@"00:00:00:00"){
        
		self.timerDisplay.text=@"00:00:00:00";
		
	}
	
	
	if ([self.timerDisplay.text rangeOfString:@"-"].location != NSNotFound) {
        
		self.timerDisplay.text=@"00:00:00:00";
		
	}
    
    
}



-(void) completeMe:(int)completeType{
    
    //get the id of current plan
    NSData *uriData;
    NSString *uniqueID;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    
    NSNumber *completeValue=[NSNumber numberWithInt:2];
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:uri];
    NSManagedObject *myMO = [moc objectWithID:moID];
    uniqueID=[myMO valueForKey:@"uniqueID"];
    [myMO setValue:completeValue forKey:@"active"];
    
    
    NSArray *notificationArray = [[UIApplication sharedApplication] scheduledLocalNotifications];
    UILocalNotification *row = nil;
    for (row in notificationArray) {
        NSDictionary *userInfo = row.userInfo;
		NSData *identifier = [userInfo valueForKey:@"localID"];
        
        if(identifier != nil){
            
            if([uriData isEqualToData:identifier]) {
                [[UIApplication sharedApplication] cancelLocalNotification:row];
                NSLog(@"Found the local notification! killed it");
            }
        }
    }
    
    NSError *error = nil;
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error updating your plan");
    }
    else {
        //delete from server if its been shared
        NSLog(@"Going to kill %@",uniqueID);
        if(uniqueID!=nil){
            
            NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
            NSString *passwordToSend=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
            responseData = [NSMutableData data];
            
            const char *bytes = [[NSString stringWithFormat:@"userID=%@&password=%@&uniqueID=%@&secretKey=387213549",userID,passwordToSend,uniqueID] UTF8String];
            NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/updatePlan.aspx"];
            NSMutableURLRequest *request =
            [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
            [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
        }
        [self checkInOtherComplete:completeType];
        
    }
    
}

-(void) trashMe{
    
    //get the id of current plan
    NSData *uriData;
    NSString *uniqueID;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:uri];
    NSManagedObject *myMO = [moc objectWithID:moID];
    uniqueID=[myMO valueForKey:@"uniqueID"];
    [moc deleteObject:myMO];

    
    NSArray *notificationArray = [[UIApplication sharedApplication] scheduledLocalNotifications];
    UILocalNotification *row = nil;
    for (row in notificationArray) {
        NSDictionary *userInfo = row.userInfo;
		NSData *identifier = [userInfo valueForKey:@"localID"];
       
        if(identifier != nil){
            
            if([uriData isEqualToData:identifier]) {
                [[UIApplication sharedApplication] cancelLocalNotification:row];
               NSLog(@"Found the local notification! killed it");
            }
        }
    }
    
    NSError *error = nil;
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error deleting your plan");
    }
    else {
        //delete from server if its been shared
        NSLog(@"Going to kill %@",uniqueID);
        if(uniqueID!=nil){
            
        NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
        NSString *passwordToSend=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
        responseData = [NSMutableData data];
            const char *bytes = [[NSString stringWithFormat:@"userID=%@&password=%@&uniqueID=%@&secretKey=387213549",userID,passwordToSend,uniqueID] UTF8String];
            NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/deletePlan.aspx"];
            NSMutableURLRequest *request =
            [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
            [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
             
    }
        [self deletePlanPhoto];
        
    
        [self.navigationController popViewControllerAnimated:YES];
        
         
        
      
    }
    
}

/*- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    NSLog(@"I am in audio player did finish");
     
}*/

- (void)viewDidUnload
{
    [super viewDidUnload];
 
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) shareIt {
    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"sharingOverride"]){
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                            message:@"You have disabled public sharing of plans on the settings tab. If you wish to share your plans you must re-enable this setting." 
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
        
        return;
        
    }
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendEventWithCategory:@"button_tap"
                        withAction:@"plan_shared"
                         withLabel:@"share"
                         withValue:nil];

    
    if (whenmeShare==YES){
        //share on when.me 
        if (isLoggedIn){
            NSString *userID=[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"];
            NSString *passwordToSend=[[NSUserDefaults standardUserDefaults] valueForKey:@"password"];
            
            NSString *planText=[self escape:[myPlanData objectForKey:@"planText"]];
        
            NSString *planDigitPicked=[myPlanData objectForKey:@"planDigitPicked"];
            NSString *planTimeFramePicked=[self escape:[myPlanData objectForKey:@"planTimeFramePicked"]];
            NSString *planDate=[self escape:[myPlanData objectForKey:@"planDate"]];
            
            NSString *planLatitude;
            NSString *planLongitude;
            
            if (locationSwitch.isOn){
            planLatitude=[myPlanData objectForKey:@"latitude"];
            planLongitude=[myPlanData objectForKey:@"longitude"];
            }
            else {
                planLatitude=nil;
                planLongitude=nil;
            }
            
           
            
            NSData *uriData;
            NSString *uniqueID;
            NSPersistentStoreCoordinator *psc;
            NSManagedObjectContext *moc;
            moc=[self managedObjectContext];
            psc = [moc persistentStoreCoordinator];
            uriData=[myPlanData objectForKey:@"localID"];
            
            NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
            NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:uri];
            NSManagedObject *myMO = [moc objectWithID:moID];
            uniqueID=[myMO valueForKey:@"uniqueID"];
            
            if (uniqueID==nil){ //hasn't been shared yet
             self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            _hud.labelText = @"Sharing on when.me...";
            
            responseData = [NSMutableData data];
                const char *bytes = [[NSString stringWithFormat:@"userID=%@&password=%@&plantext=%@&planDigitPicked=%@&planTimeFramePicked=%@&planDate=%@&planLatitude=%@&planLongitude=%@&secretKey=387213549", userID,passwordToSend,planText,planDigitPicked,planTimeFramePicked,planDate,planLatitude,planLongitude] UTF8String];
                NSString *myURLString = [NSString stringWithFormat:@"https://www.when.me/iOSCode/share.aspx"];
                NSMutableURLRequest *request =
                [NSMutableURLRequest requestWithURL:[NSURL URLWithString:myURLString]];
                [request setHTTPMethod:@"POST"];
                [request setHTTPBody:[NSData dataWithBytes:bytes length:strlen(bytes)]];
                [[NSURLConnection alloc] initWithRequest:request delegate:self];
            
           
            }
            else {
                //_hud.labelText = @"Already shared on when.me...";
                 //upload photo again...
                if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
                    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                    _hud.labelText = @"Uploading Photo...";
                    [self uploadPhoto];
                }
                
                else {
                    [self performSelector:@selector(checkInOther) withObject:nil];
                } 
            }
            
            
            
         
            
        }
        else {
            SignupTableViewController* signupVC = [[SignupTableViewController alloc]initWithNibName:@"SignupTableViewController" bundle:nil];
            signupVC.title = NSLocalizedString(@"SignUp", @"");
            [self.navigationController pushViewController:signupVC  animated:YES];

            
        }
    }
    else {
        [self performSelector:@selector(checkInOther) withObject:nil];
    }
}

- (NSString *)escape:(NSString *)text
{
    return (__bridge NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                        (__bridge CFStringRef)text, NULL,
                                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                        kCFStringEncodingUTF8);
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"In connection did receive reponse");
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"In connection did receive data");
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"In connection did fail with error");
    NSLog(@"%@",error);
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	if ([s rangeOfString:@"confirm"].location == NSNotFound){ //check if deleted or completed
    
        [self performSelector:@selector(checkIt) withObject:nil afterDelay:1.5]; //check if shared on when.e and update plan
    
    }
    else {
        NSArray *split = [s componentsSeparatedByString: @"_"];
        NSString *confirmType=[split objectAtIndex:1];

        NSLog(@"%@ from server",confirmType);
    }
   
    
    
	
	
}

-(void)checkIt{
    
    //[self.hud hide:YES];
    NSString *s=[[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
	NSLog(@"%@",s);
    
    if ([s rangeOfString:@"success"].location == NSNotFound){
        
        //something went wrong
        [self.hud hide:YES];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                            message:s
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
        
        
    }
    
    else {
    
        //update the plan ID
        NSArray *split = [s componentsSeparatedByString: @"_"];
        NSString *newPlanID=[split objectAtIndex:1];
        NSString *uniqueID=[split objectAtIndex:2];
        uniqueIDString=uniqueID;
      
    //update the plan with server ID
    //get the id of current plan
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:uri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myNumber = [f numberFromString:newPlanID];
    [myMO setValue:myNumber forKey:@"planID"];
    [myMO setValue:uniqueID forKey:@"uniqueID"];
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }
    }
    tokensEarned=tokensEarned+2;
  
    tokenForWhenMe=TRUE;
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){
        [self uploadPhoto];
    }
    
    else {
     [self performSelector:@selector(checkInOther) withObject:nil];
    } 
    
}

-(void)checkInOther{
    
    [self.hud hide:YES];
    if (facebookShare==YES || twitterShare==YES){
     self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    
    if (facebookShare==NO && twitterShare==NO){
        self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        _hud.labelText = @"Finishing Up...";
    }
    
    
    NSLog(@" authroized= %d share= %d",(int)[SHKFacebook isServiceAuthorized],(int)facebookShare);
    if ([SHKFacebook isServiceAuthorized] && facebookShare==YES){
        
        _hud.labelText = @"Sharing on services...";
        [self writeFacebook];
        tokensEarned=tokensEarned+1;
        tokenForFaceBook=TRUE;
        
    }
    
    if ([SHKTwitter isServiceAuthorized] && twitterShare==YES){
        _hud.labelText = @"Sharing on services...";
        [self writeTwitter];
        tokensEarned=tokensEarned+1;
        tokenForTwitter=TRUE;
    }
    
    [self performSelector:@selector(showShareSuccess) withObject:nil afterDelay:1.0];
}

-(void)checkInOtherComplete:(int)completeType{
    
    [self.hud hide:YES];
    if (facebookShare==YES || twitterShare==YES){
        self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    
    if (facebookShare==NO && twitterShare==NO){
        self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        _hud.labelText = @"Finishing Up...";
    }
    
    
    NSLog(@" authroized= %d share= %d",(int)[SHKFacebook isServiceAuthorized],(int)facebookShare);
    if ([SHKFacebook isServiceAuthorized] && facebookShare==YES){
        
        _hud.labelText = @"Sharing on services...";
        [self writeFacebookComplete:completeType];
        tokensEarned=tokensEarned+1;
        tokenForFaceBook=TRUE;
        
    }
    
    if ([SHKTwitter isServiceAuthorized] && twitterShare==YES){
        _hud.labelText = @"Sharing on services...";
        [self writeTwitterComplete:completeType];
        tokensEarned=tokensEarned+1;
        tokenForTwitter=TRUE;
    }
    //2 tokens for completing
    tokensEarned=tokensEarned+2;
    [self performSelector:@selector(showCompleteSuccess) withObject:nil afterDelay:2.0];
}

-(void)showCompleteSuccess{
    
    [self.hud hide:YES];
    NSLog(@"Tokens earned %d",tokensEarned);
    
    if (tokensEarned>0 && isLoggedIn){
        NSNumber *numTokensEarned=[[NSNumber alloc]  initWithInt:tokensEarned];
        NSNumber *numTokenForWhenMe=[[NSNumber alloc] initWithInt:1];
        NSNumber *numTokenForFaceBook=[[NSNumber alloc] initWithBool:tokenForFaceBook];
        NSNumber *numTokenForTwitter=[[NSNumber alloc] initWithBool:tokenForTwitter];
        NSMutableDictionary *myTokens;
        myTokens = [[NSMutableDictionary alloc] initWithObjectsAndKeys:numTokensEarned, @"tokensEarned", numTokenForWhenMe, @"tokenForWhenMe", numTokenForTwitter, @"tokenForTwitter", numTokenForFaceBook, @"tokenForFaceBook", nil];
        NSLog(@"Sending data: %@",myTokens);
        
        TokenCountViewController* TokenCountVC = [[TokenCountViewController alloc]initWithNibName:@"TokenCountViewController" andData:myTokens bundle:nil];
        TokenCountVC.title = NSLocalizedString(@"My Tokens", @"");
        
        UINavigationController *navController = self.navigationController;
        
        // retain ourselves so that the controller will still exist once it's popped off
       
        
        // Pop this controller and replace with another
        [navController popViewControllerAnimated:NO];//not to see pop
        
        [navController pushViewController:TokenCountVC animated:YES];
        //[self.navigationController pushViewController:TokenCountVC  animated:YES];
        //[self.navigationController popViewControllerAnimated:NO];
    }
    else{
     [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)showShareSuccess{
    [self.hud hide:YES];
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Success!";
    [self performSelector:@selector(finishUp) withObject:nil afterDelay:1.0];
    
}

-(void) finishUp {
    [self.hud hide:YES];
    NSLog(@"Tokens earned %d",tokensEarned);

    if (tokensEarned>0 && isLoggedIn){
        NSNumber *numTokensEarned=[[NSNumber alloc]  initWithInt:tokensEarned];
        NSNumber *numTokenForWhenMe=[[NSNumber alloc] initWithBool:tokenForWhenMe];
        NSNumber *numTokenForFaceBook=[[NSNumber alloc] initWithBool:tokenForFaceBook];
        NSNumber *numTokenForTwitter=[[NSNumber alloc] initWithBool:tokenForTwitter];
        NSMutableDictionary *myTokens;
        myTokens = [[NSMutableDictionary alloc] initWithObjectsAndKeys:numTokensEarned, @"tokensEarned", numTokenForWhenMe, @"tokenForWhenMe", numTokenForTwitter, @"tokenForTwitter", numTokenForFaceBook, @"tokenForFaceBook", nil];
        NSLog(@"Sending data: %@",myTokens);
        
        TokenCountViewController* TokenCountVC = [[TokenCountViewController alloc]initWithNibName:@"TokenCountViewController" andData:myTokens bundle:nil];
    TokenCountVC.title = NSLocalizedString(@"My Tokens", @"");
    [self.navigationController pushViewController:TokenCountVC  animated:YES];
    }
}

- (void) writeFacebook {
    NSLog(@"writing to facebook");
    
   
  if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){ //share the iamge
    
      //get the image
      NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
      NSString *documentsDirectory = [paths objectAtIndex:0];
      
      NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
      NSString *folderPath = [uri absoluteString];
      
      NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
      
      if(rangeOfSubstring.location == NSNotFound)
      {
          
      }
      
      folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
      
      NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
      NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
      NSLog(@"The image path is %@",imagePath);
      UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
      
      NSString *URLString;
      NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
      if (uniqueIDString!=nil){
          URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
      }
      else {
          URLString = [NSString stringWithFormat:@"http://www.when.me/"];
      }
      shareTitle=[NSString stringWithFormat:@"%@ %@",shareTitle,URLString];

      
      SHKItem *item = [SHKItem image:image title:shareTitle];
    [SHKFacebook shareItem:item];
  }
  else {
    
    
    NSString *URLString;
    NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
    if (uniqueIDString!=nil){
    URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
    }
    else {
         URLString = [NSString stringWithFormat:@"http://www.when.me/"];
    }
        
    NSURL *url = [NSURL URLWithString:URLString];
    SHKItem *item = [SHKItem URL:url title:shareTitle text:@"Join me!"];
    
    NSString *urlImage = @"http://www.when.me//images/icon.png";
    
    [item setCustomValue:urlImage forKey:@"image"];
    
    // Share the item
    [SHKFacebook shareItem:item];
  }

    
}

- (void) writeTwitter {
    NSLog(@"writing to twitter");
    
 
    
    /*NSString *twitterHash=[movieTitle stringByReplacingOccurrencesOfString:@" " withString:@""];  
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@":" withString:@""];  
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"-" withString:@""];  
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"'" withString:@""];
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"." withString:@""]; 
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"?" withString:@""]; 
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"!" withString:@""];
    twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"," withString:@""];*/
    
    if ([myPlanData objectForKey:@"hasPlanPicture"]==[NSNumber numberWithInt:1]){ //share the iamge
        
        //get the image
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
        NSString *folderPath = [uri absoluteString];
        
        NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
        
        if(rangeOfSubstring.location == NSNotFound)
        {
            
        }
        
        folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
        
        NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
        NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
        NSLog(@"The image path is %@",imagePath);
        UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
        
        NSString *URLString;
        NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
        if (uniqueIDString!=nil){
            URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
        }
        else {
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
        }
        shareTitle=[NSString stringWithFormat:@"%@ %@ via @WhenMeApp #whenme",shareTitle,URLString];
        
        
        SHKItem *item = [SHKItem image:image title:shareTitle];
        [SHKTwitter shareItem:item];
    }
    else {

    
    NSString *shareTitle = [planTextView.text stringByReplacingOccurrencesOfString: @"\"" withString:@""];
    NSString *URLString;
    shareTitle=[NSString stringWithFormat:@"%@ via @WhenMeApp #whenme", shareTitle];
    if (uniqueIDString!=nil){
        URLString = [NSString stringWithFormat:@"http://www.when.me/%@",uniqueIDString];
    }
    else {
        URLString = [NSString stringWithFormat:@"http://www.when.me/"];
    }
    
    NSURL *url = [NSURL URLWithString:URLString];
    SHKItem *item = [SHKItem URL:url title:shareTitle];
    
    // Share the item
    [SHKTwitter shareItem:item];
}
    
}

- (void) writeFacebookComplete:(int)completeType {
    NSLog(@"writing to facebook complete");

        NSString *URLString;
    NSString *shareTitle;
    if (completeType==1){
    shareTitle=[NSString stringWithFormat:@"%@",[myPlanData objectForKey:@"planText"]];
    }
    else if (completeType==2) {
    shareTitle=[NSString stringWithFormat:@"Checked in: %@",[myPlanData objectForKey:@"planText"]];
    }
                 
    
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];
      
        
        NSURL *url = [NSURL URLWithString:URLString];
    NSLog(@"The share title is %@",shareTitle);
    SHKItem *item;
    if (completeType==1){
    item=[SHKItem URL:url title:shareTitle text:@"I did it!"];
    }
    else if (completeType==2){
       item=[SHKItem URL:url title:shareTitle text:@"I am there!"];  
    }
        
        NSString *urlImage = @"http://www.when.me/images/icon.png";
        
        [item setCustomValue:urlImage forKey:@"image"];
        
        // Share the item
        [SHKFacebook shareItem:item];
  
    
    
}

- (void) writeTwitterComplete:(int)completeType {
    NSLog(@"writing to twitter complete");
    
    
    
    /*NSString *twitterHash=[movieTitle stringByReplacingOccurrencesOfString:@" " withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@":" withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"-" withString:@""];  
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"'" withString:@""];
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"." withString:@""]; 
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"?" withString:@""]; 
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"!" withString:@""];
     twitterHash=[twitterHash stringByReplacingOccurrencesOfString:@"," withString:@""];*/
    
 
        
        
        NSString *shareTitle = [myPlanData objectForKey:@"planText"];
        NSString *URLString;
    if (completeType==1){
        shareTitle=[NSString stringWithFormat:@"I did it! %@ via @WhenMeApp #whenme", shareTitle];
    }
    else if (completeType==2){
        shareTitle=[NSString stringWithFormat:@"Checked in at: %@ via @WhenMeApp #whenme", shareTitle];
    }
      
            URLString = [NSString stringWithFormat:@"http://www.when.me/"];

        
        NSURL *url = [NSURL URLWithString:URLString];
        SHKItem *item = [SHKItem URL:url title:shareTitle];
        
        // Share the item
        [SHKTwitter shareItem:item];

    
}

- (void)flipLocation {
    
    if (locationSwitch.isOn)
    {
        if ([myPlanData objectForKey:@"latitude"]==nil || [myPlanData objectForKey:@"longitude"]==nil){
          //need to get current location and set it to myplandata
          
            //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            //_hud.labelText = @"Getting Current Location...";
            [[self locationManager] startUpdatingLocation];

        }
        
        NSData *uriData;
        NSPersistentStoreCoordinator *psc;
        NSManagedObjectContext *moc;
        moc=[self managedObjectContext];
        psc = [moc persistentStoreCoordinator];
        uriData=[myPlanData objectForKey:@"localID"];
        NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
        NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
        NSError *error = nil;
        NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterNoStyle];
        [myMO setValue:[NSNumber numberWithInt:0] forKey:@"locationOverride"];
        //[myMO setValue:nil forKey:@"latitude"];
        // [myMO setValue:nil forKey:@"longitude"];
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }
    }
    
    if (!locationSwitch.isOn)
    {
        
        //update the plan data in coredata
        NSData *uriData;
        NSPersistentStoreCoordinator *psc;
        NSManagedObjectContext *moc;
        moc=[self managedObjectContext];
        psc = [moc persistentStoreCoordinator];
        uriData=[myPlanData objectForKey:@"localID"];
        NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
        NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
        NSError *error = nil;
        NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterNoStyle];
        [myMO setValue:[NSNumber numberWithInt:1] forKey:@"locationOverride"];
        //[myMO setValue:nil forKey:@"latitude"];
       // [myMO setValue:nil forKey:@"longitude"];
        if (![managedObjectContext save:&error]) {
            NSLog(@"There was error saving your plan");
        }

    }
    
}

- (void)flipRemind {
    
    if ([remindSwitch isOn]){
        
        //set the local alert
        NSTimeZone *timeZone = [NSTimeZone localTimeZone];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setTimeZone:timeZone];	
        [dateFormat setDateFormat:@"MM/dd/yyyy HH:mm:ss"];
        
        /*NSString *customTime = [[NSUserDefaults standardUserDefaults]
         stringForKey:@"customTime"];
         if (!customTime){
         customTime=@" 9:00:00";
         }*/
        NSString *myFireDateString=[myPlanData objectForKey:@"planDate"];
        NSLog(@"%@",myFireDateString);
        NSDate *myFireDate = [dateFormat dateFromString:myFireDateString];
        
        
        UILocalNotification *scheduledAlert;
        scheduledAlert = [[UILocalNotification alloc] init];
        scheduledAlert.applicationIconBadgeNumber=-1;
        scheduledAlert.fireDate = myFireDate;
        scheduledAlert.timeZone = [NSTimeZone localTimeZone];
        scheduledAlert.userInfo = myPlanData;
        scheduledAlert.soundName= UILocalNotificationDefaultSoundName;
        scheduledAlert.alertBody = [NSString stringWithFormat:@"Reminder: \"%@\" ", [myPlanData objectForKey:@"planText"]];
        [[UIApplication sharedApplication] scheduleLocalNotification:scheduledAlert];
    }
    
    else {
        NSData *uriData;
        uriData=[myPlanData objectForKey:@"localID"];
        NSArray *notificationArray = [[UIApplication sharedApplication] scheduledLocalNotifications];
        UILocalNotification *row = nil;
        for (row in notificationArray) {
            NSDictionary *userInfo = row.userInfo;
            NSData *identifier = [userInfo valueForKey:@"localID"];
            
            if(identifier != nil){
                
                if([uriData isEqualToData:identifier]) {
                    [[UIApplication sharedApplication] cancelLocalNotification:row];
                    NSLog(@"Found the local notification! killed it");
                }
            }
        }
    }
    
}

#pragma mark -
#pragma mark Location manager

/**
 Return a location manager -- create one if necessary.
 */

- (CLLocationManager *)locationManager 
{
	
    if (locationManager != nil) 
    {
		return locationManager;
	}
	
	locationManager = [[CLLocationManager alloc] init];
	[locationManager setDesiredAccuracy:kCLLocationAccuracyNearestTenMeters];
	[locationManager setDelegate:self];
	
	return locationManager;
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation 
{
    
    NSLog(@"I am in the locationManger did update");
    
    currentLocation = newLocation;
    CLLocationCoordinate2D coords=CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    NSLog(@"The corrdinate is %f",coords.latitude);
    NSString *latString=[NSString stringWithFormat:@"%f", coords.latitude];   
    NSString *longString=[NSString stringWithFormat:@"%f", coords.longitude]; 
    [myPlanData setObject:latString forKey:@"latitude"];
    [myPlanData setObject:longString forKey:@"longitude"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myLat = [f numberFromString:latString];
    NSNumber * myLong = [f numberFromString:longString];
    [myMO setValue:myLat forKey:@"latitude"];
    [myMO setValue:myLong forKey:@"longitude"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }
    
    [self.hud hide:YES];
    [locationManager stopUpdatingLocation];
   
    
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error 
{
    NSLog(@"locationManager FAIL");
    NSLog(@"%@", [error description]);
    [self.hud hide:YES];
    [locationSwitch setOn:false animated:YES];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"You have disabled location sharing for when.me or no network connection is available. To re-enable location sharing please switch 'Location Services' to 'On' for when.me in your device settings." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
    
}

/*-(void) getImageFromCamera {
    NSLog(@"I am in getImageFrom Camera");
    UIImagePickerController *imagePicker =
    [[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    
    imagePicker.sourceType = 
    UIImagePickerControllerSourceTypeCamera;
    //imagePicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    
    imagePicker.mediaTypes = [NSArray arrayWithObjects:
                              (NSString *) kUTTypeImage,
                               nil];
    
    imagePicker.allowsEditing = YES;
    [self presentModalViewController:imagePicker 
                            animated:YES];
}*/

-(void) getImageFromCamera {
    UIImagePickerController *imagePicker =
    [[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    
    imagePicker.sourceType = 
    UIImagePickerControllerSourceTypeCamera;
    imagePicker.cameraDevice = UIImagePickerControllerCameraDeviceRear;
    
    imagePicker.mediaTypes = [NSArray arrayWithObjects:
                              (NSString *) kUTTypeImage,
                              (NSString *) kUTTypeMovie, nil];
    
    imagePicker.allowsEditing = YES;
    [self presentModalViewController:imagePicker 
                            animated:YES];
}

-(void) loadImageFromPicker{
    
    UIImagePickerController *pickerC = 
    [[UIImagePickerController alloc] init];
    pickerC.delegate = self;
    [self presentModalViewController:pickerC animated:YES];
    
}

#pragma imagepicker deletgate

- (void)imagePickerController:(UIImagePickerController *)picker 
didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
     [self dismissModalViewControllerAnimated:YES];
    NSLog(@"I am in the delegate emthod");
    UIImage *gotImage = 
    [info objectForKey:UIImagePickerControllerOriginalImage];
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera){
     UIImageWriteToSavedPhotosAlbum(gotImage, nil, nil, nil);
    }
    CGSize sizeOfPhoto = CGSizeMake(500, 500);
    gotImage=[self imageWithImage:gotImage scaledToSizeKeepingAspect:(sizeOfPhoto)];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
 
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
      
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    
    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:folderPath];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:YES attributes:nil error:nil]; //Create folder
    
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
    NSLog(@"I am here photo path:%@",photoPath);
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
    NSData *webData = UIImagePNGRepresentation(gotImage);
    [webData writeToFile:imagePath atomically:YES];
    
    //update view
    [myPlanData setObject:[NSNumber numberWithInteger: 1] forKey:@"hasPlanPicture"];
    //update the plan data in coredata
    NSData *uriData;
    NSPersistentStoreCoordinator *psc;
    NSManagedObjectContext *moc;
    moc=[self managedObjectContext];
    psc = [moc persistentStoreCoordinator];
    uriData=[myPlanData objectForKey:@"localID"];
    NSURL *myuri = [NSKeyedUnarchiver unarchiveObjectWithData:uriData];
    NSManagedObjectID *moID = [psc managedObjectIDForURIRepresentation:myuri];
    NSError *error = nil;
    NSManagedObject *myMO = [moc existingObjectWithID:moID error:&error];
    NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
    [f setNumberStyle:NSNumberFormatterNoStyle];
    NSNumber * myNumber = [f numberFromString:@"1"];
    [myMO setValue:myNumber forKey:@"hasPlanPicture"];
    if (![managedObjectContext save:&error]) {
        NSLog(@"There was error saving your plan");
    }


    
    
   
    
}



- (void)imagePickerControllerDidCancel:
(UIImagePickerController *)picker {
    [self dismissModalViewControllerAnimated:YES];
}

- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSizeKeepingAspect:(CGSize)targetSize
{  
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
        {
            scaleFactor = widthFactor; // scale to fit height
        }
        else
        {
            scaleFactor = heightFactor; // scale to fit width
        }
        
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5; 
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }     
    
    CGContextRef bitmap;
    CGImageRef imageRef = [sourceImage CGImage];
    CGColorSpaceRef genericColorSpace = CGColorSpaceCreateDeviceRGB();
    if (sourceImage.imageOrientation == UIImageOrientationUp || sourceImage.imageOrientation == UIImageOrientationDown)
    {
        bitmap = CGBitmapContextCreate(NULL, targetWidth, targetHeight, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }
    else
    {
        bitmap = CGBitmapContextCreate(NULL, targetHeight, targetWidth, 8, 4 * targetWidth, genericColorSpace, kCGImageAlphaPremultipliedFirst);
        
    }   
    
    CGColorSpaceRelease(genericColorSpace);
    CGContextSetInterpolationQuality(bitmap, kCGInterpolationDefault);
    
    // In the right or left cases, we need to switch scaledWidth and scaledHeight,
    // and also the thumbnail point
    if (sourceImage.imageOrientation == UIImageOrientationLeft)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(90));
        CGContextTranslateCTM (bitmap, 0, -targetHeight);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationRight)
    {
        thumbnailPoint = CGPointMake(thumbnailPoint.y, thumbnailPoint.x);
        CGFloat oldScaledWidth = scaledWidth;
        scaledWidth = scaledHeight;
        scaledHeight = oldScaledWidth;
        
        CGContextRotateCTM (bitmap, radians(-90));
        CGContextTranslateCTM (bitmap, -targetWidth, 0);
        
    }
    else if (sourceImage.imageOrientation == UIImageOrientationUp)
    {
        // NOTHING
    }
    else if (sourceImage.imageOrientation == UIImageOrientationDown)
    {
        CGContextTranslateCTM (bitmap, targetWidth, targetHeight);
        CGContextRotateCTM (bitmap, radians(-180.));
    }
    
    CGContextDrawImage(bitmap, CGRectMake(thumbnailPoint.x, thumbnailPoint.y, scaledWidth, scaledHeight), imageRef);
    CGImageRef ref = CGBitmapContextCreateImage(bitmap);
    UIImage* newImage = [UIImage imageWithCGImage:ref];
    
    CGContextRelease(bitmap);
    CGImageRelease(ref);
    
    return newImage; 
}

-(void)uploadPhoto{
    NSLog(@"I am in the uploadPhoto method");
 
    //self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _hud.labelText = @"Uploading Picture...";
    
    NSString *URLString = [NSString stringWithFormat:@"http://www.when.me/iOSCode/uploadPlanPhoto.aspx?secretkey=387213549&userID=%@&password=%@&planID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"userID"],[[NSUserDefaults standardUserDefaults] valueForKey:@"password"],uniqueIDString];
    //NSLog(@"%@",URLString);
    NSURL *url = [NSURL URLWithString:URLString];
    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    [request setUseKeychainPersistence:YES];
    
    
    NSString *fileName = [NSString stringWithFormat:@"planPhoto_%@.jpg",uniqueIDString];
    [request addPostValue:fileName forKey:@"name"];
    
    // Upload an image
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSURL *uri = [NSKeyedUnarchiver unarchiveObjectWithData:[myPlanData objectForKey:@"localID"]];
    NSString *folderPath = [uri absoluteString];
    
    NSRange rangeOfSubstring = [folderPath rangeOfString:@"Plan/"];
    
    if(rangeOfSubstring.location == NSNotFound)
    {
        
    }
    
    folderPath=[folderPath substringFromIndex:rangeOfSubstring.location];
    
    NSString *photoPath = [NSString stringWithFormat:@"%@/plan_photo_before.png",folderPath];
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:photoPath];
    NSLog(@"The image path is %@",imagePath);
    UIImage *img = [UIImage imageWithContentsOfFile:imagePath]; 
    NSData *imageData = UIImageJPEGRepresentation(img,0.66);
    
    
    [request setData:imageData withFileName:fileName andContentType:@"image/jpeg" forKey:@"userfile"];
    
    [request setDelegate:self];
    [request setDidFinishSelector:@selector(uploadRequestFinished:)];
    [request setDidFailSelector:@selector(uploadRequestFailed:)];
    
    [request startAsynchronous];
}

- (void)uploadRequestFinished:(ASIHTTPRequest *)request{    
    NSString *responseString = [request responseString];
    NSLog(@"Upload response %@", responseString);
    _hud.labelText = @"Success!";
    [self performSelector:@selector(checkInOther) withObject:nil afterDelay:0.5];
}

- (void)uploadRequestFailed:(ASIHTTPRequest *)request{
    
    NSLog(@" Error - file upload failed: \"%@\"",[[request error] localizedDescription]); 
    
    [self.hud hide:YES];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops. Something went wrong :(" 
                                                        message:@"It's not your fault - when.me may be over capacity. Please check your network connection and try again." 
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView show];
    
}

- (void)dealloc {
    
}






@end
