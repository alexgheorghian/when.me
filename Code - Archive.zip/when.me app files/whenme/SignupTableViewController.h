//
//  SignupTableViewController.h
//  ExSignup
//
//  Created by Nada Jaksic on 7/13/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "whenMeConstants.h"
#import <Accounts/Accounts.h>


@interface SignupTableViewController : UITableViewController<UITextFieldDelegate, UIActionSheetDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{

    int phoneVersion;
    
    IBOutlet UITableViewCell *cellUsername;
    IBOutlet UITableViewCell *cellEmail;
	IBOutlet UITableViewCell *cellPassword;
    IBOutlet UITableViewCell *cellPicture;
	

	IBOutlet UITextField* txtUsername;
	IBOutlet UITextField* txtEmail;
	IBOutlet UITextField* txtPassword;
    IBOutlet UIImageView* myPicture;


	UIActivityIndicatorView* activityIndicator;
    
    NSMutableData *responseData;
    
    MBProgressHUD *_hud;
    


}

@property (nonatomic, retain) IBOutlet UITableViewCell *cellUsername;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellEmail;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellPassword;
@property (nonatomic, retain) IBOutlet UITableViewCell *cellPicture;

@property (nonatomic, retain) IBOutlet UITextField* txtUsername;
@property (nonatomic, retain) IBOutlet UITextField* txtEmail;
@property (nonatomic, retain) IBOutlet UITextField* txtPassword;
@property (nonatomic, retain) IBOutlet UIImageView* myPicture;

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;

@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;

@property (retain) MBProgressHUD *hud;

@property (strong, nonatomic) ACAccountStore *accountStore; 
@property (strong, nonatomic) NSArray *accounts;

@property (strong, nonatomic) NSTimer *timer;


-(void)signup;

@end
