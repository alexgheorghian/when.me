//
//  Plan.h
//  whenme
//
//  Created by Eric English on 4/27/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Plan : NSManagedObject

@property (nonatomic, retain) NSNumber * planID;
@property (nonatomic, retain) NSString * planText;
@property (nonatomic, retain) NSString * planDigit;
@property (nonatomic, retain) NSString * planTimeFrame;
@property (nonatomic, retain) NSString * uniqueID;
@property (nonatomic, retain) NSDate * planDate;
@property (nonatomic, retain) NSDate * planCompleteDate;
@property (nonatomic, retain) NSDate * createDate;
@property (nonatomic, retain) NSNumber * latitude;
@property (nonatomic, retain) NSNumber * longitude;
@property (nonatomic, retain) NSNumber * active;
@property (nonatomic, retain) NSNumber * hasPlanPicture;
@property (nonatomic, retain) NSNumber * hasCompletePicture;
@property (nonatomic, retain) NSNumber * locationOverride;

@end
