//
//  PlanViewController.h
//  whenme
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <CoreLocation/CoreLocation.h>
#import "PlacesTableViewController.h"
#import "SharePlanViewController.h"
#import "MBProgressHUD.h"
#import "CMPopTipView.h"


int pickerSelected;
int popTipSeen;
int popTip2Seen;
int firstPopSeen;
int keyBoardVisible;
int thereButtonPressed;
int phoneVersion;
NSString *myPlanText;



@interface PlanViewController : UIViewController<UIPickerViewDelegate,UITextViewDelegate,CMPopTipViewDelegate,AVAudioPlayerDelegate>{
    MBProgressHUD *_hud;
    NSManagedObjectContext *managedObjectContext;
}




@property (strong, nonatomic) IBOutlet UIImageView *backGround;
@property (strong, nonatomic) IBOutlet UIImageView *logo;
@property (strong, nonatomic) IBOutlet UIImageView *iamgoingto;
@property (strong, nonatomic) IBOutlet UIImageView *iamat;
@property (strong, nonatomic) IBOutlet UIImageView *myPhoto;
@property (strong, nonatomic) UIImageView *locationGray;
@property (strong, nonatomic) UIImageView * planPickerMaskView;
@property (strong, nonatomic) UIImageView * planPickerDateMaskView;
@property (strong, nonatomic) UIButton * planArrow;
@property (strong, nonatomic) UIButton * planArrowBack;
@property (strong, nonatomic) UIButton *addButton;
@property (strong, nonatomic) UIButton *mapButton;
@property (strong, nonatomic) UIButton *thereButton;
@property (strong, nonatomic) UIButton *calendarButton;
@property (strong, nonatomic) UIButton *aButton;
@property (strong, nonatomic) UIButton *aButton2;
@property (strong, nonatomic) UIButton *photoButton;
@property (strong, nonatomic) UIPickerView *myDigitPickerView;
@property (strong, nonatomic) UIPickerView *myTimeFramePickerView;
@property (strong, nonatomic) UIDatePicker *myDateTimePickerView;

@property (strong, nonatomic) NSArray *digitsArray;
@property (strong, nonatomic) NSMutableArray *timeFrameArray;

@property (strong, nonatomic) NSNumber *planLatitude;
@property (strong, nonatomic) NSNumber *planLongitude;

@property (strong, nonatomic) UIImage *buttonImage2; 
@property (strong, nonatomic) UIImage *photoButtonImage; 

@property (strong, nonatomic) UIImageView *imgView;

@property (strong, nonatomic) UIView *tutorialPop;


@property (strong, nonatomic) IBOutlet UITextView *planTextView;
@property (strong, nonatomic) UINavigationController *navController;
@property (strong, nonatomic) PlacesTableViewController *placesView;
@property (strong, nonatomic) UISegmentedControl *segControl;
@property (strong, nonatomic) UIToolbar *toolbar;
@property (strong, nonatomic) CMPopTipView *PopTipView;
@property (strong, nonatomic) CMPopTipView *PopTipView2;
@property (strong, nonatomic) CMPopTipView *PopTipViewFirstTime;
@property (retain) MBProgressHUD *hud;

@property (nonatomic) BOOL isLoggedIn;

@property (strong,retain) AVAudioPlayer *playSound;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;









@end
