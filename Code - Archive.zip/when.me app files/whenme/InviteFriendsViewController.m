//
//  InviteFriendsViewController.m
//  whenme
//
//  Created by Eric English on 6/27/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "InviteFriendsViewController.h"
#import "GAI.h"
#import <AddressBookUI/AddressBookUI.h>

@interface InviteFriendsViewController ()

@end


@implementation InviteFriendsViewController
@synthesize userEmails;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    //self.navigationController.navigationBar.titleTextAttributes=[UIColor darkGrayColor];
    
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button addTarget:self 
               action:@selector(showPicker:)
     forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"From My Address Book" forState:UIControlStateNormal];
    button.frame = CGRectMake(10.0, 20.0, 300.0, 40.0);
    [self.view addSubview:button];
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button2 addTarget:self
               action:@selector(tweetIt)
     forControlEvents:UIControlEventTouchUpInside];
    [button2 setTitle:@"Tweet My Followers" forState:UIControlStateNormal];
    button2.frame = CGRectMake(10.0, 80.0, 300.0, 40.0);
    [self.view addSubview:button2];
    
  
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"invite_view"];
   

    
    // Do any additional setup after loading the view from its nib.
}



- (void) viewWillAppear:(BOOL)animated{
    userEmails=[[NSMutableArray alloc] init];
}

-(void) tweetIt {
    

    
    if ([TWTweetComposeViewController canSendTweet])
    {
        TWTweetComposeViewController *tweetSheet = 
        [[TWTweetComposeViewController alloc] init];
        [tweetSheet setInitialText:@"Come join me in sharing plans and places we're going on when.me for iOS! http://www.when.me #whenme"];
	    [self presentModalViewController:tweetSheet animated:YES];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Twitter Not Available." 
                                                            message:@"1. Check that you have an internet connection and you have at least one Twitter account setup. 2. Make sure your device is upgraded the latest operating system." 
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}

- (IBAction)showPicker:(id)sender
{
    ABPeoplePickerNavigationController *picker =
    [[ABPeoplePickerNavigationController alloc] init];
    picker.peoplePickerDelegate = self;
    
    [self presentModalViewController:picker animated:YES];
}

- (void)peoplePickerNavigationControllerDidCancel:
(ABPeoplePickerNavigationController *)peoplePicker
{
    [self dismissModalViewControllerAnimated:YES];
}


- (BOOL)peoplePickerNavigationController:
(ABPeoplePickerNavigationController *)peoplePicker
      shouldContinueAfterSelectingPerson:(ABRecordRef)person {
    
    [self emailPerson:person];
    [self dismissModalViewControllerAnimated:YES];
    
    return NO;
}

- (BOOL)peoplePickerNavigationController:
(ABPeoplePickerNavigationController *)peoplePicker
      shouldContinueAfterSelectingPerson:(ABRecordRef)person
                                property:(ABPropertyID)property
                              identifier:(ABMultiValueIdentifier)identifier
{
    return NO;
}

-(void)emailPerson:(ABRecordRef)person{
    ABMultiValueRef emails = ABRecordCopyValue(person, kABPersonEmailProperty);
    for (int i=0; i<ABMultiValueGetCount(emails); i++) {
        //Get the email
       NSString *mail = (NSString *) CFBridgingRelease(ABMultiValueCopyValueAtIndex(emails, i));
        //Add the email to the array previously initializated
        [userEmails addObject:mail];
   
    }
    CFRelease(emails);
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Choose Email" 
                                                             delegate:self
                                                    cancelButtonTitle:nil
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:nil];
    for (NSString *button in userEmails)
        [actionSheet addButtonWithTitle:button];
    [actionSheet addButtonWithTitle:@"Cancel"];
    
    [actionSheet setCancelButtonIndex:[userEmails count]];
    [actionSheet setTag:1];
    [actionSheet showFromTabBar:self.tabBarController.tabBar];
    //NSLog(@"email this person %@",email);
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	
    int actionSheetTag;
    
    actionSheetTag=[actionSheet tag];
    
    if (actionSheetTag==1){
        if (buttonIndex != [actionSheet cancelButtonIndex]){
        NSLog(@"Email chosen");
        
        NSString *emailAddress=[actionSheet buttonTitleAtIndex:buttonIndex];
        [self emailRequest:emailAddress];
        }
    }

    
}

- (void)emailRequest:(NSString *)sendTo
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
    // Set the subject of email
    [picker setSubject:@"Come join me on when.me!"];
    [picker setToRecipients:[NSArray arrayWithObjects:sendTo, nil]];
    
    // Add email addresses
    // Notice three sections: "to" "cc" and "bcc"	
    // [picker setToRecipients:[NSArray arrayWithObjects:@"emailaddress1@domainName.com", @"emailaddress2@domainName.com", nil]];
    //[picker setCcRecipients:[NSArray arrayWithObject:@"emailaddress3@domainName.com"]];	
    //[picker setBccRecipients:[NSArray arrayWithObject:@"emailaddress4@domainName.com"]];
    
    // Fill out the email body text
    NSString *emailBody = @"I am using when.me for iOS and think you'll like it! We can share future plans and places we are going. You should get it! - <a href=http://www.when.me>www.when.me</a>";
    
    // This is not an HTML formatted email
    [picker setMessageBody:emailBody isHTML:YES];
    
    // Show email view	
    [self presentModalViewController:picker animated:YES];
    
    // Release picker

}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{
  
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
