//
//  TermsOfUseViewController.m
//  whenme
//
//  Created by Eric English on 5/31/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import "TermsOfUseViewController.h"
#import "GAI.h"

@interface TermsOfUseViewController ()

@end

@implementation TermsOfUseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [super viewDidLoad];
    
    self.title= @"Terms Of Use";
    //self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7921 green:.7803 blue:.7529 alpha:1];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:.7019678 green:.7019678 blue:.7019678 alpha:1];
    CGRect webFrame = CGRectMake(0.0, 0.0, 320.0, 460.0);
    UIWebView *webView = [[UIWebView alloc] initWithFrame:webFrame];
    
    NSString *urlAddress = @"http://www.when.me/TermsOfUse.html";
    NSURL *url = [NSURL URLWithString:urlAddress];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [webView loadRequest:requestObj];
    [self.view addSubview:webView]; 
    
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:@"UA-66783-41"];
    [tracker sendView:@"terms_of_use"];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
