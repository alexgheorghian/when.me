//
//  SharePlanViewController.h
//  whenme
//
//  Created by Eric English on 4/24/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <CoreLocation/CoreLocation.h>
#import "MBProgressHUD.h"
#import <AVFoundation/AVFoundation.h>



@interface SharePlanViewController : UIViewController<UIActionSheetDelegate,CLLocationManagerDelegate,UIImagePickerControllerDelegate,AVAudioPlayerDelegate,UINavigationControllerDelegate>{
     NSManagedObjectContext *managedObjectContext;
    
    BOOL facebookShare;
    BOOL twitterShare;
    BOOL whenmeShare;
    BOOL tokenForFaceBook;
    BOOL tokenForTwitter;
    BOOL tokenForWhenMe;
    int  tokensEarned;
    int phoneVersion;
    NSString *uniqueIDString;
    MBProgressHUD *_hud;
    NSMutableData *responseData;
    
    CLLocationManager       *locationManager;
    CLLocation              *currentLocation;


}


@property (strong, nonatomic) IBOutlet UIImageView *graybar;
@property (strong,nonatomic) NSMutableDictionary *myPlanData;
@property (strong, nonatomic) IBOutlet UIImageView *backGround;
@property (strong, nonatomic) IBOutlet UIImageView *shareMyPlan;
@property (strong, nonatomic) IBOutlet UITextView *planTextView;
@property (strong, nonatomic) IBOutlet UIView *shareView;

@property (strong, nonatomic) UIButton *shareButton;
@property (strong, nonatomic) UIButton *deleteButton;
@property (strong, nonatomic) UIButton *completeButton;
@property (strong, nonatomic) UIButton *trashButton;
@property (strong, nonatomic) UISwitch *remindSwitch;
@property (strong, nonatomic) UISwitch *locationSwitch;

@property (strong, nonatomic) UIButton *facebookShareButton;
@property (strong, nonatomic) UIButton *twitterShareButton;
@property (strong, nonatomic) UIButton *whenmeShareButton;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@property (nonatomic) BOOL isLoggedIn;
@property (nonatomic) NSString *uniqueIDString;

@property (retain) MBProgressHUD *hud;

@property (nonatomic, retain) IBOutlet NSMutableData* responseData;
@property (nonatomic, retain) IBOutlet UILabel *timerDisplay;

@property (strong, nonatomic) CLLocationManager *locationManager;
@property (strong, nonatomic) CLLocation        *currentLocation;

@property (nonatomic, retain) NSTimer *timer;

@property (nonatomic,retain) UIImageView *myPlanImage;


-(id) initWithData:(NSMutableDictionary*)data nibName:(NSString*)nib bundle:(NSBundle *)nibBundleOrNil;
-(IBAction)showDeleteSheet:(id)sender;
@end

