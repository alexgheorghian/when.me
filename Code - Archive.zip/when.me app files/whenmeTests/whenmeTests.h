//
//  whenmeTests.h
//  whenmeTests
//
//  Created by Eric English on 4/12/12.
//  Copyright (c) 2012 Mediaspree LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface whenmeTests : SenTestCase

@end
